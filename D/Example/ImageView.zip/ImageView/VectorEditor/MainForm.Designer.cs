﻿namespace VectorEditor
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openRasterToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openExternalVectorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.openXvcVectorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveXvcVectorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pixoneerXVMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.externalVectorFormatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vectorObjectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pointToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ellipseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rectangleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polylineToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.polygonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.textBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bitmapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scaleBarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.measureToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.measurePointToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.measureDistanceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.measureAreaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.measureAngleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.propertyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backgroundColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.changeMouseWheelDirectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zoomToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zoomFitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zoomInToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zoomOutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zoom1to1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enhancementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wholeRegionMinMaxLinearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wholeRegionMinMaxEqualizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wholeRegionMinMaxSqureRootToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.wholeRegionGaussian95LinearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wholeRegionGaussian95EqualizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wholeRegionGaussian95SquareRootToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.wholeRegionGaussian98LinearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wholeRegionGaussian98EqualizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.wholeRegionGaussian98SquareRootToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.visibleRegionMinMaxLinearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visibleRegionMinMaxEqualizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visibleRegionMinMaxSquareRootToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.visibleRegionGaussian95LinearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visibleRegionGaussian95EqualizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visibleRegionGaussian95SquareRootToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.visibleRegionGaussian98LinearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visibleRegionGaussian98EqualizeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.visibleRegionGaussian98SquareRootToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabelMouseCoord = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabelWorldCoord = new System.Windows.Forms.ToolStripStatusLabel();
            this.nxImageView1 = new Pixoneer.NXDL.NXImage.NXImageView();
            this.nxImageLayerComposites = new Pixoneer.NXDL.NXImage.NXImageLayerComposites();
            this.nxImageLayerVectorEditor = new Pixoneer.NXDL.NXImage.NXImageLayerVectorEditor();
            this.menuStrip1.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.nxImageView1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.vectorObjectToolStripMenuItem,
            this.mapToolStripMenuItem,
            this.zoomToolStripMenuItem,
            this.enhancementToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(475, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openRasterToolStripMenuItem,
            this.openExternalVectorToolStripMenuItem,
            this.toolStripSeparator2,
            this.openXvcVectorToolStripMenuItem,
            this.saveXvcVectorToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openRasterToolStripMenuItem
            // 
            this.openRasterToolStripMenuItem.Name = "openRasterToolStripMenuItem";
            this.openRasterToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.openRasterToolStripMenuItem.Text = "Open Raster";
            this.openRasterToolStripMenuItem.Click += new System.EventHandler(this.openRasterToolStripMenuItem_Click);
            // 
            // openExternalVectorToolStripMenuItem
            // 
            this.openExternalVectorToolStripMenuItem.Name = "openExternalVectorToolStripMenuItem";
            this.openExternalVectorToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.openExternalVectorToolStripMenuItem.Text = "Open External Vector";
            this.openExternalVectorToolStripMenuItem.Click += new System.EventHandler(this.openExternalVectorToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(185, 6);
            // 
            // openXvcVectorToolStripMenuItem
            // 
            this.openXvcVectorToolStripMenuItem.Name = "openXvcVectorToolStripMenuItem";
            this.openXvcVectorToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.openXvcVectorToolStripMenuItem.Text = "Open XvcVector";
            this.openXvcVectorToolStripMenuItem.Click += new System.EventHandler(this.openXvcVectorToolStripMenuItem_Click);
            // 
            // saveXvcVectorToolStripMenuItem
            // 
            this.saveXvcVectorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pixoneerXVMLToolStripMenuItem,
            this.externalVectorFormatToolStripMenuItem});
            this.saveXvcVectorToolStripMenuItem.Name = "saveXvcVectorToolStripMenuItem";
            this.saveXvcVectorToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.saveXvcVectorToolStripMenuItem.Text = "Save XvcVector";
            // 
            // pixoneerXVMLToolStripMenuItem
            // 
            this.pixoneerXVMLToolStripMenuItem.Name = "pixoneerXVMLToolStripMenuItem";
            this.pixoneerXVMLToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            this.pixoneerXVMLToolStripMenuItem.Text = "Pixoneer XVML";
            this.pixoneerXVMLToolStripMenuItem.Click += new System.EventHandler(this.pixoneerXVMLToolStripMenuItem_Click);
            // 
            // externalVectorFormatToolStripMenuItem
            // 
            this.externalVectorFormatToolStripMenuItem.Name = "externalVectorFormatToolStripMenuItem";
            this.externalVectorFormatToolStripMenuItem.Size = new System.Drawing.Size(156, 22);
            // 
            // vectorObjectToolStripMenuItem
            // 
            this.vectorObjectToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pointToolStripMenuItem,
            this.lineToolStripMenuItem,
            this.ellipseToolStripMenuItem,
            this.rectangleToolStripMenuItem,
            this.polylineToolStripMenuItem,
            this.polygonToolStripMenuItem,
            this.textToolStripMenuItem,
            this.textBoxToolStripMenuItem,
            this.bitmapToolStripMenuItem,
            this.scaleBarToolStripMenuItem,
            this.measureToolStripMenuItem,
            this.toolStripSeparator1,
            this.propertyToolStripMenuItem});
            this.vectorObjectToolStripMenuItem.Name = "vectorObjectToolStripMenuItem";
            this.vectorObjectToolStripMenuItem.Size = new System.Drawing.Size(93, 20);
            this.vectorObjectToolStripMenuItem.Text = "Vector Object";
            // 
            // pointToolStripMenuItem
            // 
            this.pointToolStripMenuItem.Name = "pointToolStripMenuItem";
            this.pointToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.pointToolStripMenuItem.Text = "Point";
            this.pointToolStripMenuItem.Click += new System.EventHandler(this.pointToolStripMenuItem_Click);
            // 
            // lineToolStripMenuItem
            // 
            this.lineToolStripMenuItem.Name = "lineToolStripMenuItem";
            this.lineToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.lineToolStripMenuItem.Text = "Line";
            this.lineToolStripMenuItem.Click += new System.EventHandler(this.lineToolStripMenuItem_Click);
            // 
            // ellipseToolStripMenuItem
            // 
            this.ellipseToolStripMenuItem.Name = "ellipseToolStripMenuItem";
            this.ellipseToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.ellipseToolStripMenuItem.Text = "Ellipse";
            this.ellipseToolStripMenuItem.Click += new System.EventHandler(this.ellipseToolStripMenuItem_Click);
            // 
            // rectangleToolStripMenuItem
            // 
            this.rectangleToolStripMenuItem.Name = "rectangleToolStripMenuItem";
            this.rectangleToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.rectangleToolStripMenuItem.Text = "Rectangle";
            this.rectangleToolStripMenuItem.Click += new System.EventHandler(this.rectangleToolStripMenuItem_Click);
            // 
            // polylineToolStripMenuItem
            // 
            this.polylineToolStripMenuItem.Name = "polylineToolStripMenuItem";
            this.polylineToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.polylineToolStripMenuItem.Text = "Polyline";
            this.polylineToolStripMenuItem.Click += new System.EventHandler(this.polylineToolStripMenuItem_Click);
            // 
            // polygonToolStripMenuItem
            // 
            this.polygonToolStripMenuItem.Name = "polygonToolStripMenuItem";
            this.polygonToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.polygonToolStripMenuItem.Text = "Polygon";
            this.polygonToolStripMenuItem.Click += new System.EventHandler(this.polygonToolStripMenuItem_Click);
            // 
            // textToolStripMenuItem
            // 
            this.textToolStripMenuItem.Name = "textToolStripMenuItem";
            this.textToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.textToolStripMenuItem.Text = "Text";
            this.textToolStripMenuItem.Click += new System.EventHandler(this.textToolStripMenuItem_Click);
            // 
            // textBoxToolStripMenuItem
            // 
            this.textBoxToolStripMenuItem.Name = "textBoxToolStripMenuItem";
            this.textBoxToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.textBoxToolStripMenuItem.Text = "TextBox";
            this.textBoxToolStripMenuItem.Click += new System.EventHandler(this.textBoxToolStripMenuItem_Click);
            // 
            // bitmapToolStripMenuItem
            // 
            this.bitmapToolStripMenuItem.Name = "bitmapToolStripMenuItem";
            this.bitmapToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.bitmapToolStripMenuItem.Text = "Bitmap";
            this.bitmapToolStripMenuItem.Click += new System.EventHandler(this.bitmapToolStripMenuItem_Click);
            // 
            // scaleBarToolStripMenuItem
            // 
            this.scaleBarToolStripMenuItem.Name = "scaleBarToolStripMenuItem";
            this.scaleBarToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.scaleBarToolStripMenuItem.Text = "ScaleBar";
            this.scaleBarToolStripMenuItem.Click += new System.EventHandler(this.scaleBarToolStripMenuItem_Click);
            // 
            // measureToolStripMenuItem
            // 
            this.measureToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.measurePointToolStripMenuItem,
            this.measureDistanceToolStripMenuItem,
            this.measureAreaToolStripMenuItem,
            this.measureAngleToolStripMenuItem});
            this.measureToolStripMenuItem.Name = "measureToolStripMenuItem";
            this.measureToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.measureToolStripMenuItem.Text = "Measure";
            // 
            // measurePointToolStripMenuItem
            // 
            this.measurePointToolStripMenuItem.Name = "measurePointToolStripMenuItem";
            this.measurePointToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.measurePointToolStripMenuItem.Text = "MeasurePoint";
            this.measurePointToolStripMenuItem.Click += new System.EventHandler(this.measurePointToolStripMenuItem_Click);
            // 
            // measureDistanceToolStripMenuItem
            // 
            this.measureDistanceToolStripMenuItem.Name = "measureDistanceToolStripMenuItem";
            this.measureDistanceToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.measureDistanceToolStripMenuItem.Text = "MeasureDistance";
            this.measureDistanceToolStripMenuItem.Click += new System.EventHandler(this.measureDistanceToolStripMenuItem_Click);
            // 
            // measureAreaToolStripMenuItem
            // 
            this.measureAreaToolStripMenuItem.Name = "measureAreaToolStripMenuItem";
            this.measureAreaToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.measureAreaToolStripMenuItem.Text = "MeasureArea";
            this.measureAreaToolStripMenuItem.Click += new System.EventHandler(this.measureAreaToolStripMenuItem_Click);
            // 
            // measureAngleToolStripMenuItem
            // 
            this.measureAngleToolStripMenuItem.Name = "measureAngleToolStripMenuItem";
            this.measureAngleToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.measureAngleToolStripMenuItem.Text = "MeasureAngle";
            this.measureAngleToolStripMenuItem.Click += new System.EventHandler(this.measureAngleToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(123, 6);
            // 
            // propertyToolStripMenuItem
            // 
            this.propertyToolStripMenuItem.Name = "propertyToolStripMenuItem";
            this.propertyToolStripMenuItem.Size = new System.Drawing.Size(126, 22);
            this.propertyToolStripMenuItem.Text = "Property";
            this.propertyToolStripMenuItem.Click += new System.EventHandler(this.propertyToolStripMenuItem_Click);
            // 
            // mapToolStripMenuItem
            // 
            this.mapToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.backgroundColorToolStripMenuItem,
            this.changeMouseWheelDirectionToolStripMenuItem});
            this.mapToolStripMenuItem.Name = "mapToolStripMenuItem";
            this.mapToolStripMenuItem.Size = new System.Drawing.Size(43, 20);
            this.mapToolStripMenuItem.Text = "Map";
            // 
            // backgroundColorToolStripMenuItem
            // 
            this.backgroundColorToolStripMenuItem.Name = "backgroundColorToolStripMenuItem";
            this.backgroundColorToolStripMenuItem.Size = new System.Drawing.Size(241, 22);
            this.backgroundColorToolStripMenuItem.Text = "Background Color";
            this.backgroundColorToolStripMenuItem.Click += new System.EventHandler(this.backgroundColorToolStripMenuItem_Click);
            // 
            // changeMouseWheelDirectionToolStripMenuItem
            // 
            this.changeMouseWheelDirectionToolStripMenuItem.Name = "changeMouseWheelDirectionToolStripMenuItem";
            this.changeMouseWheelDirectionToolStripMenuItem.Size = new System.Drawing.Size(241, 22);
            this.changeMouseWheelDirectionToolStripMenuItem.Text = "Change MouseWheel Direction";
            this.changeMouseWheelDirectionToolStripMenuItem.Click += new System.EventHandler(this.changeMouseWheelDirectionToolStripMenuItem_Click);
            // 
            // zoomToolStripMenuItem
            // 
            this.zoomToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zoomFitToolStripMenuItem,
            this.zoomInToolStripMenuItem,
            this.zoomOutToolStripMenuItem,
            this.zoom1to1ToolStripMenuItem});
            this.zoomToolStripMenuItem.Name = "zoomToolStripMenuItem";
            this.zoomToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.zoomToolStripMenuItem.Text = "Zoom";
            // 
            // zoomFitToolStripMenuItem
            // 
            this.zoomFitToolStripMenuItem.Name = "zoomFitToolStripMenuItem";
            this.zoomFitToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.zoomFitToolStripMenuItem.Text = "ZoomFit";
            this.zoomFitToolStripMenuItem.Click += new System.EventHandler(this.zoomFitToolStripMenuItem_Click);
            // 
            // zoomInToolStripMenuItem
            // 
            this.zoomInToolStripMenuItem.Name = "zoomInToolStripMenuItem";
            this.zoomInToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.zoomInToolStripMenuItem.Text = "ZoomIn";
            this.zoomInToolStripMenuItem.Click += new System.EventHandler(this.zoomInToolStripMenuItem_Click);
            // 
            // zoomOutToolStripMenuItem
            // 
            this.zoomOutToolStripMenuItem.Name = "zoomOutToolStripMenuItem";
            this.zoomOutToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.zoomOutToolStripMenuItem.Text = "ZoomOut";
            this.zoomOutToolStripMenuItem.Click += new System.EventHandler(this.zoomOutToolStripMenuItem_Click);
            // 
            // zoom1to1ToolStripMenuItem
            // 
            this.zoom1to1ToolStripMenuItem.Name = "zoom1to1ToolStripMenuItem";
            this.zoom1to1ToolStripMenuItem.Size = new System.Drawing.Size(131, 22);
            this.zoom1to1ToolStripMenuItem.Text = "Zoom1to1";
            this.zoom1to1ToolStripMenuItem.Click += new System.EventHandler(this.zoom1to1ToolStripMenuItem_Click);
            // 
            // enhancementToolStripMenuItem
            // 
            this.enhancementToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wholeRegionMinMaxLinearToolStripMenuItem,
            this.wholeRegionMinMaxEqualizeToolStripMenuItem,
            this.wholeRegionMinMaxSqureRootToolStripMenuItem,
            this.toolStripSeparator3,
            this.wholeRegionGaussian95LinearToolStripMenuItem,
            this.wholeRegionGaussian95EqualizeToolStripMenuItem,
            this.wholeRegionGaussian95SquareRootToolStripMenuItem,
            this.toolStripSeparator4,
            this.wholeRegionGaussian98LinearToolStripMenuItem,
            this.wholeRegionGaussian98EqualizeToolStripMenuItem,
            this.wholeRegionGaussian98SquareRootToolStripMenuItem,
            this.toolStripSeparator5,
            this.visibleRegionMinMaxLinearToolStripMenuItem,
            this.visibleRegionMinMaxEqualizeToolStripMenuItem,
            this.visibleRegionMinMaxSquareRootToolStripMenuItem,
            this.toolStripSeparator6,
            this.visibleRegionGaussian95LinearToolStripMenuItem,
            this.visibleRegionGaussian95EqualizeToolStripMenuItem,
            this.visibleRegionGaussian95SquareRootToolStripMenuItem,
            this.toolStripSeparator7,
            this.visibleRegionGaussian98LinearToolStripMenuItem,
            this.visibleRegionGaussian98EqualizeToolStripMenuItem,
            this.visibleRegionGaussian98SquareRootToolStripMenuItem});
            this.enhancementToolStripMenuItem.Name = "enhancementToolStripMenuItem";
            this.enhancementToolStripMenuItem.Size = new System.Drawing.Size(92, 20);
            this.enhancementToolStripMenuItem.Text = "Enhancement";
            // 
            // wholeRegionMinMaxLinearToolStripMenuItem
            // 
            this.wholeRegionMinMaxLinearToolStripMenuItem.Name = "wholeRegionMinMaxLinearToolStripMenuItem";
            this.wholeRegionMinMaxLinearToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.wholeRegionMinMaxLinearToolStripMenuItem.Text = "Whole Region - MinMax - Linear";
            this.wholeRegionMinMaxLinearToolStripMenuItem.Click += new System.EventHandler(this.wholeRegionMinMaxLinearToolStripMenuItem_Click);
            // 
            // wholeRegionMinMaxEqualizeToolStripMenuItem
            // 
            this.wholeRegionMinMaxEqualizeToolStripMenuItem.Name = "wholeRegionMinMaxEqualizeToolStripMenuItem";
            this.wholeRegionMinMaxEqualizeToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.wholeRegionMinMaxEqualizeToolStripMenuItem.Text = "Whole Region - MinMax - Equalize";
            this.wholeRegionMinMaxEqualizeToolStripMenuItem.Click += new System.EventHandler(this.wholeRegionMinMaxEqualizeToolStripMenuItem_Click);
            // 
            // wholeRegionMinMaxSqureRootToolStripMenuItem
            // 
            this.wholeRegionMinMaxSqureRootToolStripMenuItem.Name = "wholeRegionMinMaxSqureRootToolStripMenuItem";
            this.wholeRegionMinMaxSqureRootToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.wholeRegionMinMaxSqureRootToolStripMenuItem.Text = "Whole Region - MinMax - SqureRoot";
            this.wholeRegionMinMaxSqureRootToolStripMenuItem.Click += new System.EventHandler(this.wholeRegionMinMaxSqureRootToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(306, 6);
            // 
            // wholeRegionGaussian95LinearToolStripMenuItem
            // 
            this.wholeRegionGaussian95LinearToolStripMenuItem.Name = "wholeRegionGaussian95LinearToolStripMenuItem";
            this.wholeRegionGaussian95LinearToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.wholeRegionGaussian95LinearToolStripMenuItem.Text = "Whole Region - Gaussian95% - Linear";
            this.wholeRegionGaussian95LinearToolStripMenuItem.Click += new System.EventHandler(this.wholeRegionGaussian95LinearToolStripMenuItem_Click);
            // 
            // wholeRegionGaussian95EqualizeToolStripMenuItem
            // 
            this.wholeRegionGaussian95EqualizeToolStripMenuItem.Name = "wholeRegionGaussian95EqualizeToolStripMenuItem";
            this.wholeRegionGaussian95EqualizeToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.wholeRegionGaussian95EqualizeToolStripMenuItem.Text = "Whole Region - Gaussian95% - Equalize";
            this.wholeRegionGaussian95EqualizeToolStripMenuItem.Click += new System.EventHandler(this.wholeRegionGaussian95EqualizeToolStripMenuItem_Click);
            // 
            // wholeRegionGaussian95SquareRootToolStripMenuItem
            // 
            this.wholeRegionGaussian95SquareRootToolStripMenuItem.Name = "wholeRegionGaussian95SquareRootToolStripMenuItem";
            this.wholeRegionGaussian95SquareRootToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.wholeRegionGaussian95SquareRootToolStripMenuItem.Text = "Whole Region - Gaussian95% - SquareRoot";
            this.wholeRegionGaussian95SquareRootToolStripMenuItem.Click += new System.EventHandler(this.wholeRegionGaussian95SquareRootToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(306, 6);
            // 
            // wholeRegionGaussian98LinearToolStripMenuItem
            // 
            this.wholeRegionGaussian98LinearToolStripMenuItem.Name = "wholeRegionGaussian98LinearToolStripMenuItem";
            this.wholeRegionGaussian98LinearToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.wholeRegionGaussian98LinearToolStripMenuItem.Text = "Whole Region - Gaussian98% - Linear";
            this.wholeRegionGaussian98LinearToolStripMenuItem.Click += new System.EventHandler(this.wholeRegionGaussian98LinearToolStripMenuItem_Click);
            // 
            // wholeRegionGaussian98EqualizeToolStripMenuItem
            // 
            this.wholeRegionGaussian98EqualizeToolStripMenuItem.Name = "wholeRegionGaussian98EqualizeToolStripMenuItem";
            this.wholeRegionGaussian98EqualizeToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.wholeRegionGaussian98EqualizeToolStripMenuItem.Text = "Whole Region - Gaussian98% - Equalize";
            this.wholeRegionGaussian98EqualizeToolStripMenuItem.Click += new System.EventHandler(this.wholeRegionGaussian98EqualizeToolStripMenuItem_Click);
            // 
            // wholeRegionGaussian98SquareRootToolStripMenuItem
            // 
            this.wholeRegionGaussian98SquareRootToolStripMenuItem.Name = "wholeRegionGaussian98SquareRootToolStripMenuItem";
            this.wholeRegionGaussian98SquareRootToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.wholeRegionGaussian98SquareRootToolStripMenuItem.Text = "Whole Region - Gaussian98% - SquareRoot";
            this.wholeRegionGaussian98SquareRootToolStripMenuItem.Click += new System.EventHandler(this.wholeRegionGaussian98SquareRootToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(306, 6);
            // 
            // visibleRegionMinMaxLinearToolStripMenuItem
            // 
            this.visibleRegionMinMaxLinearToolStripMenuItem.Name = "visibleRegionMinMaxLinearToolStripMenuItem";
            this.visibleRegionMinMaxLinearToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.visibleRegionMinMaxLinearToolStripMenuItem.Text = "Visible Region - MinMax - Linear";
            this.visibleRegionMinMaxLinearToolStripMenuItem.Click += new System.EventHandler(this.visibleRegionMinMaxLinearToolStripMenuItem_Click);
            // 
            // visibleRegionMinMaxEqualizeToolStripMenuItem
            // 
            this.visibleRegionMinMaxEqualizeToolStripMenuItem.Name = "visibleRegionMinMaxEqualizeToolStripMenuItem";
            this.visibleRegionMinMaxEqualizeToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.visibleRegionMinMaxEqualizeToolStripMenuItem.Text = "Visible Region - MinMax - Equalize";
            this.visibleRegionMinMaxEqualizeToolStripMenuItem.Click += new System.EventHandler(this.visibleRegionMinMaxEqualizeToolStripMenuItem_Click);
            // 
            // visibleRegionMinMaxSquareRootToolStripMenuItem
            // 
            this.visibleRegionMinMaxSquareRootToolStripMenuItem.Name = "visibleRegionMinMaxSquareRootToolStripMenuItem";
            this.visibleRegionMinMaxSquareRootToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.visibleRegionMinMaxSquareRootToolStripMenuItem.Text = "Visible Region - MinMax - SquareRoot";
            this.visibleRegionMinMaxSquareRootToolStripMenuItem.Click += new System.EventHandler(this.visibleRegionMinMaxSquareRootToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(306, 6);
            // 
            // visibleRegionGaussian95LinearToolStripMenuItem
            // 
            this.visibleRegionGaussian95LinearToolStripMenuItem.Name = "visibleRegionGaussian95LinearToolStripMenuItem";
            this.visibleRegionGaussian95LinearToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.visibleRegionGaussian95LinearToolStripMenuItem.Text = "Visible Region - Gaussian95% - Linear";
            this.visibleRegionGaussian95LinearToolStripMenuItem.Click += new System.EventHandler(this.visibleRegionGaussian95LinearToolStripMenuItem_Click);
            // 
            // visibleRegionGaussian95EqualizeToolStripMenuItem
            // 
            this.visibleRegionGaussian95EqualizeToolStripMenuItem.Name = "visibleRegionGaussian95EqualizeToolStripMenuItem";
            this.visibleRegionGaussian95EqualizeToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.visibleRegionGaussian95EqualizeToolStripMenuItem.Text = "Visible Region - Gaussian95% - Equalize";
            this.visibleRegionGaussian95EqualizeToolStripMenuItem.Click += new System.EventHandler(this.visibleRegionGaussian95EqualizeToolStripMenuItem_Click);
            // 
            // visibleRegionGaussian95SquareRootToolStripMenuItem
            // 
            this.visibleRegionGaussian95SquareRootToolStripMenuItem.Name = "visibleRegionGaussian95SquareRootToolStripMenuItem";
            this.visibleRegionGaussian95SquareRootToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.visibleRegionGaussian95SquareRootToolStripMenuItem.Text = "Visible Region - Gaussian95% - SquareRoot";
            this.visibleRegionGaussian95SquareRootToolStripMenuItem.Click += new System.EventHandler(this.visibleRegionGaussian95SquareRootToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(306, 6);
            // 
            // visibleRegionGaussian98LinearToolStripMenuItem
            // 
            this.visibleRegionGaussian98LinearToolStripMenuItem.Name = "visibleRegionGaussian98LinearToolStripMenuItem";
            this.visibleRegionGaussian98LinearToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.visibleRegionGaussian98LinearToolStripMenuItem.Text = "Visible Region - Gaussian98% - Linear";
            this.visibleRegionGaussian98LinearToolStripMenuItem.Click += new System.EventHandler(this.visibleRegionGaussian98LinearToolStripMenuItem_Click);
            // 
            // visibleRegionGaussian98EqualizeToolStripMenuItem
            // 
            this.visibleRegionGaussian98EqualizeToolStripMenuItem.Name = "visibleRegionGaussian98EqualizeToolStripMenuItem";
            this.visibleRegionGaussian98EqualizeToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.visibleRegionGaussian98EqualizeToolStripMenuItem.Text = "Visible Region - Gaussian98% - Equalize";
            this.visibleRegionGaussian98EqualizeToolStripMenuItem.Click += new System.EventHandler(this.visibleRegionGaussian98EqualizeToolStripMenuItem_Click);
            // 
            // visibleRegionGaussian98SquareRootToolStripMenuItem
            // 
            this.visibleRegionGaussian98SquareRootToolStripMenuItem.Name = "visibleRegionGaussian98SquareRootToolStripMenuItem";
            this.visibleRegionGaussian98SquareRootToolStripMenuItem.Size = new System.Drawing.Size(309, 22);
            this.visibleRegionGaussian98SquareRootToolStripMenuItem.Text = "Visible Region - Gaussian98% - SquareRoot";
            this.visibleRegionGaussian98SquareRootToolStripMenuItem.Click += new System.EventHandler(this.visibleRegionGaussian98SquareRootToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabelMouseCoord,
            this.toolStripStatusLabelWorldCoord});
            this.statusStrip.Location = new System.Drawing.Point(0, 368);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(475, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabelMouseCoord
            // 
            this.toolStripStatusLabelMouseCoord.Name = "toolStripStatusLabelMouseCoord";
            this.toolStripStatusLabelMouseCoord.Size = new System.Drawing.Size(50, 17);
            this.toolStripStatusLabelMouseCoord.Text = "Mouse :";
            // 
            // toolStripStatusLabelWorldCoord
            // 
            this.toolStripStatusLabelWorldCoord.Name = "toolStripStatusLabelWorldCoord";
            this.toolStripStatusLabelWorldCoord.Size = new System.Drawing.Size(25, 17);
            this.toolStripStatusLabelWorldCoord.Text = "W :";
            // 
            // nxImageView1
            // 
            this.nxImageView1.BackColor = System.Drawing.SystemColors.Control;
            this.nxImageView1.BackgroundColor = System.Drawing.Color.Black;
            this.nxImageView1.BackgroundMapAlpha = 1F;
            this.nxImageView1.BackgroundMapBrightness = 1F;
            this.nxImageView1.BackgroundMapContrast = 1F;
            this.nxImageView1.BackgroundMapInterpolPixel = false;
            this.nxImageView1.BackgroundMapSaturation = 1F;
            this.nxImageView1.BackgroundMapVisible = false;
            this.nxImageView1.Controls.Add(this.nxImageLayerComposites);
            this.nxImageView1.Controls.Add(this.nxImageLayerVectorEditor);
            this.nxImageView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nxImageView1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.nxImageView1.InverseMouseButton = false;
            this.nxImageView1.InverseMouseWheel = false;
            this.nxImageView1.Location = new System.Drawing.Point(0, 24);
            this.nxImageView1.Name = "nxImageView1";
            this.nxImageView1.Size = new System.Drawing.Size(475, 366);
            this.nxImageView1.SR = null;
            this.nxImageView1.StereoColorMaskL = Pixoneer.NXDL.NGR.eStereoColorMask.Blue;
            this.nxImageView1.StereoColorMaskR = Pixoneer.NXDL.NGR.eStereoColorMask.Blue;
            this.nxImageView1.StereoFirstLineAsLeft = false;
            this.nxImageView1.StereoPixelOffset = null;
            this.nxImageView1.StereoPixelOffsetX = 0D;
            this.nxImageView1.StereoPixelOffsetY = 0D;
            this.nxImageView1.StereoSwap = false;
            this.nxImageView1.StereoViewType = Pixoneer.NXDL.NGR.eStereoType.None;
            this.nxImageView1.TabIndex = 0;
            this.nxImageView1.WorldRounding = false;
            this.nxImageView1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.nxImageView1_MouseMove);
            // 
            // nxImageLayerComposites
            // 
            this.nxImageLayerComposites.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nxImageLayerComposites.LayerVisible = true;
            this.nxImageLayerComposites.Location = new System.Drawing.Point(20, 73);
            this.nxImageLayerComposites.Name = "nxImageLayerComposites";
            this.nxImageLayerComposites.ShowBoundary = false;
            this.nxImageLayerComposites.ShowPixelBased = false;
            this.nxImageLayerComposites.Size = new System.Drawing.Size(145, 30);
            this.nxImageLayerComposites.TabIndex = 2;
            this.nxImageLayerComposites.Visible = false;
            // 
            // nxImageLayerVectorEditor
            // 
            this.nxImageLayerVectorEditor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nxImageLayerVectorEditor.BoundColorBack = System.Drawing.Color.Transparent;
            this.nxImageLayerVectorEditor.BoundColorFore = System.Drawing.Color.White;
            this.nxImageLayerVectorEditor.BoundColorLine = System.Drawing.Color.Red;
            this.nxImageLayerVectorEditor.BoundLineThick = 0D;
            this.nxImageLayerVectorEditor.BoundStyleFill = Pixoneer.NXDL.NVC.eXvcObjFillStyle.User;
            this.nxImageLayerVectorEditor.BoundStyleLine = Pixoneer.NXDL.NVC.eXvcObjLineStyle.User;
            this.nxImageLayerVectorEditor.CreateBound = false;
            this.nxImageLayerVectorEditor.Editable = false;
            this.nxImageLayerVectorEditor.LayerVisible = true;
            this.nxImageLayerVectorEditor.Location = new System.Drawing.Point(20, 40);
            this.nxImageLayerVectorEditor.Name = "nxImageLayerVectorEditor";
            this.nxImageLayerVectorEditor.SelectableObject = false;
            this.nxImageLayerVectorEditor.Size = new System.Drawing.Size(145, 30);
            this.nxImageLayerVectorEditor.TabIndex = 0;
            this.nxImageLayerVectorEditor.UsableKeyboard = false;
            this.nxImageLayerVectorEditor.UsableLayerDisplayOrder = false;
            this.nxImageLayerVectorEditor.Visible = false;
            this.nxImageLayerVectorEditor.OnObjectCreated += new Pixoneer.NXDL.NXImage.NXImageLayerVectorEditor_Event_Edit(this.nxImageLayerVectorEditor_OnObjectCreated);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 390);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.nxImageView1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.Text = "Vector Editor";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.nxImageView1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private Pixoneer.NXDL.NXImage.NXImageView nxImageView1;
        private Pixoneer.NXDL.NXImage.NXImageLayerVectorEditor nxImageLayerVectorEditor;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem vectorObjectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polylineToolStripMenuItem;
        private Pixoneer.NXDL.NXImage.NXImageLayerComposites nxImageLayerComposites;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openRasterToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem polygonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pointToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem textToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem measureToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem measurePointToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem textBoxToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelMouseCoord;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabelWorldCoord;
        private System.Windows.Forms.ToolStripMenuItem measureDistanceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem measureAreaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem propertyToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem openXvcVectorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveXvcVectorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lineToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ellipseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rectangleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backgroundColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pixoneerXVMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem externalVectorFormatToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem measureAngleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bitmapToolStripMenuItem;
        //private DevExpress.XtraBars.PopupMenu popupMenu1;
        //private DevExpress.XtraBars.BarManager barManager1;
        //private DevExpress.XtraBars.BarSubItem barSubItem1;
        //private DevExpress.XtraBars.BarSubItem barSubItem2;
        //private DevExpress.XtraBars.BarSubItem barSubItem3;
        //private DevExpress.XtraBars.BarSubItem barSubItem4;
        //private DevExpress.XtraBars.BarDockControl barDockControlTop;
        //private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        //private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        //private DevExpress.XtraBars.BarDockControl barDockControlRight;
        //private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        //private DevExpress.XtraBars.BarButtonItem barButtonFirst;
        //private DevExpress.XtraBars.BarButtonItem barButtonFront;
        //private DevExpress.XtraBars.BarButtonItem barButtonLast;
        //private DevExpress.XtraBars.BarButtonItem barButtonBack;
        //private DevExpress.XtraBars.BarButtonItem barButtonProperty;
        //private DevExpress.XtraBars.BarButtonItem barButtonGroup;
        //private DevExpress.XtraBars.BarButtonItem barButtonUnGroup;
        private System.Windows.Forms.ToolStripMenuItem zoomToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zoomFitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zoomInToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zoomOutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zoom1to1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enhancementToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wholeRegionMinMaxLinearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wholeRegionMinMaxEqualizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wholeRegionMinMaxSqureRootToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wholeRegionGaussian95LinearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wholeRegionGaussian95EqualizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wholeRegionGaussian95SquareRootToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wholeRegionGaussian98LinearToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem wholeRegionGaussian98EqualizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem wholeRegionGaussian98SquareRootToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem visibleRegionMinMaxLinearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visibleRegionMinMaxEqualizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visibleRegionMinMaxSquareRootToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem visibleRegionGaussian95LinearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visibleRegionGaussian95EqualizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visibleRegionGaussian95SquareRootToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem visibleRegionGaussian98LinearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visibleRegionGaussian98EqualizeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem visibleRegionGaussian98SquareRootToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scaleBarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem changeMouseWheelDirectionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openExternalVectorToolStripMenuItem;
    }
}

