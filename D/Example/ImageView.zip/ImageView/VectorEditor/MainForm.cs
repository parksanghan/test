﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Pixoneer.NXDL.NRS;
using Pixoneer.NXDL.NIO;
using Pixoneer.NXDL.NVC;
using Pixoneer.NXDL;

namespace VectorEditor
{
    public partial class MainForm : Form
    {
        public XRasterIO m_RasterIO = null;
        public XVectorIO m_VectorIO = null;
        public XRSLoadFile m_RasterFile = null;

        public MainForm()
        {
            InitializeComponent();
            nxImageLayerVectorEditor.Editable = true;

            String StrError;
            m_RasterIO = new XRasterIO();
            if (m_RasterIO.Initialize(out StrError) == false)
                MessageBox.Show(StrError);

            m_VectorIO = new XVectorIO();
            if (m_VectorIO.Initialize(out StrError) == false)
                MessageBox.Show(StrError);

            this.nxImageLayerVectorEditor.OnPreTranslateMessage += NXImageLayerVectorEditor_OnPreTranslateMessage;

        }

        private bool NXImageLayerVectorEditor_OnPreTranslateMessage(Pixoneer.NXDL.NXImage.NXImageLayerVectorEditor sender, ref Message m)
        {
            if (m.Msg == XWndMsg.XWM_LBUTTONDBLCLK)
            {
                double sx = Pixoneer.NXDL.XWndMsg.GetLowValue(m.LParam);
                double sy = Pixoneer.NXDL.XWndMsg.GetHighValue(m.LParam);

                Pixoneer.NXDL.XVertex2d vtWorld = this.nxImageView1.ScreenToWorld(new Pixoneer.NXDL.XVertex2d(sx, sy));
                Pixoneer.NXDL.XVertex3d vtWorldZ = new Pixoneer.NXDL.XVertex3d(vtWorld.x, vtWorld.y, 0.0);

                Pixoneer.NXDL.XHitFlag hitFlag = new Pixoneer.NXDL.XHitFlag();
                XvcObj selObj = this.nxImageLayerVectorEditor.HitTest(vtWorldZ, ref hitFlag);
                if (selObj != null)
                {
                    int numInfo = selObj.NumProperties;
                    for (int i = 0; i < numInfo; i++)
                    {
                        string name = selObj.GetPropertyNameAt(i);
                        string val = selObj.GetPropertyValueAt(i);

                        System.Diagnostics.Debug.WriteLine(i.ToString() + " : " + name + " : " + val);
                    }
                }
            }

            return false;
        }

        private void openRasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "XDM file(*.xdm)|*.XDM||";
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() != DialogResult.OK) return;

            String strError;
            XRSLoadFile xrsFile = m_RasterIO.LoadFile(openFileDialog.FileName, out strError, false, eIOCreateXLDMode.All_NoMsg);
            if (xrsFile == null) return;

            m_RasterFile = xrsFile;

            XRSSaveFile xrsFileSave = new XRSSaveFile();
            XDMBand saveBand = xrsFile.GetBandAt(0);
            xrsFileSave.AddBand(ref saveBand);

            nxImageView1.SR = xrsFile.SR;
            nxImageLayerComposites.Lock();

            // get XDMCompManager and reset list
            XDMCompManager xdmCompManager = nxImageLayerComposites.GetXDMCompManager();
            for (int i = 0; i < xdmCompManager.NumComp; i++)
            {
                XDMComposite comp = xdmCompManager.GetXDMCompositeAt(i);
                comp.Dispose();
            }
            xdmCompManager.RemoveXDMCompositeAll();

            // XDMComposite를 생성하고 Band와 도시 방법을 설정
            XDMComposite newComp = new XDMComposite();

            newComp.Mode = eCompMode.RGB;
            XDMBand bandR = null, bandG = null, bandB = null;
            bandR = m_RasterFile.GetBandAt(0);
            bandG = m_RasterFile.GetBandAt(1);
            bandB = m_RasterFile.GetBandAt(2);

            String bandName0 = bandR.BandName;

            if (bandR != null) newComp.SetBand(ref bandR, 2);
            if (bandG != null) newComp.SetBand(ref bandG, 1);
            if (bandB != null) newComp.SetBand(ref bandB, 0);
            for (int i = 0; i < 3; i++)
            {
                newComp.SetCutType(eCompCutType.Minmax, i);
                newComp.SetStretchCoverage(eCompStretchCoverage.Band, i);
                newComp.SetStretchType(eCompStretchType.Linear, i);
                newComp.SetTransparentValue(0.0, i);
            }
            newComp.ApplyTransparent = true;

            xdmCompManager.AddXDMComposite(ref newComp);
            nxImageLayerComposites.ZoomFit();
            nxImageLayerComposites.Invalidate();
            nxImageLayerComposites.UnLock();

        }

        private void polylineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.Polyline, null);
        }

        private void polygonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.Polygon, null);
        }

        private void pointToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XvcObj obj = nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.Point, null);
            if (obj != null)
            {
                ((XvcPoint)obj).PointType = eXvcPointType.CirclePoint;
                ((XvcPoint)obj).PointSize = 1;
            }
        }

        private void textToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.Text, null);
        }

        private void measurePointToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.MeasurePoint, null);
        }

        private void textBoxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.Textbox, null);
        }

        private void scaleBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XvcObj obj = nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.Scalebar, null);
            if (obj != null)
            {
                ((XvcScaleBar)obj).ScaleBarType = eXvcScaleBarType.ScaleBarType1;
            }
        }

        private void bitmapToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XvcObj obj = nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.Bitmap, null);
            if (obj != null)
            {
                string strError = string.Empty;
                string strFilePath = System.IO.Path.Combine(Pixoneer.NXDL.Xfn.GetResourcePath(), "indexmap.bmp");
                ((XvcBitmap)obj).SetBitmapName("BITMAP_INDEXMAP");
                ((XvcBitmap)obj).SetImage(strFilePath, ref strError);
                ((XvcBitmap)obj).StyleLine = eXvcObjLineStyle.Null;
                ((XvcBitmap)obj).IsRotatable = false;
            }
        }

        private void nxImageView1_MouseMove(object sender, MouseEventArgs e)
        {
            Pixoneer.NXDL.XVertex2d scr_pos = new Pixoneer.NXDL.XVertex2d();
            scr_pos.x = (double)e.X;
            scr_pos.y = (double)e.Y;

            Pixoneer.NXDL.XVertex2d pos = nxImageView1.ScreenToWorld(scr_pos);

            string wxs = "", wys = "";
            Pixoneer.NXDL.NCC.XSpatialReference sr = nxImageView1.SR;
            if (sr.IsGeographic())
            {
                wxs = pos.x.ToString("f8");
                wys = pos.y.ToString("f8");
            }
            else
            {
                wxs = pos.x.ToString("f4");
                wys = pos.y.ToString("f4");
            }

            toolStripStatusLabelWorldCoord.Text = "World : " + wxs + ", " + wys;
            toolStripStatusLabelMouseCoord.Text = "Mouse : " + e.X + ", " + e.Y;
        }

        private void measureDistanceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.MeasureDist, null);
        }

        private void measureAreaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.MeasureArea, null);
        }

        private bool nxImageLayerVectorEditor_OnObjectCreated(XvcObj Obj)
        {
            if (Obj == null)
            {
                return default(bool);
            }

            if (Obj.Type == eXvcObjType.Bitmap)
            { 
                if (((XvcBitmap)Obj).GetBitmapName() == "BITMAP_INDEXMAP")
                {
                    //BOUND2=124.16, 37.58, 130.81, 43.17
                    ((Pixoneer.NXDL.NVC.XvcBitmap)Obj).SetIndexMapBound(124.16, 37.58, 130.81, 43.17);
                    ((Pixoneer.NXDL.NVC.XvcBitmap)Obj).ColorLine = System.Drawing.Color.FromArgb(255, 255, 0, 0);
                    ((XvcBitmap)Obj).RotAngle = 0;
                }
            }
            return default(bool);
        }

        private bool NxImageLayerVectorEditor_OnObjectEditOver(Pixoneer.NXDL.NVC.XvcObj Obj, bool bEdited)
        {
            if (Obj == null) return false;

            eXvcObjType type = Obj.Type;
            if (type == eXvcObjType.Text)
            {
                InputText InputTextDlg = new InputText();
                InputTextDlg.m_strText = ((XvcText)Obj).Text;

                if (InputTextDlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    ((XvcText)Obj).Text = InputTextDlg.m_strText;
                }
            }

            return default(bool);
        }


        private void propertyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            XvcObj Obj = nxImageLayerVectorEditor.GetSelectedObj();
            if (Obj == null) return;

            ChangeProperty(Obj);
        }

        private void lineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.Line, null);
        }

        private void ellipseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.Ellipse, null);
        }

        private void rectangleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.Rectangle, null);
        }

        private void measureAngleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageLayerVectorEditor.CreateNewOBJ(Pixoneer.NXDL.NVC.eXvcObjType.MeasureAngle, null);
        }

        private void openXvcVectorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "XvcBase Files|*.xvml";
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() != DialogResult.OK) return;

            String strError;
            XvcBase vcBase = new XvcBase();
            bool bres = vcBase.LoadFile(openFileDialog.FileName, out strError, null);

            if (bres)
                MessageBox.Show("Vector File Open Succeed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            else
            {
                MessageBox.Show("Vector File Open Failed", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            nxImageLayerVectorEditor.SetEditBase(vcBase);
            nxImageView1.RefreshScreen();
        }

        private void pixoneerXVMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Pixoneer.NXDL.NVC.XvcBase vcbase = nxImageLayerVectorEditor.GetEditBase();
            if (vcbase == null) return;

            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Title = "Save XvcBase File";
            dialog.DefaultExt = "xvml";
            dialog.Filter = "XvcBase Files|*.xvml";

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                String strError;
                bool bres = vcbase.SaveFile(dialog.FileName, out strError, null);

                if (bres)
                    MessageBox.Show("Vector File Save Succeed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Vector File Save Failed", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public void ChangeProperty(XvcObj Obj)
        {
            if (Obj == null)
            {
                return;
            }

            eXvcObjType type = Obj.Type;

            PropertyXvcObj propertyDlg = new PropertyXvcObj();
            propertyDlg.m_strObjType = type.ToString();
            propertyDlg.m_nID = Obj.ID;
            propertyDlg.m_strName = Obj.Name;
            propertyDlg.m_crBack = Obj.ColorBack;
            propertyDlg.m_crFore = Obj.ColorFore;
            propertyDlg.m_crLine = Obj.ColorLine;
            propertyDlg.m_dblThick = Obj.GetThick();
            propertyDlg.m_StyleFill = Obj.StyleFill;
            propertyDlg.m_StyleLine = Obj.StyleLine;
            propertyDlg.m_crText = Obj.ColorText;

            if (type == eXvcObjType.Text)
            {
                propertyDlg.m_dblFontSize = ((XvcText)Obj).FontSize;
                propertyDlg.m_strFontName = ((XvcText)Obj).FontName;
                propertyDlg.m_bBold = ((XvcText)Obj).Bold;
                propertyDlg.m_bUnderline = ((XvcText)Obj).Underline;
                propertyDlg.m_bItalic = ((XvcText)Obj).Italic;
                propertyDlg.m_bStrikeOut = ((XvcText)Obj).StrikeOut;
            }
            else if (type == eXvcObjType.Line)
            {
                propertyDlg.m_LineStartShape = ((XvcLine)Obj).StartShapeType;
                propertyDlg.m_LineEndShape = ((XvcLine)Obj).EndShapeType;
            }

            System.Collections.ArrayList selObjs = new System.Collections.ArrayList();
            System.Collections.ArrayList copyObjs = new System.Collections.ArrayList();
            nxImageLayerVectorEditor.GetSelectedObjs(ref selObjs);
            XvcObj newObj = Xvc.CreateCloneObj(Obj);
            copyObjs.Add(newObj);

            if (propertyDlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                Obj.ID = propertyDlg.m_nID;
                Obj.Name = propertyDlg.m_strName;
                Obj.ColorBack = propertyDlg.m_crBack;
                Obj.ColorFore = propertyDlg.m_crFore;
                Obj.ColorLine = propertyDlg.m_crLine;
                Obj.SetThick(propertyDlg.m_dblThick);
                Obj.StyleFill = propertyDlg.m_StyleFill;
                Obj.StyleLine = propertyDlg.m_StyleLine;
                Obj.ColorText = propertyDlg.m_crText;

                if (type == eXvcObjType.Text)
                {
                    XvcText text = (XvcText)Obj;
                    text.FontSize = propertyDlg.m_dblFontSize;
                    text.FontName = propertyDlg.m_strFontName;
                    text.Bold = propertyDlg.m_bBold;
                    text.Underline = propertyDlg.m_bUnderline;
                    text.Italic = propertyDlg.m_bItalic;
                    text.StrikeOut = propertyDlg.m_bStrikeOut;
                }
                else if (type == eXvcObjType.Line)
                {
                    ((XvcLine)Obj).StartShapeType = propertyDlg.m_LineStartShape;
                    ((XvcLine)Obj).EndShapeType = propertyDlg.m_LineEndShape;
                }

                nxImageLayerVectorEditor.Modify(ref copyObjs, ref selObjs);
                nxImageLayerVectorEditor.SelectObject(ref selObjs);
                this.nxImageView1.RefreshScreen();
            }
        }

        private void backgroundColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = nxImageView1.BackgroundColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                nxImageView1.BackgroundColor = dlg.Color;
                nxImageView1.RefreshScreen();
            }
        }

        private void changeMouseWheelDirectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageView1.InverseMouseWheel = !nxImageView1.InverseMouseWheel;
        }

        private void zoomFitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageView1.ZoomFit();
        }

        private void zoomInToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageView1.Zoom(2.0);
        }

        private void zoomOutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageView1.Zoom(-2.0);
        }

        private void zoom1to1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            nxImageView1.ZoomOneToOne();
        }

        private void wholeRegionMinMaxLinearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Band, eCompCutType.Minmax, eCompStretchType.Linear);
        }

        private void wholeRegionMinMaxEqualizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Band, eCompCutType.Minmax, eCompStretchType.Histequal);
        }

        private void wholeRegionMinMaxSqureRootToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Band, eCompCutType.Minmax, eCompStretchType.SqrRoot);
        }

        private void wholeRegionGaussian95LinearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Band, eCompCutType.Ct95, eCompStretchType.Linear);
        }

        private void wholeRegionGaussian95EqualizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Band, eCompCutType.Ct95, eCompStretchType.Histequal);
        }

        private void wholeRegionGaussian95SquareRootToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Band, eCompCutType.Ct95, eCompStretchType.SqrRoot);
        }

        private void wholeRegionGaussian98LinearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Band, eCompCutType.Ct98, eCompStretchType.Linear);
        }

        private void wholeRegionGaussian98EqualizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Band, eCompCutType.Ct98, eCompStretchType.Histequal);
        }

        private void wholeRegionGaussian98SquareRootToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Band, eCompCutType.Ct98, eCompStretchType.SqrRoot);
        }

        private void visibleRegionMinMaxLinearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Visible, eCompCutType.Minmax, eCompStretchType.Linear);
        }

        private void visibleRegionMinMaxEqualizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Visible, eCompCutType.Minmax, eCompStretchType.Histequal);
        }

        private void visibleRegionMinMaxSquareRootToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Visible, eCompCutType.Minmax, eCompStretchType.SqrRoot);
        }

        private void visibleRegionGaussian95LinearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Visible, eCompCutType.Ct95, eCompStretchType.Linear);
        }

        private void visibleRegionGaussian95EqualizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Visible, eCompCutType.Ct95, eCompStretchType.Histequal);
        }

        private void visibleRegionGaussian95SquareRootToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Visible, eCompCutType.Ct95, eCompStretchType.SqrRoot);
        }

        private void visibleRegionGaussian98LinearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Visible, eCompCutType.Ct98, eCompStretchType.Linear);
        }

        private void visibleRegionGaussian98EqualizeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Visible, eCompCutType.Ct98, eCompStretchType.Histequal);
        }

        private void visibleRegionGaussian98SquareRootToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetHistoEnhancement(eCompStretchCoverage.Visible, eCompCutType.Ct98, eCompStretchType.SqrRoot);
        }

        private void SetHistoEnhancement(eCompStretchCoverage stretchCov, eCompCutType cutType, eCompStretchType stretchType)
        {
            XDMCompManager compMng = nxImageLayerComposites.GetXDMCompManager();
            if (compMng == null) return;

            nxImageLayerComposites.Lock();

            for (int i = 0; i < compMng.NumComp; i++)
            {
                XDMComposite comp = compMng.GetXDMCompositeAt(i);
                if (comp == null) continue;

                if (comp.Mode == eCompMode.Gray)
                {
                    comp.SetStretchCoverage(stretchCov, 0);
                    comp.SetCutType(cutType, 0);

                    comp.SetIntensity000(0, 0);
                    comp.SetIntensity255(255, 0);

                    comp.SetStretchType(stretchType, 0);
                }
                else if (comp.Mode == eCompMode.RGB)
                {
                    for (int b = 0; b < 3; b++)
                    {
                        comp.SetStretchCoverage(stretchCov, b);
                        comp.SetCutType(cutType, b);

                        comp.SetIntensity000(0, b);
                        comp.SetIntensity255(255, b);
                        comp.SetStretchType(stretchType, b);
                    }
                }
            }

            nxImageLayerComposites.UnLock();

            nxImageLayerComposites.Invalidate();
        }

        private void openExternalVectorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = m_VectorIO.GetFiltersForLoad();
            openFileDialog.RestoreDirectory = true;
            if (openFileDialog.ShowDialog() != DialogResult.OK) return;

            Pixoneer.NXDL.NCC.XSpatialReference srIn = new Pixoneer.NXDL.NCC.XSpatialReference();
            srIn.importFromEPSG(4326);

            String strError = "";
            XvcBase vectorFile = m_VectorIO.LoadFile(openFileDialog.FileName, out strError, ref srIn);
            if (vectorFile == null) return;

            vectorFile.CalcRange();

            double minx = 0.0, maxx = 0.0, miny = 0.0, maxy = 0.0;
            vectorFile.GetBoundRect(ref minx, ref maxx, ref miny, ref maxy);
            nxImageLayerVectorEditor.SetEditBase(vectorFile);
            nxImageView1.ZoomFitRect(minx, miny, maxx, maxy);
            nxImageView1.RefreshScreen();
        }
    }
}
