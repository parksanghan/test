﻿namespace VectorEditor
{
    partial class PropertyXvcObj
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PropertyXvcObj));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxID = new System.Windows.Forms.TextBox();
            this.textBoxName = new System.Windows.Forms.TextBox();
            this.textBoxFontSize = new System.Windows.Forms.TextBox();
            this.comboBoxStyleLine = new System.Windows.Forms.ComboBox();
            this.comboBoxStyleFill = new System.Windows.Forms.ComboBox();
            this.textBoxThick = new System.Windows.Forms.TextBox();
            this.buttonOK = new System.Windows.Forms.Button();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.textBoxObjType = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.buttonColorLine = new System.Windows.Forms.Button();
            this.buttonColorFore = new System.Windows.Forms.Button();
            this.buttonColorBack = new System.Windows.Forms.Button();
            this.buttonColorText = new System.Windows.Forms.Button();
            this.checkBoxUnderline = new System.Windows.Forms.CheckBox();
            this.checkBoxItalic = new System.Windows.Forms.CheckBox();
            this.checkBoxStrikeOut = new System.Windows.Forms.CheckBox();
            this.checkBoxBold = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.buttonFontText = new System.Windows.Forms.Button();
            this.textBoxObjText = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBoxLineStartShape = new System.Windows.Forms.ComboBox();
            this.comboBoxLineEndShape = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(52, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "Name :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "LineColor :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(8, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "ForeColor :";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "BackColor :";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(10, 166);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 12);
            this.label6.TabIndex = 5;
            this.label6.Text = "LineStyle :";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 192);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(57, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "FillStyle :";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "TextColor :";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 83);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 12);
            this.label9.TabIndex = 8;
            this.label9.Text = "FontSize :";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(31, 220);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 12);
            this.label10.TabIndex = 9;
            this.label10.Text = "Thick :";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // textBoxID
            // 
            this.textBoxID.Location = new System.Drawing.Point(85, 30);
            this.textBoxID.Name = "textBoxID";
            this.textBoxID.Size = new System.Drawing.Size(98, 21);
            this.textBoxID.TabIndex = 10;
            // 
            // textBoxName
            // 
            this.textBoxName.Location = new System.Drawing.Point(85, 55);
            this.textBoxName.Name = "textBoxName";
            this.textBoxName.Size = new System.Drawing.Size(98, 21);
            this.textBoxName.TabIndex = 11;
            // 
            // textBoxFontSize
            // 
            this.textBoxFontSize.Location = new System.Drawing.Point(89, 77);
            this.textBoxFontSize.Name = "textBoxFontSize";
            this.textBoxFontSize.Size = new System.Drawing.Size(98, 21);
            this.textBoxFontSize.TabIndex = 16;
            this.textBoxFontSize.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // comboBoxStyleLine
            // 
            this.comboBoxStyleLine.FormattingEnabled = true;
            this.comboBoxStyleLine.Items.AddRange(new object[] {
            "Solid",
            "Dash",
            "Dot",
            "DashDot",
            "DashDotDot",
            "Null"});
            this.comboBoxStyleLine.Location = new System.Drawing.Point(85, 163);
            this.comboBoxStyleLine.Name = "comboBoxStyleLine";
            this.comboBoxStyleLine.Size = new System.Drawing.Size(98, 20);
            this.comboBoxStyleLine.TabIndex = 17;
            // 
            // comboBoxStyleFill
            // 
            this.comboBoxStyleFill.FormattingEnabled = true;
            this.comboBoxStyleFill.Items.AddRange(new object[] {
            "Solid",
            "Hollow",
            "BackwardDiagonal",
            "Cross",
            "DiagonalCross",
            "FowardDiagonal",
            "Horizontal",
            "Vertical",
            "Screen"});
            this.comboBoxStyleFill.Location = new System.Drawing.Point(85, 189);
            this.comboBoxStyleFill.Name = "comboBoxStyleFill";
            this.comboBoxStyleFill.Size = new System.Drawing.Size(98, 20);
            this.comboBoxStyleFill.TabIndex = 18;
            // 
            // textBoxThick
            // 
            this.textBoxThick.Location = new System.Drawing.Point(85, 215);
            this.textBoxThick.Name = "textBoxThick";
            this.textBoxThick.Size = new System.Drawing.Size(98, 21);
            this.textBoxThick.TabIndex = 19;
            this.textBoxThick.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // buttonOK
            // 
            this.buttonOK.Location = new System.Drawing.Point(303, 333);
            this.buttonOK.Name = "buttonOK";
            this.buttonOK.Size = new System.Drawing.Size(50, 23);
            this.buttonOK.TabIndex = 20;
            this.buttonOK.Text = "OK";
            this.buttonOK.UseVisualStyleBackColor = true;
            this.buttonOK.Click += new System.EventHandler(this.buttonOK_Click);
            // 
            // buttonCancel
            // 
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Location = new System.Drawing.Point(359, 333);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(67, 23);
            this.buttonCancel.TabIndex = 21;
            this.buttonCancel.Text = "Cancel";
            this.buttonCancel.UseVisualStyleBackColor = true;
            // 
            // textBoxObjType
            // 
            this.textBoxObjType.Location = new System.Drawing.Point(85, 3);
            this.textBoxObjType.Name = "textBoxObjType";
            this.textBoxObjType.ReadOnly = true;
            this.textBoxObjType.Size = new System.Drawing.Size(98, 21);
            this.textBoxObjType.TabIndex = 23;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(34, 7);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 12);
            this.label11.TabIndex = 22;
            this.label11.Text = "Type :";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // buttonColorLine
            // 
            this.buttonColorLine.Location = new System.Drawing.Point(86, 80);
            this.buttonColorLine.Name = "buttonColorLine";
            this.buttonColorLine.Size = new System.Drawing.Size(98, 23);
            this.buttonColorLine.TabIndex = 24;
            this.buttonColorLine.Text = "...";
            this.buttonColorLine.UseVisualStyleBackColor = true;
            this.buttonColorLine.Click += new System.EventHandler(this.buttonColorLine_Click);
            // 
            // buttonColorFore
            // 
            this.buttonColorFore.Location = new System.Drawing.Point(86, 106);
            this.buttonColorFore.Name = "buttonColorFore";
            this.buttonColorFore.Size = new System.Drawing.Size(98, 23);
            this.buttonColorFore.TabIndex = 25;
            this.buttonColorFore.Text = "...";
            this.buttonColorFore.UseVisualStyleBackColor = true;
            this.buttonColorFore.Click += new System.EventHandler(this.buttonColorFore_Click);
            // 
            // buttonColorBack
            // 
            this.buttonColorBack.Location = new System.Drawing.Point(86, 134);
            this.buttonColorBack.Name = "buttonColorBack";
            this.buttonColorBack.Size = new System.Drawing.Size(98, 23);
            this.buttonColorBack.TabIndex = 26;
            this.buttonColorBack.Text = "...";
            this.buttonColorBack.UseVisualStyleBackColor = true;
            this.buttonColorBack.Click += new System.EventHandler(this.buttonColorBack_Click);
            // 
            // buttonColorText
            // 
            this.buttonColorText.Location = new System.Drawing.Point(89, 50);
            this.buttonColorText.Name = "buttonColorText";
            this.buttonColorText.Size = new System.Drawing.Size(98, 23);
            this.buttonColorText.TabIndex = 27;
            this.buttonColorText.Text = "...";
            this.buttonColorText.UseVisualStyleBackColor = true;
            this.buttonColorText.Click += new System.EventHandler(this.buttonColorText_Click);
            // 
            // checkBoxUnderline
            // 
            this.checkBoxUnderline.AutoSize = true;
            this.checkBoxUnderline.Location = new System.Drawing.Point(22, 161);
            this.checkBoxUnderline.Name = "checkBoxUnderline";
            this.checkBoxUnderline.Size = new System.Drawing.Size(77, 16);
            this.checkBoxUnderline.TabIndex = 28;
            this.checkBoxUnderline.Text = "Underline";
            this.checkBoxUnderline.UseVisualStyleBackColor = true;
            // 
            // checkBoxItalic
            // 
            this.checkBoxItalic.AutoSize = true;
            this.checkBoxItalic.Location = new System.Drawing.Point(22, 182);
            this.checkBoxItalic.Name = "checkBoxItalic";
            this.checkBoxItalic.Size = new System.Drawing.Size(50, 16);
            this.checkBoxItalic.TabIndex = 29;
            this.checkBoxItalic.Text = "Italic";
            this.checkBoxItalic.UseVisualStyleBackColor = true;
            // 
            // checkBoxStrikeOut
            // 
            this.checkBoxStrikeOut.AutoSize = true;
            this.checkBoxStrikeOut.Location = new System.Drawing.Point(21, 203);
            this.checkBoxStrikeOut.Name = "checkBoxStrikeOut";
            this.checkBoxStrikeOut.Size = new System.Drawing.Size(74, 16);
            this.checkBoxStrikeOut.TabIndex = 30;
            this.checkBoxStrikeOut.Text = "StrikeOut";
            this.checkBoxStrikeOut.UseVisualStyleBackColor = true;
            // 
            // checkBoxBold
            // 
            this.checkBoxBold.AutoSize = true;
            this.checkBoxBold.Location = new System.Drawing.Point(22, 139);
            this.checkBoxBold.Name = "checkBoxBold";
            this.checkBoxBold.Size = new System.Drawing.Size(49, 16);
            this.checkBoxBold.TabIndex = 31;
            this.checkBoxBold.Text = "Bold";
            this.checkBoxBold.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.buttonFontText);
            this.groupBox1.Controls.Add(this.textBoxObjText);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.buttonColorText);
            this.groupBox1.Controls.Add(this.checkBoxBold);
            this.groupBox1.Controls.Add(this.checkBoxStrikeOut);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.checkBoxItalic);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.checkBoxUnderline);
            this.groupBox1.Controls.Add(this.textBoxFontSize);
            this.groupBox1.Location = new System.Drawing.Point(217, 1);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(209, 233);
            this.groupBox1.TabIndex = 32;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Text";
            // 
            // buttonFontText
            // 
            this.buttonFontText.Location = new System.Drawing.Point(89, 103);
            this.buttonFontText.Name = "buttonFontText";
            this.buttonFontText.Size = new System.Drawing.Size(98, 23);
            this.buttonFontText.TabIndex = 34;
            this.buttonFontText.Text = "...";
            this.buttonFontText.UseVisualStyleBackColor = true;
            this.buttonFontText.Click += new System.EventHandler(this.buttonFontText_Click);
            // 
            // textBoxObjText
            // 
            this.textBoxObjText.Location = new System.Drawing.Point(63, 20);
            this.textBoxObjText.Name = "textBoxObjText";
            this.textBoxObjText.Size = new System.Drawing.Size(140, 21);
            this.textBoxObjText.TabIndex = 33;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(19, 24);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 12);
            this.label13.TabIndex = 33;
            this.label13.Text = "Text :";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(15, 109);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(71, 12);
            this.label12.TabIndex = 32;
            this.label12.Text = "FontName :";
            // 
            // comboBoxLineStartShape
            // 
            this.comboBoxLineStartShape.FormattingEnabled = true;
            this.comboBoxLineStartShape.Items.AddRange(new object[] {
            "NULL\t",
            "TRIANGLE",
            "ARROW",
            "ARROW2",
            "RECT\t",
            "CIRCLE"});
            this.comboBoxLineStartShape.Location = new System.Drawing.Point(125, 266);
            this.comboBoxLineStartShape.Name = "comboBoxLineStartShape";
            this.comboBoxLineStartShape.Size = new System.Drawing.Size(140, 20);
            this.comboBoxLineStartShape.TabIndex = 33;
            // 
            // comboBoxLineEndShape
            // 
            this.comboBoxLineEndShape.FormattingEnabled = true;
            this.comboBoxLineEndShape.Items.AddRange(new object[] {
            "NULL\t",
            "TRIANGLE",
            "ARROW",
            "ARROW2",
            "RECT\t",
            "CIRCLE"});
            this.comboBoxLineEndShape.Location = new System.Drawing.Point(126, 291);
            this.comboBoxLineEndShape.Name = "comboBoxLineEndShape";
            this.comboBoxLineEndShape.Size = new System.Drawing.Size(140, 20);
            this.comboBoxLineEndShape.TabIndex = 34;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(19, 269);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(85, 12);
            this.label14.TabIndex = 35;
            this.label14.Text = "선 시작 스타일";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(19, 294);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(73, 12);
            this.label15.TabIndex = 36;
            this.label15.Text = "선 끝 스타일";
            // 
            // PropertyXvcObj
            // 
            this.AcceptButton = this.buttonOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.buttonCancel;
            this.ClientSize = new System.Drawing.Size(436, 362);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.comboBoxLineEndShape);
            this.Controls.Add(this.comboBoxLineStartShape);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.buttonColorBack);
            this.Controls.Add(this.buttonColorFore);
            this.Controls.Add(this.buttonColorLine);
            this.Controls.Add(this.textBoxObjType);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.buttonCancel);
            this.Controls.Add(this.buttonOK);
            this.Controls.Add(this.textBoxThick);
            this.Controls.Add(this.comboBoxStyleFill);
            this.Controls.Add(this.comboBoxStyleLine);
            this.Controls.Add(this.textBoxName);
            this.Controls.Add(this.textBoxID);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PropertyXvcObj";
            this.Text = "Property [XvcObj]";
            this.Load += new System.EventHandler(this.PropertyXvcObj_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxID;
        private System.Windows.Forms.TextBox textBoxName;
        private System.Windows.Forms.TextBox textBoxFontSize;
        private System.Windows.Forms.ComboBox comboBoxStyleLine;
        private System.Windows.Forms.ComboBox comboBoxStyleFill;
        private System.Windows.Forms.TextBox textBoxThick;
        private System.Windows.Forms.Button buttonOK;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.TextBox textBoxObjType;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button buttonColorLine;
        private System.Windows.Forms.Button buttonColorFore;
        private System.Windows.Forms.Button buttonColorBack;
        private System.Windows.Forms.Button buttonColorText;
        private System.Windows.Forms.CheckBox checkBoxUnderline;
        private System.Windows.Forms.CheckBox checkBoxItalic;
        private System.Windows.Forms.CheckBox checkBoxStrikeOut;
        private System.Windows.Forms.CheckBox checkBoxBold;
        private System.Windows.Forms.GroupBox groupBox1;
//        private DevExpress.XtraEditors.FontEdit fontEdit1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBoxObjText;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBoxLineStartShape;
        private System.Windows.Forms.ComboBox comboBoxLineEndShape;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button buttonFontText;
        private System.Windows.Forms.FontDialog fontDialog1;
    }
}