﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using Pixoneer.NXDL;
using Pixoneer.NXDL.NVC;

namespace VectorEditor
{
    public partial class PropertyXvcObj : Form
    {
        public System.Drawing.Color m_crLine;
        public System.Drawing.Color m_crFore;
        public System.Drawing.Color m_crBack;
        public System.Drawing.Color m_crText;
        public double   m_dblThick;
        public int     m_nID;
        public String m_strName, m_strObjType, m_strText;
        public eXvcObjLineStyle m_StyleLine;
        public eXvcObjFillStyle m_StyleFill;

        // XvcText
        public String m_strFontName;
        public double   m_dblFontSize;
        public bool m_bBold;
        public bool m_bUnderline;
        public bool m_bItalic;
        public bool m_bStrikeOut;

        // Arrow
        public eXvcShapeType m_LineStartShape;
        public eXvcShapeType m_LineEndShape;

        public PropertyXvcObj()
        {
            InitializeComponent();
        }

         private void buttonOK_Click(object sender, EventArgs e)
         {
            m_strName = textBoxName.Text;
            m_nID = int.Parse(textBoxID.Text);
            m_dblThick = double.Parse(textBoxThick.Text);
            m_dblFontSize = double.Parse(textBoxFontSize.Text);
            m_StyleLine = (eXvcObjLineStyle)comboBoxStyleLine.SelectedIndex;
            m_StyleFill = (eXvcObjFillStyle)comboBoxStyleFill.SelectedIndex;
            m_bBold = checkBoxBold.Checked;
            m_bUnderline = checkBoxUnderline.Checked;
            m_bItalic = checkBoxItalic.Checked;
            m_bStrikeOut = checkBoxStrikeOut.Checked;
            m_strText = textBoxObjText.Text;
            m_LineStartShape = (eXvcShapeType)comboBoxLineStartShape.SelectedIndex;
            m_LineEndShape = (eXvcShapeType)comboBoxLineEndShape.SelectedIndex;

            DialogResult = System.Windows.Forms.DialogResult.OK;
         }

         private void buttonColorLine_Click(object sender, EventArgs e)
         {
             ColorDialog dlg = new ColorDialog();
             dlg.Color = m_crLine;
             if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
             {
                 m_crLine = dlg.Color;
                 buttonColorLine.BackColor = m_crLine;
             }
         }

         private void buttonColorFore_Click(object sender, EventArgs e)
         {
             ColorDialog dlg = new ColorDialog();
             dlg.Color = m_crFore;
             if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
             {
                 m_crFore = dlg.Color;
                 buttonColorFore.BackColor = m_crFore;
             }
         }

         private void buttonColorBack_Click(object sender, EventArgs e)
         {
             ColorDialog dlg = new ColorDialog();
             dlg.Color = m_crBack;
             if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
             {
                 m_crBack = dlg.Color;
                 buttonColorBack.BackColor = m_crBack;
             }
         }

         private void buttonColorText_Click(object sender, EventArgs e)
         {
             ColorDialog dlg = new ColorDialog();
             dlg.Color = m_crBack;
             if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
             {
                 m_crText = dlg.Color;
                 buttonColorText.BackColor = m_crText;
             }
         }

         private void buttonFontText_Click(object sender, EventArgs e)
         {
             FontDialog dlg = new FontDialog();
             float size = dlg.Font.Size;
             dlg.Font = new Font(m_strFontName, size);
             if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
             {
                 m_strFontName = dlg.Font.Name;
             }
         }

         private void PropertyXvcObj_Load(object sender, EventArgs e)
         {
             textBoxObjType.Text = m_strObjType;
             textBoxName.Text = m_strName;
             textBoxID.Text = m_nID.ToString();
             textBoxFontSize.Text = m_dblFontSize.ToString();
             buttonColorLine.BackColor = m_crLine;
             buttonColorFore.BackColor = m_crFore;
             buttonColorBack.BackColor = m_crBack;
             buttonColorText.BackColor = m_crText;
             textBoxThick.Text = m_dblThick.ToString();
             comboBoxStyleLine.SelectedIndex = (int)m_StyleLine;
             comboBoxStyleFill.SelectedIndex = (int)m_StyleFill;
             checkBoxBold.Checked = m_bBold;
             checkBoxUnderline.Checked = m_bUnderline;
             checkBoxItalic.Checked = m_bItalic;
             checkBoxStrikeOut.Checked = m_bStrikeOut;
             textBoxObjText.Text = m_strText;
             comboBoxLineStartShape.SelectedIndex = (int)m_LineStartShape;
             comboBoxLineEndShape.SelectedIndex = (int)m_LineEndShape;

         }         
    }
}
