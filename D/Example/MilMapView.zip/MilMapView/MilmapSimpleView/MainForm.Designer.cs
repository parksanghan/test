﻿using Pixoneer;
using Pixoneer.NXDL;
namespace MilmapSimpleView
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.radioButton_ZoomByZoomFactor = new System.Windows.Forms.RadioButton();
            this.radioButton_ZoomByScaleIndex = new System.Windows.Forms.RadioButton();
            this.labelScale = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox_MouseButton = new System.Windows.Forms.GroupBox();
            this.radioButton_InverseMouseButtonInverse = new System.Windows.Forms.RadioButton();
            this.radioButton_InverseMouseButtonDefault = new System.Windows.Forms.RadioButton();
            this.groupBox_MouseWheel = new System.Windows.Forms.GroupBox();
            this.radioButton_InverseMouseWheelInverse = new System.Windows.Forms.RadioButton();
            this.radioButton_InverseMouseWheelDefault = new System.Windows.Forms.RadioButton();
            this.groupBox_ZoomType = new System.Windows.Forms.GroupBox();
            this.radioButtonZoomMousePosition = new System.Windows.Forms.RadioButton();
            this.radioButton_ZoomViewCenter = new System.Windows.Forms.RadioButton();
            this.groupBox_Coordinate = new System.Windows.Forms.GroupBox();
            this.buttonZoomFit = new System.Windows.Forms.Button();
            this.textBox_URY = new System.Windows.Forms.TextBox();
            this.textBox_URX = new System.Windows.Forms.TextBox();
            this.textBox_LLY = new System.Windows.Forms.TextBox();
            this.textBox_LLX = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.checkbox_MouseCoord = new System.Windows.Forms.CheckBox();
            this.Ratio = new System.Windows.Forms.GroupBox();
            this.checkBox_RatioEnable = new System.Windows.Forms.CheckBox();
            this.trackBar_Ratio = new System.Windows.Forms.TrackBar();
            this.groupBox_Rotate = new System.Windows.Forms.GroupBox();
            this.textBox_RotUser = new System.Windows.Forms.TextBox();
            this.radioButton_RotUser = new System.Windows.Forms.RadioButton();
            this.radioButton_RotMouse = new System.Windows.Forms.RadioButton();
            this.radioButton_RotNone = new System.Windows.Forms.RadioButton();
            this.groupBox_ShowCross = new System.Windows.Forms.GroupBox();
            this.radioButton_HideCross = new System.Windows.Forms.RadioButton();
            this.radioButton_ShowCross = new System.Windows.Forms.RadioButton();
            this.groupBox_Grid = new System.Windows.Forms.GroupBox();
            this.radioButton_GridNone = new System.Windows.Forms.RadioButton();
            this.radioButton_Degree = new System.Windows.Forms.RadioButton();
            this.radioButton_GARS = new System.Windows.Forms.RadioButton();
            this.groupBox_SetCenterPos = new System.Windows.Forms.GroupBox();
            this.comboBox_Scale = new System.Windows.Forms.ComboBox();
            this.checkBox_Scale = new System.Windows.Forms.CheckBox();
            this.button_goto = new System.Windows.Forms.Button();
            this.textBox_Lat = new System.Windows.Forms.TextBox();
            this.textBox_Lon = new System.Windows.Forms.TextBox();
            this.label_Lat = new System.Windows.Forms.Label();
            this.label_Lon = new System.Windows.Forms.Label();
            this.groupBox_Saturation = new System.Windows.Forms.GroupBox();
            this.trackBar_Saturation = new System.Windows.Forms.TrackBar();
            this.groupBox_Brightness = new System.Windows.Forms.GroupBox();
            this.trackBar_Brightness = new System.Windows.Forms.TrackBar();
            this.groupBox_Contrast = new System.Windows.Forms.GroupBox();
            this.trackBar_Contrast = new System.Windows.Forms.TrackBar();
            this.nxMilmapView = new Pixoneer.NXDL.NXMilmap.NXMilmapView();
            this.nxMilmapLayer = new Pixoneer.NXDL.NXMilmap.NXMilmapLayer();
            this.backgroundWorker = new System.ComponentModel.BackgroundWorker();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox_MouseButton.SuspendLayout();
            this.groupBox_MouseWheel.SuspendLayout();
            this.groupBox_ZoomType.SuspendLayout();
            this.groupBox_Coordinate.SuspendLayout();
            this.Ratio.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Ratio)).BeginInit();
            this.groupBox_Rotate.SuspendLayout();
            this.groupBox_ShowCross.SuspendLayout();
            this.groupBox_Grid.SuspendLayout();
            this.groupBox_SetCenterPos.SuspendLayout();
            this.groupBox_Saturation.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Saturation)).BeginInit();
            this.groupBox_Brightness.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Brightness)).BeginInit();
            this.groupBox_Contrast.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Contrast)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.groupBox1);
            this.splitContainer.Panel1.Controls.Add(this.labelScale);
            this.splitContainer.Panel1.Controls.Add(this.label3);
            this.splitContainer.Panel1.Controls.Add(this.groupBox_MouseButton);
            this.splitContainer.Panel1.Controls.Add(this.groupBox_MouseWheel);
            this.splitContainer.Panel1.Controls.Add(this.groupBox_ZoomType);
            this.splitContainer.Panel1.Controls.Add(this.groupBox_Coordinate);
            this.splitContainer.Panel1.Controls.Add(this.Ratio);
            this.splitContainer.Panel1.Controls.Add(this.groupBox_Rotate);
            this.splitContainer.Panel1.Controls.Add(this.groupBox_ShowCross);
            this.splitContainer.Panel1.Controls.Add(this.groupBox_Grid);
            this.splitContainer.Panel1.Controls.Add(this.groupBox_SetCenterPos);
            this.splitContainer.Panel1.Controls.Add(this.groupBox_Saturation);
            this.splitContainer.Panel1.Controls.Add(this.groupBox_Brightness);
            this.splitContainer.Panel1.Controls.Add(this.groupBox_Contrast);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.nxMilmapView);
            this.splitContainer.Size = new System.Drawing.Size(1074, 824);
            this.splitContainer.SplitterDistance = 331;
            this.splitContainer.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButton_ZoomByZoomFactor);
            this.groupBox1.Controls.Add(this.radioButton_ZoomByScaleIndex);
            this.groupBox1.Location = new System.Drawing.Point(182, 621);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(136, 82);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Zoom Action";
            // 
            // radioButton_ZoomByZoomFactor
            // 
            this.radioButton_ZoomByZoomFactor.AutoSize = true;
            this.radioButton_ZoomByZoomFactor.Location = new System.Drawing.Point(10, 52);
            this.radioButton_ZoomByZoomFactor.Name = "radioButton_ZoomByZoomFactor";
            this.radioButton_ZoomByZoomFactor.Size = new System.Drawing.Size(114, 16);
            this.radioButton_ZoomByZoomFactor.TabIndex = 1;
            this.radioButton_ZoomByZoomFactor.TabStop = true;
            this.radioButton_ZoomByZoomFactor.Text = "By Zoom Factor";
            this.radioButton_ZoomByZoomFactor.UseVisualStyleBackColor = true;
            this.radioButton_ZoomByZoomFactor.CheckedChanged += new System.EventHandler(this.radioButton_ZoomByZoomFactor_CheckedChanged);
            // 
            // radioButton_ZoomByScaleIndex
            // 
            this.radioButton_ZoomByScaleIndex.AutoSize = true;
            this.radioButton_ZoomByScaleIndex.Location = new System.Drawing.Point(10, 30);
            this.radioButton_ZoomByScaleIndex.Name = "radioButton_ZoomByScaleIndex";
            this.radioButton_ZoomByScaleIndex.Size = new System.Drawing.Size(109, 16);
            this.radioButton_ZoomByScaleIndex.TabIndex = 0;
            this.radioButton_ZoomByScaleIndex.TabStop = true;
            this.radioButton_ZoomByScaleIndex.Text = "By Scale Index";
            this.radioButton_ZoomByScaleIndex.UseVisualStyleBackColor = true;
            this.radioButton_ZoomByScaleIndex.CheckedChanged += new System.EventHandler(this.radioButton_ZoomByScaleIndex_CheckedChanged);
            // 
            // labelScale
            // 
            this.labelScale.AutoSize = true;
            this.labelScale.Location = new System.Drawing.Point(126, 781);
            this.labelScale.Name = "labelScale";
            this.labelScale.Size = new System.Drawing.Size(65, 12);
            this.labelScale.TabIndex = 13;
            this.labelScale.Text = "1 : 1000000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 781);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(115, 12);
            this.label3.TabIndex = 12;
            this.label3.Text = "Calculated Scale - ";
            // 
            // groupBox_MouseButton
            // 
            this.groupBox_MouseButton.Controls.Add(this.radioButton_InverseMouseButtonInverse);
            this.groupBox_MouseButton.Controls.Add(this.radioButton_InverseMouseButtonDefault);
            this.groupBox_MouseButton.Location = new System.Drawing.Point(165, 708);
            this.groupBox_MouseButton.Name = "groupBox_MouseButton";
            this.groupBox_MouseButton.Size = new System.Drawing.Size(163, 60);
            this.groupBox_MouseButton.TabIndex = 11;
            this.groupBox_MouseButton.TabStop = false;
            this.groupBox_MouseButton.Text = "Inverse MouseButton";
            // 
            // radioButton_InverseMouseButtonInverse
            // 
            this.radioButton_InverseMouseButtonInverse.AutoSize = true;
            this.radioButton_InverseMouseButtonInverse.Location = new System.Drawing.Point(83, 30);
            this.radioButton_InverseMouseButtonInverse.Name = "radioButton_InverseMouseButtonInverse";
            this.radioButton_InverseMouseButtonInverse.Size = new System.Drawing.Size(64, 16);
            this.radioButton_InverseMouseButtonInverse.TabIndex = 1;
            this.radioButton_InverseMouseButtonInverse.TabStop = true;
            this.radioButton_InverseMouseButtonInverse.Text = "Inverse";
            this.radioButton_InverseMouseButtonInverse.UseVisualStyleBackColor = true;
            this.radioButton_InverseMouseButtonInverse.CheckedChanged += new System.EventHandler(this.radioButton_InverseMouseButtonInverse_CheckedChanged);
            // 
            // radioButton_InverseMouseButtonDefault
            // 
            this.radioButton_InverseMouseButtonDefault.AutoSize = true;
            this.radioButton_InverseMouseButtonDefault.Location = new System.Drawing.Point(14, 30);
            this.radioButton_InverseMouseButtonDefault.Name = "radioButton_InverseMouseButtonDefault";
            this.radioButton_InverseMouseButtonDefault.Size = new System.Drawing.Size(61, 16);
            this.radioButton_InverseMouseButtonDefault.TabIndex = 0;
            this.radioButton_InverseMouseButtonDefault.TabStop = true;
            this.radioButton_InverseMouseButtonDefault.Text = "Default";
            this.radioButton_InverseMouseButtonDefault.UseVisualStyleBackColor = true;
            this.radioButton_InverseMouseButtonDefault.CheckedChanged += new System.EventHandler(this.radioButton_InverseMouseButtonDefault_CheckedChanged);
            // 
            // groupBox_MouseWheel
            // 
            this.groupBox_MouseWheel.Controls.Add(this.radioButton_InverseMouseWheelInverse);
            this.groupBox_MouseWheel.Controls.Add(this.radioButton_InverseMouseWheelDefault);
            this.groupBox_MouseWheel.Location = new System.Drawing.Point(3, 709);
            this.groupBox_MouseWheel.Name = "groupBox_MouseWheel";
            this.groupBox_MouseWheel.Size = new System.Drawing.Size(153, 60);
            this.groupBox_MouseWheel.TabIndex = 10;
            this.groupBox_MouseWheel.TabStop = false;
            this.groupBox_MouseWheel.Text = "Inverse MouseWheel";
            // 
            // radioButton_InverseMouseWheelInverse
            // 
            this.radioButton_InverseMouseWheelInverse.AutoSize = true;
            this.radioButton_InverseMouseWheelInverse.Location = new System.Drawing.Point(81, 30);
            this.radioButton_InverseMouseWheelInverse.Name = "radioButton_InverseMouseWheelInverse";
            this.radioButton_InverseMouseWheelInverse.Size = new System.Drawing.Size(64, 16);
            this.radioButton_InverseMouseWheelInverse.TabIndex = 1;
            this.radioButton_InverseMouseWheelInverse.TabStop = true;
            this.radioButton_InverseMouseWheelInverse.Text = "Inverse";
            this.radioButton_InverseMouseWheelInverse.UseVisualStyleBackColor = true;
            this.radioButton_InverseMouseWheelInverse.CheckedChanged += new System.EventHandler(this.radioButton_InverseMouseWheelInverse_CheckedChanged);
            // 
            // radioButton_InverseMouseWheelDefault
            // 
            this.radioButton_InverseMouseWheelDefault.AutoSize = true;
            this.radioButton_InverseMouseWheelDefault.Location = new System.Drawing.Point(14, 30);
            this.radioButton_InverseMouseWheelDefault.Name = "radioButton_InverseMouseWheelDefault";
            this.radioButton_InverseMouseWheelDefault.Size = new System.Drawing.Size(61, 16);
            this.radioButton_InverseMouseWheelDefault.TabIndex = 0;
            this.radioButton_InverseMouseWheelDefault.TabStop = true;
            this.radioButton_InverseMouseWheelDefault.Text = "Default";
            this.radioButton_InverseMouseWheelDefault.UseVisualStyleBackColor = true;
            this.radioButton_InverseMouseWheelDefault.CheckedChanged += new System.EventHandler(this.radioButton_InverseMouseWheelDefault_CheckedChanged);
            // 
            // groupBox_ZoomType
            // 
            this.groupBox_ZoomType.Controls.Add(this.radioButtonZoomMousePosition);
            this.groupBox_ZoomType.Controls.Add(this.radioButton_ZoomViewCenter);
            this.groupBox_ZoomType.Location = new System.Drawing.Point(3, 621);
            this.groupBox_ZoomType.Name = "groupBox_ZoomType";
            this.groupBox_ZoomType.Size = new System.Drawing.Size(173, 82);
            this.groupBox_ZoomType.TabIndex = 9;
            this.groupBox_ZoomType.TabStop = false;
            this.groupBox_ZoomType.Text = "Zoom Type";
            // 
            // radioButtonZoomMousePosition
            // 
            this.radioButtonZoomMousePosition.AutoSize = true;
            this.radioButtonZoomMousePosition.Location = new System.Drawing.Point(10, 52);
            this.radioButtonZoomMousePosition.Name = "radioButtonZoomMousePosition";
            this.radioButtonZoomMousePosition.Size = new System.Drawing.Size(148, 16);
            this.radioButtonZoomMousePosition.TabIndex = 1;
            this.radioButtonZoomMousePosition.TabStop = true;
            this.radioButtonZoomMousePosition.Text = "Zoom Mouse Position";
            this.radioButtonZoomMousePosition.UseVisualStyleBackColor = true;
            this.radioButtonZoomMousePosition.CheckedChanged += new System.EventHandler(this.radioButtonZoomMousePosition_CheckedChanged);
            // 
            // radioButton_ZoomViewCenter
            // 
            this.radioButton_ZoomViewCenter.AutoSize = true;
            this.radioButton_ZoomViewCenter.Location = new System.Drawing.Point(10, 30);
            this.radioButton_ZoomViewCenter.Name = "radioButton_ZoomViewCenter";
            this.radioButton_ZoomViewCenter.Size = new System.Drawing.Size(129, 16);
            this.radioButton_ZoomViewCenter.TabIndex = 0;
            this.radioButton_ZoomViewCenter.TabStop = true;
            this.radioButton_ZoomViewCenter.Text = "Zoom View Center";
            this.radioButton_ZoomViewCenter.UseVisualStyleBackColor = true;
            this.radioButton_ZoomViewCenter.CheckedChanged += new System.EventHandler(this.radioButton_ZoomViewCenter_CheckedChanged);
            // 
            // groupBox_Coordinate
            // 
            this.groupBox_Coordinate.Controls.Add(this.buttonZoomFit);
            this.groupBox_Coordinate.Controls.Add(this.textBox_URY);
            this.groupBox_Coordinate.Controls.Add(this.textBox_URX);
            this.groupBox_Coordinate.Controls.Add(this.textBox_LLY);
            this.groupBox_Coordinate.Controls.Add(this.textBox_LLX);
            this.groupBox_Coordinate.Controls.Add(this.label2);
            this.groupBox_Coordinate.Controls.Add(this.label1);
            this.groupBox_Coordinate.Controls.Add(this.checkbox_MouseCoord);
            this.groupBox_Coordinate.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_Coordinate.Location = new System.Drawing.Point(0, 513);
            this.groupBox_Coordinate.Name = "groupBox_Coordinate";
            this.groupBox_Coordinate.Size = new System.Drawing.Size(331, 102);
            this.groupBox_Coordinate.TabIndex = 8;
            this.groupBox_Coordinate.TabStop = false;
            this.groupBox_Coordinate.Text = "Coordinate";
            // 
            // buttonZoomFit
            // 
            this.buttonZoomFit.Location = new System.Drawing.Point(277, 51);
            this.buttonZoomFit.Name = "buttonZoomFit";
            this.buttonZoomFit.Size = new System.Drawing.Size(48, 35);
            this.buttonZoomFit.TabIndex = 3;
            this.buttonZoomFit.Text = "Zoom";
            this.buttonZoomFit.UseVisualStyleBackColor = true;
            this.buttonZoomFit.Click += new System.EventHandler(this.buttonZoomFit_Click);
            // 
            // textBox_URY
            // 
            this.textBox_URY.Location = new System.Drawing.Point(179, 70);
            this.textBox_URY.Name = "textBox_URY";
            this.textBox_URY.Size = new System.Drawing.Size(95, 21);
            this.textBox_URY.TabIndex = 2;
            // 
            // textBox_URX
            // 
            this.textBox_URX.Location = new System.Drawing.Point(81, 71);
            this.textBox_URX.Name = "textBox_URX";
            this.textBox_URX.Size = new System.Drawing.Size(95, 21);
            this.textBox_URX.TabIndex = 2;
            // 
            // textBox_LLY
            // 
            this.textBox_LLY.Location = new System.Drawing.Point(179, 46);
            this.textBox_LLY.Name = "textBox_LLY";
            this.textBox_LLY.Size = new System.Drawing.Size(95, 21);
            this.textBox_LLY.TabIndex = 2;
            // 
            // textBox_LLX
            // 
            this.textBox_LLX.Location = new System.Drawing.Point(81, 47);
            this.textBox_LLX.Name = "textBox_LLX";
            this.textBox_LLX.Size = new System.Drawing.Size(95, 21);
            this.textBox_LLX.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(71, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "Uper Right :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(10, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "Low Left :";
            // 
            // checkbox_MouseCoord
            // 
            this.checkbox_MouseCoord.AutoSize = true;
            this.checkbox_MouseCoord.Location = new System.Drawing.Point(12, 24);
            this.checkbox_MouseCoord.Name = "checkbox_MouseCoord";
            this.checkbox_MouseCoord.Size = new System.Drawing.Size(128, 16);
            this.checkbox_MouseCoord.TabIndex = 0;
            this.checkbox_MouseCoord.Text = "Mouse Coordinate";
            this.checkbox_MouseCoord.UseVisualStyleBackColor = true;
            this.checkbox_MouseCoord.CheckedChanged += new System.EventHandler(this.checkbox_MouseCoord_CheckedChanged);
            // 
            // Ratio
            // 
            this.Ratio.Controls.Add(this.checkBox_RatioEnable);
            this.Ratio.Controls.Add(this.trackBar_Ratio);
            this.Ratio.Dock = System.Windows.Forms.DockStyle.Top;
            this.Ratio.Location = new System.Drawing.Point(0, 450);
            this.Ratio.Name = "Ratio";
            this.Ratio.Size = new System.Drawing.Size(331, 63);
            this.Ratio.TabIndex = 7;
            this.Ratio.TabStop = false;
            this.Ratio.Text = "Ratio";
            // 
            // checkBox_RatioEnable
            // 
            this.checkBox_RatioEnable.AutoSize = true;
            this.checkBox_RatioEnable.Location = new System.Drawing.Point(13, 29);
            this.checkBox_RatioEnable.Name = "checkBox_RatioEnable";
            this.checkBox_RatioEnable.Size = new System.Drawing.Size(63, 16);
            this.checkBox_RatioEnable.TabIndex = 4;
            this.checkBox_RatioEnable.Text = "Enable";
            this.checkBox_RatioEnable.UseVisualStyleBackColor = true;
            this.checkBox_RatioEnable.CheckedChanged += new System.EventHandler(this.checkBox_RatioEnable_CheckedChanged);
            // 
            // trackBar_Ratio
            // 
            this.trackBar_Ratio.Dock = System.Windows.Forms.DockStyle.Right;
            this.trackBar_Ratio.Location = new System.Drawing.Point(81, 17);
            this.trackBar_Ratio.Name = "trackBar_Ratio";
            this.trackBar_Ratio.Size = new System.Drawing.Size(247, 43);
            this.trackBar_Ratio.TabIndex = 3;
            this.trackBar_Ratio.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBar_Ratio.Scroll += new System.EventHandler(this.trackBar_Ratio_Scroll);
            // 
            // groupBox_Rotate
            // 
            this.groupBox_Rotate.Controls.Add(this.textBox_RotUser);
            this.groupBox_Rotate.Controls.Add(this.radioButton_RotUser);
            this.groupBox_Rotate.Controls.Add(this.radioButton_RotMouse);
            this.groupBox_Rotate.Controls.Add(this.radioButton_RotNone);
            this.groupBox_Rotate.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_Rotate.Location = new System.Drawing.Point(0, 386);
            this.groupBox_Rotate.Name = "groupBox_Rotate";
            this.groupBox_Rotate.Size = new System.Drawing.Size(331, 64);
            this.groupBox_Rotate.TabIndex = 6;
            this.groupBox_Rotate.TabStop = false;
            this.groupBox_Rotate.Text = "Rotate";
            // 
            // textBox_RotUser
            // 
            this.textBox_RotUser.Location = new System.Drawing.Point(259, 29);
            this.textBox_RotUser.Name = "textBox_RotUser";
            this.textBox_RotUser.Size = new System.Drawing.Size(52, 21);
            this.textBox_RotUser.TabIndex = 3;
            this.textBox_RotUser.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_RotUser_KeyDown);
            // 
            // radioButton_RotUser
            // 
            this.radioButton_RotUser.AutoSize = true;
            this.radioButton_RotUser.Location = new System.Drawing.Point(175, 31);
            this.radioButton_RotUser.Name = "radioButton_RotUser";
            this.radioButton_RotUser.Size = new System.Drawing.Size(80, 16);
            this.radioButton_RotUser.TabIndex = 2;
            this.radioButton_RotUser.Text = "User Input";
            this.radioButton_RotUser.UseVisualStyleBackColor = true;
            this.radioButton_RotUser.CheckedChanged += new System.EventHandler(this.radioButton_RotUser_CheckedChanged);
            // 
            // radioButton_RotMouse
            // 
            this.radioButton_RotMouse.AutoSize = true;
            this.radioButton_RotMouse.Location = new System.Drawing.Point(72, 31);
            this.radioButton_RotMouse.Name = "radioButton_RotMouse";
            this.radioButton_RotMouse.Size = new System.Drawing.Size(97, 16);
            this.radioButton_RotMouse.TabIndex = 2;
            this.radioButton_RotMouse.Text = "Mouse Event";
            this.radioButton_RotMouse.UseVisualStyleBackColor = true;
            this.radioButton_RotMouse.CheckedChanged += new System.EventHandler(this.radioButton_RotMouse_CheckedChanged);
            // 
            // radioButton_RotNone
            // 
            this.radioButton_RotNone.AutoSize = true;
            this.radioButton_RotNone.Checked = true;
            this.radioButton_RotNone.Location = new System.Drawing.Point(13, 31);
            this.radioButton_RotNone.Name = "radioButton_RotNone";
            this.radioButton_RotNone.Size = new System.Drawing.Size(53, 16);
            this.radioButton_RotNone.TabIndex = 0;
            this.radioButton_RotNone.TabStop = true;
            this.radioButton_RotNone.Text = "None";
            this.radioButton_RotNone.UseVisualStyleBackColor = true;
            this.radioButton_RotNone.CheckedChanged += new System.EventHandler(this.radioButton_RotNone_CheckedChanged);
            // 
            // groupBox_ShowCross
            // 
            this.groupBox_ShowCross.Controls.Add(this.radioButton_HideCross);
            this.groupBox_ShowCross.Controls.Add(this.radioButton_ShowCross);
            this.groupBox_ShowCross.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_ShowCross.Location = new System.Drawing.Point(0, 333);
            this.groupBox_ShowCross.Name = "groupBox_ShowCross";
            this.groupBox_ShowCross.Size = new System.Drawing.Size(331, 53);
            this.groupBox_ShowCross.TabIndex = 5;
            this.groupBox_ShowCross.TabStop = false;
            this.groupBox_ShowCross.Text = "Show Cross";
            // 
            // radioButton_HideCross
            // 
            this.radioButton_HideCross.AutoSize = true;
            this.radioButton_HideCross.Location = new System.Drawing.Point(118, 25);
            this.radioButton_HideCross.Name = "radioButton_HideCross";
            this.radioButton_HideCross.Size = new System.Drawing.Size(48, 16);
            this.radioButton_HideCross.TabIndex = 2;
            this.radioButton_HideCross.Text = "Hide";
            this.radioButton_HideCross.UseVisualStyleBackColor = true;
            this.radioButton_HideCross.CheckedChanged += new System.EventHandler(this.radioButton_HideCross_CheckedChanged);
            // 
            // radioButton_ShowCross
            // 
            this.radioButton_ShowCross.AutoSize = true;
            this.radioButton_ShowCross.Checked = true;
            this.radioButton_ShowCross.Location = new System.Drawing.Point(13, 25);
            this.radioButton_ShowCross.Name = "radioButton_ShowCross";
            this.radioButton_ShowCross.Size = new System.Drawing.Size(55, 16);
            this.radioButton_ShowCross.TabIndex = 0;
            this.radioButton_ShowCross.TabStop = true;
            this.radioButton_ShowCross.Text = "Show";
            this.radioButton_ShowCross.UseVisualStyleBackColor = true;
            this.radioButton_ShowCross.CheckedChanged += new System.EventHandler(this.radioButton_ShowCross_CheckedChanged);
            // 
            // groupBox_Grid
            // 
            this.groupBox_Grid.Controls.Add(this.radioButton_GridNone);
            this.groupBox_Grid.Controls.Add(this.radioButton_Degree);
            this.groupBox_Grid.Controls.Add(this.radioButton_GARS);
            this.groupBox_Grid.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_Grid.Location = new System.Drawing.Point(0, 275);
            this.groupBox_Grid.Name = "groupBox_Grid";
            this.groupBox_Grid.Size = new System.Drawing.Size(331, 58);
            this.groupBox_Grid.TabIndex = 4;
            this.groupBox_Grid.TabStop = false;
            this.groupBox_Grid.Text = "Grid Type";
            // 
            // radioButton_GridNone
            // 
            this.radioButton_GridNone.AutoSize = true;
            this.radioButton_GridNone.Location = new System.Drawing.Point(232, 25);
            this.radioButton_GridNone.Name = "radioButton_GridNone";
            this.radioButton_GridNone.Size = new System.Drawing.Size(53, 16);
            this.radioButton_GridNone.TabIndex = 2;
            this.radioButton_GridNone.Text = "None";
            this.radioButton_GridNone.UseVisualStyleBackColor = true;
            this.radioButton_GridNone.CheckedChanged += new System.EventHandler(this.radioButton_GridNone_CheckedChanged);
            // 
            // radioButton_Degree
            // 
            this.radioButton_Degree.AutoSize = true;
            this.radioButton_Degree.Location = new System.Drawing.Point(118, 25);
            this.radioButton_Degree.Name = "radioButton_Degree";
            this.radioButton_Degree.Size = new System.Drawing.Size(63, 16);
            this.radioButton_Degree.TabIndex = 1;
            this.radioButton_Degree.Text = "Degree";
            this.radioButton_Degree.UseVisualStyleBackColor = true;
            this.radioButton_Degree.CheckedChanged += new System.EventHandler(this.radioButton_Degree_CheckedChanged);
            // 
            // radioButton_GARS
            // 
            this.radioButton_GARS.AutoSize = true;
            this.radioButton_GARS.Checked = true;
            this.radioButton_GARS.Location = new System.Drawing.Point(13, 25);
            this.radioButton_GARS.Name = "radioButton_GARS";
            this.radioButton_GARS.Size = new System.Drawing.Size(56, 16);
            this.radioButton_GARS.TabIndex = 0;
            this.radioButton_GARS.TabStop = true;
            this.radioButton_GARS.Text = "GARS";
            this.radioButton_GARS.UseVisualStyleBackColor = true;
            this.radioButton_GARS.CheckedChanged += new System.EventHandler(this.radioButton_GARS_CheckedChanged);
            // 
            // groupBox_SetCenterPos
            // 
            this.groupBox_SetCenterPos.Controls.Add(this.comboBox_Scale);
            this.groupBox_SetCenterPos.Controls.Add(this.checkBox_Scale);
            this.groupBox_SetCenterPos.Controls.Add(this.button_goto);
            this.groupBox_SetCenterPos.Controls.Add(this.textBox_Lat);
            this.groupBox_SetCenterPos.Controls.Add(this.textBox_Lon);
            this.groupBox_SetCenterPos.Controls.Add(this.label_Lat);
            this.groupBox_SetCenterPos.Controls.Add(this.label_Lon);
            this.groupBox_SetCenterPos.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_SetCenterPos.Location = new System.Drawing.Point(0, 183);
            this.groupBox_SetCenterPos.Name = "groupBox_SetCenterPos";
            this.groupBox_SetCenterPos.Size = new System.Drawing.Size(331, 92);
            this.groupBox_SetCenterPos.TabIndex = 3;
            this.groupBox_SetCenterPos.TabStop = false;
            this.groupBox_SetCenterPos.Text = "Set Center Position";
            // 
            // comboBox_Scale
            // 
            this.comboBox_Scale.FormattingEnabled = true;
            this.comboBox_Scale.Location = new System.Drawing.Point(12, 52);
            this.comboBox_Scale.Name = "comboBox_Scale";
            this.comboBox_Scale.Size = new System.Drawing.Size(79, 20);
            this.comboBox_Scale.TabIndex = 7;
            this.comboBox_Scale.SelectedIndexChanged += new System.EventHandler(this.comboBox_Scale_SelectedIndexChanged);
            // 
            // checkBox_Scale
            // 
            this.checkBox_Scale.AutoSize = true;
            this.checkBox_Scale.Location = new System.Drawing.Point(13, 29);
            this.checkBox_Scale.Name = "checkBox_Scale";
            this.checkBox_Scale.Size = new System.Drawing.Size(56, 16);
            this.checkBox_Scale.TabIndex = 6;
            this.checkBox_Scale.Text = "Scale";
            this.checkBox_Scale.UseVisualStyleBackColor = true;
            this.checkBox_Scale.CheckedChanged += new System.EventHandler(this.checkBox_Scale_CheckedChanged);
            // 
            // button_goto
            // 
            this.button_goto.Location = new System.Drawing.Point(256, 27);
            this.button_goto.Name = "button_goto";
            this.button_goto.Size = new System.Drawing.Size(56, 46);
            this.button_goto.TabIndex = 5;
            this.button_goto.Text = "GoTo";
            this.button_goto.UseVisualStyleBackColor = true;
            this.button_goto.Click += new System.EventHandler(this.button_goto_Click);
            // 
            // textBox_Lat
            // 
            this.textBox_Lat.Location = new System.Drawing.Point(162, 52);
            this.textBox_Lat.Name = "textBox_Lat";
            this.textBox_Lat.Size = new System.Drawing.Size(88, 21);
            this.textBox_Lat.TabIndex = 4;
            // 
            // textBox_Lon
            // 
            this.textBox_Lon.Location = new System.Drawing.Point(162, 27);
            this.textBox_Lon.Name = "textBox_Lon";
            this.textBox_Lon.Size = new System.Drawing.Size(88, 21);
            this.textBox_Lon.TabIndex = 3;
            // 
            // label_Lat
            // 
            this.label_Lat.AutoSize = true;
            this.label_Lat.Location = new System.Drawing.Point(116, 61);
            this.label_Lat.Name = "label_Lat";
            this.label_Lat.Size = new System.Drawing.Size(37, 12);
            this.label_Lat.TabIndex = 1;
            this.label_Lat.Text = "위도 :";
            // 
            // label_Lon
            // 
            this.label_Lon.AutoSize = true;
            this.label_Lon.Location = new System.Drawing.Point(116, 30);
            this.label_Lon.Name = "label_Lon";
            this.label_Lon.Size = new System.Drawing.Size(37, 12);
            this.label_Lon.TabIndex = 0;
            this.label_Lon.Text = "경도 :";
            // 
            // groupBox_Saturation
            // 
            this.groupBox_Saturation.Controls.Add(this.trackBar_Saturation);
            this.groupBox_Saturation.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_Saturation.Location = new System.Drawing.Point(0, 122);
            this.groupBox_Saturation.Name = "groupBox_Saturation";
            this.groupBox_Saturation.Size = new System.Drawing.Size(331, 61);
            this.groupBox_Saturation.TabIndex = 2;
            this.groupBox_Saturation.TabStop = false;
            this.groupBox_Saturation.Text = "Saturation";
            // 
            // trackBar_Saturation
            // 
            this.trackBar_Saturation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trackBar_Saturation.Location = new System.Drawing.Point(3, 17);
            this.trackBar_Saturation.Name = "trackBar_Saturation";
            this.trackBar_Saturation.Size = new System.Drawing.Size(325, 41);
            this.trackBar_Saturation.TabIndex = 2;
            this.trackBar_Saturation.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBar_Saturation.Scroll += new System.EventHandler(this.trackBar_Saturation_Scroll);
            // 
            // groupBox_Brightness
            // 
            this.groupBox_Brightness.Controls.Add(this.trackBar_Brightness);
            this.groupBox_Brightness.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_Brightness.Location = new System.Drawing.Point(0, 61);
            this.groupBox_Brightness.Name = "groupBox_Brightness";
            this.groupBox_Brightness.Size = new System.Drawing.Size(331, 61);
            this.groupBox_Brightness.TabIndex = 1;
            this.groupBox_Brightness.TabStop = false;
            this.groupBox_Brightness.Text = "Brightness";
            // 
            // trackBar_Brightness
            // 
            this.trackBar_Brightness.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trackBar_Brightness.Location = new System.Drawing.Point(3, 17);
            this.trackBar_Brightness.Name = "trackBar_Brightness";
            this.trackBar_Brightness.Size = new System.Drawing.Size(325, 41);
            this.trackBar_Brightness.TabIndex = 1;
            this.trackBar_Brightness.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBar_Brightness.Scroll += new System.EventHandler(this.trackBar_Brightness_Scroll);
            // 
            // groupBox_Contrast
            // 
            this.groupBox_Contrast.Controls.Add(this.trackBar_Contrast);
            this.groupBox_Contrast.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_Contrast.Location = new System.Drawing.Point(0, 0);
            this.groupBox_Contrast.Name = "groupBox_Contrast";
            this.groupBox_Contrast.Size = new System.Drawing.Size(331, 61);
            this.groupBox_Contrast.TabIndex = 0;
            this.groupBox_Contrast.TabStop = false;
            this.groupBox_Contrast.Text = "Contrast";
            // 
            // trackBar_Contrast
            // 
            this.trackBar_Contrast.Dock = System.Windows.Forms.DockStyle.Fill;
            this.trackBar_Contrast.Location = new System.Drawing.Point(3, 17);
            this.trackBar_Contrast.Name = "trackBar_Contrast";
            this.trackBar_Contrast.Size = new System.Drawing.Size(325, 41);
            this.trackBar_Contrast.TabIndex = 0;
            this.trackBar_Contrast.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBar_Contrast.Scroll += new System.EventHandler(this.trackBar_Contrast_Scroll);
            // 
            // nxMilmapView
            // 
            this.nxMilmapView.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.nxMilmapView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nxMilmapView.EnableControlRatio = false;
            this.nxMilmapView.ForeColor = System.Drawing.SystemColors.ControlText;
            this.nxMilmapView.FreezeViewArea = false;
            this.nxMilmapView.GridType = Pixoneer.NXDL.NXMilmap.NXMilmapView.eGridType.GridNone;
            this.nxMilmapView.InverseMouseButton = false;
            this.nxMilmapView.InverseMouseWheel = false;
            this.nxMilmapView.Location = new System.Drawing.Point(0, 0);
            this.nxMilmapView.Name = "nxMilmapView";
            this.nxMilmapView.RenderCycleOn = false;
            this.nxMilmapView.Rotatable = false;
            this.nxMilmapView.ShowGrid = false;
            this.nxMilmapView.ShowPlaceName = false;
            this.nxMilmapView.Size = new System.Drawing.Size(739, 824);
            this.nxMilmapView.TabIndex = 0;
            this.nxMilmapView.ToolboxAreaUnit = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxAreaUnit.SquareMeter;
            this.nxMilmapView.ToolboxDistUnit = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxDistUnit.Meter;
            this.nxMilmapView.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.None;
            this.nxMilmapView.WheelZoomAction = Pixoneer.NXDL.NXMilmap.NXMilmapView.eWheelZoomAction.ByScaleIndex;
            this.nxMilmapView.ZoomType = Pixoneer.NXDL.NXMilmap.NXMilmapView.eZoomType.ViewCenter;
            this.nxMilmapView.OnMouseWheel += new Pixoneer.NXDL.NXMilmap.NXMilMapView_Event_Mouse(this.nxMilmapView_OnMouseWheel);
            this.nxMilmapView.MouseMove += new System.Windows.Forms.MouseEventHandler(this.nxMilmapView_MouseMove);
            // 
            // nxMilmapLayer
            // 
            this.nxMilmapLayer.AutoDelete = true;
            this.nxMilmapLayer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nxMilmapLayer.LayerCapture = true;
            this.nxMilmapLayer.LayerVisible = true;
            this.nxMilmapLayer.Location = new System.Drawing.Point(0, 0);
            this.nxMilmapLayer.Name = "nxMilmapLayer";
            this.nxMilmapLayer.Size = new System.Drawing.Size(145, 30);
            this.nxMilmapLayer.TabIndex = 0;
            this.nxMilmapLayer.UseDisplayList = true;
            this.nxMilmapLayer.Visible = false;
            this.nxMilmapLayer.OnOrthoRender += new Pixoneer.NXDL.NXMilmap.NXMilmapLayerRenderEvent(this.nxMilmapLayer_OnOrthoRender);
            this.nxMilmapLayer.OnRender += new Pixoneer.NXDL.NXMilmap.NXMilmapLayerRenderEvent(this.nxMilmapLayer_OnRender);
            // 
            // backgroundWorker
            // 
            this.backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_RunWorkerCompleted);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1074, 824);
            this.Controls.Add(this.splitContainer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Milmap Simple View";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox_MouseButton.ResumeLayout(false);
            this.groupBox_MouseButton.PerformLayout();
            this.groupBox_MouseWheel.ResumeLayout(false);
            this.groupBox_MouseWheel.PerformLayout();
            this.groupBox_ZoomType.ResumeLayout(false);
            this.groupBox_ZoomType.PerformLayout();
            this.groupBox_Coordinate.ResumeLayout(false);
            this.groupBox_Coordinate.PerformLayout();
            this.Ratio.ResumeLayout(false);
            this.Ratio.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Ratio)).EndInit();
            this.groupBox_Rotate.ResumeLayout(false);
            this.groupBox_Rotate.PerformLayout();
            this.groupBox_ShowCross.ResumeLayout(false);
            this.groupBox_ShowCross.PerformLayout();
            this.groupBox_Grid.ResumeLayout(false);
            this.groupBox_Grid.PerformLayout();
            this.groupBox_SetCenterPos.ResumeLayout(false);
            this.groupBox_SetCenterPos.PerformLayout();
            this.groupBox_Saturation.ResumeLayout(false);
            this.groupBox_Saturation.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Saturation)).EndInit();
            this.groupBox_Brightness.ResumeLayout(false);
            this.groupBox_Brightness.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Brightness)).EndInit();
            this.groupBox_Contrast.ResumeLayout(false);
            this.groupBox_Contrast.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_Contrast)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Pixoneer.NXDL.NXMilmap.NXMilmapView nxMilmapView;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.GroupBox groupBox_Contrast;
        private System.Windows.Forms.TrackBar trackBar_Contrast;
        private System.Windows.Forms.GroupBox groupBox_Brightness;
        private System.Windows.Forms.TrackBar trackBar_Brightness;
        private System.Windows.Forms.GroupBox groupBox_Saturation;
        private System.Windows.Forms.TrackBar trackBar_Saturation;
        private System.Windows.Forms.GroupBox groupBox_SetCenterPos;
        private System.Windows.Forms.Label label_Lat;
        private System.Windows.Forms.Label label_Lon;
        private System.Windows.Forms.TextBox textBox_Lat;
        private System.Windows.Forms.TextBox textBox_Lon;
        private System.Windows.Forms.Button button_goto;
        private System.Windows.Forms.GroupBox groupBox_Grid;
        private System.Windows.Forms.RadioButton radioButton_GridNone;
        private System.Windows.Forms.RadioButton radioButton_Degree;
        private System.Windows.Forms.RadioButton radioButton_GARS;
        private System.Windows.Forms.ComboBox comboBox_Scale;
        private System.Windows.Forms.CheckBox checkBox_Scale;
        private System.Windows.Forms.GroupBox groupBox_ShowCross;
        private System.Windows.Forms.RadioButton radioButton_HideCross;
        private System.Windows.Forms.RadioButton radioButton_ShowCross;
        private System.Windows.Forms.GroupBox groupBox_Rotate;
        private System.Windows.Forms.RadioButton radioButton_RotUser;
        private System.Windows.Forms.RadioButton radioButton_RotMouse;
        private System.Windows.Forms.RadioButton radioButton_RotNone;
        private System.Windows.Forms.TextBox textBox_RotUser;
        private System.Windows.Forms.GroupBox Ratio;
        private System.Windows.Forms.TrackBar trackBar_Ratio;
        private Pixoneer.NXDL.NXMilmap.NXMilmapLayer nxMilmapLayer;
        private System.ComponentModel.BackgroundWorker backgroundWorker;
        private System.Windows.Forms.GroupBox groupBox_MouseWheel;
        private System.Windows.Forms.RadioButton radioButton_InverseMouseWheelInverse;
        private System.Windows.Forms.RadioButton radioButton_InverseMouseWheelDefault;
        private System.Windows.Forms.GroupBox groupBox_MouseButton;
        private System.Windows.Forms.RadioButton radioButton_InverseMouseButtonInverse;
        private System.Windows.Forms.RadioButton radioButton_InverseMouseButtonDefault;
        private System.Windows.Forms.CheckBox checkBox_RatioEnable;
        private System.Windows.Forms.Label labelScale;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox_Coordinate;
        private System.Windows.Forms.Button buttonZoomFit;
        private System.Windows.Forms.TextBox textBox_URY;
        private System.Windows.Forms.TextBox textBox_URX;
        private System.Windows.Forms.TextBox textBox_LLY;
        private System.Windows.Forms.TextBox textBox_LLX;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkbox_MouseCoord;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton_ZoomByZoomFactor;
        private System.Windows.Forms.RadioButton radioButton_ZoomByScaleIndex;
        private System.Windows.Forms.GroupBox groupBox_ZoomType;
        private System.Windows.Forms.RadioButton radioButtonZoomMousePosition;
        private System.Windows.Forms.RadioButton radioButton_ZoomViewCenter;
    }
}

