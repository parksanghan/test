﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL;
using Pixoneer.NXDL.NXMilmap;
using System.Diagnostics;
using Pixoneer.NXDL.NGR;
namespace MilmapSimpleView
{
    public partial class MainForm : Form
    {
        XTextPrinter TextPrinter = new XTextPrinter();
        XTextPrinter TextPrinter1 = new XTextPrinter();
        XVertex2d vMousePos = new XVertex2d();
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Xfn.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            Font myFont = new Font("Arial", 30, FontStyle.Bold);
            Font myFont1 = new Font("Arial", 30, FontStyle.Regular);
            TextPrinter.Initialize(myFont);
            TextPrinter1.Initialize(myFont1);
            if (NXMilmapView.m_MapEngine.InitFromXML(@"c:\Pixoneer\XDL3.0\Config\XMilmapConfig.xml") == false)
            {
                MessageBox.Show("XMilmapConfig.xml Load Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            trackBar_Contrast.Maximum = 100;
            trackBar_Contrast.Minimum = 0;
            trackBar_Contrast.Value = (int)(nxMilmapView.GetDrawArgs().Contrast*50.0f);

            trackBar_Brightness.Maximum = 100;
            trackBar_Brightness.Minimum = 0;
            trackBar_Brightness.Value = (int)(nxMilmapView.GetDrawArgs().Brightness * 50.0f);

            trackBar_Saturation.Maximum = 100;
            trackBar_Saturation.Minimum = 0;
            trackBar_Saturation.Value = (int)(nxMilmapView.GetDrawArgs().Saturation * 50.0f);

            trackBar_Ratio.Maximum = 100;
            trackBar_Ratio.Minimum = 0;
            trackBar_Ratio.Value = (int)(nxMilmapView.GetDrawArgs().DrawingRatio * 50.0f);


            nxMilmapView.ShowGrid = false;
            radioButton_GridNone.Checked = true;

            textBox_Lon.Text = "128.0";
            textBox_Lat.Text = "36.0";

            
            int nNumofScale = NXMilmapView.m_MapEngine.GetNumOfScale();
            for (int i = 0; i < nNumofScale; i++)
            {
                string scaleName = NXMilmapView.m_MapEngine.GetScaleName(i);
                comboBox_Scale.Items.Add(scaleName);
            }
            if (nNumofScale > 0)
                comboBox_Scale.SelectedIndex = 0;
            comboBox_Scale.Enabled = false;
            radioButton_ShowCross.Checked = true;

            textBox_RotUser.Text = "0.0";
            radioButton_RotNone.Checked = true;
            textBox_RotUser.Enabled = false;

            nxMilmapView.AddRenderLayer(ref nxMilmapLayer);
            radioButton_ZoomViewCenter.Checked = true;

            radioButton_InverseMouseWheelDefault.Checked = true;
            radioButton_InverseMouseButtonDefault.Checked = true;
            checkBox_RatioEnable.Checked = true;

            nxMilmapView.WheelZoomAction = NXMilmapView.eWheelZoomAction.ByScaleIndex;

            radioButton_ZoomByScaleIndex.Checked = true;
            radioButton_ZoomByZoomFactor.Checked = false;

            nxMilmapView.OnKeyDown += new NXMilMapView_Event_Keyboard(nxMilmapView_OnKeyDown);
            nxMilmapView.OnKeyUp += new NXMilMapView_Event_Keyboard(nxMilmapView_OnKeyUp);
            nxMilmapView.OnMouseWheel += new NXMilMapView_Event_Mouse(nxMilmapView_OnMouseWheel);
        }

        bool nxMilmapView_OnKeyUp(NXMilmapView sender, KeyEventArgs e)
        {
            return false;
        }

        bool nxMilmapView_OnKeyDown(NXMilmapView sender, KeyEventArgs e)
        {
            return false;
        }

        private void trackBar_Contrast_Scroll(object sender, EventArgs e)
        {
            string strValue = trackBar_Contrast.Value.ToString();
            nxMilmapView.GetDrawArgs().Contrast = float.Parse(strValue) / 50.0f;

            System.Diagnostics.Debug.WriteLine("Contrast : " + nxMilmapView.GetDrawArgs().Contrast.ToString());
        }

        private void trackBar_Brightness_Scroll(object sender, EventArgs e)
        {
            string strValue = trackBar_Brightness.Value.ToString();
            nxMilmapView.GetDrawArgs().Brightness = float.Parse(strValue) / 50.0f;
            System.Diagnostics.Debug.WriteLine("Brightness : " + nxMilmapView.GetDrawArgs().Brightness.ToString());
        }

        private void trackBar_Saturation_Scroll(object sender, EventArgs e)
        {

            string strValue = trackBar_Saturation.Value.ToString();
            nxMilmapView.GetDrawArgs().Saturation = float.Parse(strValue) / 50.0f;
            System.Diagnostics.Debug.WriteLine("Saturation : " + nxMilmapView.GetDrawArgs().Saturation.ToString());
        }

        private void button_goto_Click(object sender, EventArgs e)
        {
            int nScale = 0;
            if (comboBox_Scale.Enabled)
            {
                nScale = comboBox_Scale.SelectedIndex;
            }
            else nScale = nxMilmapView.GetDrawArgs().ScaleIndex;
            XVertex2d vGeopos = new XVertex2d();
            vGeopos.x = Double.Parse(textBox_Lon.Text);
            vGeopos.y = Double.Parse(textBox_Lat.Text);
            
            nxMilmapView.SetGeoToCenter(nScale, vGeopos);
            
        }

        private void radioButton_GridNone_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.ShowGrid = false;
            nxMilmapView.RefreshScreen();
        }

        private void radioButton_GARS_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.GridType = NXMilmapView.eGridType.GridGARS;
            nxMilmapView.ShowGrid = true;
            nxMilmapView.RefreshScreen();
        }

        private void radioButton_Degree_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.GridType = NXMilmapView.eGridType.GridDegrees;
            nxMilmapView.ShowGrid = true;
            nxMilmapView.RefreshScreen();
        }

        private void checkBox_Scale_CheckedChanged(object sender, EventArgs e)
        {
            comboBox_Scale.Enabled = checkBox_Scale.Checked;
        }

        private void comboBox_Scale_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void radioButton_ShowCross_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.ShowCross(radioButton_ShowCross.Checked);
        }

        private void radioButton_HideCross_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.ShowCross(radioButton_ShowCross.Checked);
        }

        private void radioButton_RotNone_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.GetDrawArgs().Rotatable = !radioButton_RotNone.Checked;
        }

        private void radioButton_RotMouse_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void radioButton_RotUser_CheckedChanged(object sender, EventArgs e)
        {
            textBox_RotUser.Enabled = radioButton_RotUser.Checked;
            textBox_RotUser.Text = nxMilmapView.GetDrawArgs().AzimuthAng.deg.ToString();
            nxMilmapView.GetDrawArgs().Rotatable = !radioButton_RotUser.Checked;
        }

        private void textBox_RotUser_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                nxMilmapView.GetDrawArgs().AzimuthAng = XAngle.FromDegree(double.Parse(textBox_RotUser.Text));
            }
        }

        private void trackBar_Ratio_Scroll(object sender, EventArgs e)
        {
            string strValue = trackBar_Ratio.Value.ToString();
            nxMilmapView.GetDrawArgs().DrawingRatio = Double.Parse(strValue) / 50.0f;
        }

        private void UpdateViewCoordinate()
        {
            if (textBox_LLX.InvokeRequired)
            {
                if( !this.backgroundWorker.IsBusy )
                    this.backgroundWorker.RunWorkerAsync();
            }
            else
            {
                textBox_LLX.Text = nxMilmapView.GetDrawArgs().LLGeo.x.ToString();
                textBox_LLY.Text = nxMilmapView.GetDrawArgs().LLGeo.y.ToString();
                textBox_URX.Text = nxMilmapView.GetDrawArgs().URGeo.x.ToString();
                textBox_URY.Text = nxMilmapView.GetDrawArgs().URGeo.y.ToString();
            }
        }

        private bool nxMilmapLayer_OnRender(object sender, NXMilmapDrawArgs e)
        {
            System.Diagnostics.Debug.WriteLine("Scale Index : " + e.ScaleIndex.ToString());
            return default(bool);
        }

        private bool nxMilmapLayer_OnOrthoRender(object sender, NXMilmapDrawArgs e)
        {
            UpdateViewCoordinate();
            if (checkbox_MouseCoord.Checked)
            {
                XVertex2d pt = e.ScreenToGeographic(vMousePos);
                string strMouseCoord = string.Format("{0}, {1}", pt.x, pt.y);
                TextPrinter.Print(strMouseCoord, new XVertex3d(vMousePos.x, vMousePos.y, 0.0), eTextAlign.Align_Left, Color.Red, false, Color.Black);

                TextPrinter1.Print(strMouseCoord, new XVertex3d(vMousePos.x, vMousePos.y + 50, 0.0), eTextAlign.Align_Left, Color.Red, false, Color.Black);
            }

            return default(bool);
        }

        private void backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (textBox_LLX.InvokeRequired)
            {
                this.Invoke(new MethodInvoker(delegate()
                {
                    textBox_LLX.Text = nxMilmapView.GetDrawArgs().LLGeo.x.ToString();
                    textBox_LLY.Text = nxMilmapView.GetDrawArgs().LLGeo.y.ToString();
                    textBox_URX.Text = nxMilmapView.GetDrawArgs().URGeo.x.ToString();
                    textBox_URY.Text = nxMilmapView.GetDrawArgs().URGeo.y.ToString();
                }));
            }
            
        }

        private void nxMilmapView_MouseMove(object sender, MouseEventArgs e)
        {
            if (nxMilmapView == null) return;
            if (checkbox_MouseCoord.Checked)
            {
                vMousePos.x = e.X;
                vMousePos.y = e.Y;
                nxMilmapView.RefreshScreen();
            }

            int scale = nxMilmapView.CalculateScale();
            labelScale.Text = scale.ToString("#,##0");
        }

        private void checkbox_MouseCoord_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.RefreshScreen();
        }

        private void radioButton_ZoomViewCenter_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.ZoomType = NXMilmapView.eZoomType.ViewCenter;
        }

        private void radioButtonZoomMousePosition_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.ZoomType = NXMilmapView.eZoomType.MousePostion;
        }

        private void radioButton_InverseMouseWheelDefault_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.InverseMouseWheel = false;
        }

        private void radioButton_InverseMouseWheelInverse_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.InverseMouseWheel = true;
        }

        private void radioButton_InverseMouseButtonDefault_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.InverseMouseButton = false;
        }

        private void radioButton_InverseMouseButtonInverse_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.InverseMouseButton = true;
        }

        private void checkBox_RatioEnable_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.EnableControlRatio = checkBox_RatioEnable.Checked;
            if (checkBox_RatioEnable.Checked == true)
                trackBar_Ratio.Enabled = true;
            else
                trackBar_Ratio.Enabled = false;
        }

        private void buttonZoomFit_Click(object sender, EventArgs e)
        {
            double llx = Double.Parse(textBox_LLX.Text);
            double lly = Double.Parse(textBox_LLY.Text);
            double urx = Double.Parse(textBox_URX.Text);
            double ury = Double.Parse(textBox_URY.Text);

            int nScale = 0;
            if (comboBox_Scale.Enabled) nScale = comboBox_Scale.SelectedIndex;
            else                        nScale = nxMilmapView.GetDrawArgs().ScaleIndex;

            nxMilmapView.ZoomFitRect(nScale, llx, lly, urx, ury, true);
        }

        private bool nxMilmapView_OnMouseWheel(NXMilmapView sender, MouseEventArgs e)
        {
            NXMilmapDrawArgs args = nxMilmapView.GetDrawArgs();
 //           System.Diagnostics.Debug.WriteLine("Scale Index : " + args.ScaleIndex.ToString());

            //System.Diagnostics.Debug.WriteLine("Original Args");
            //System.Diagnostics.Debug.WriteLine("====================================================================");
            //System.Diagnostics.Debug.WriteLine(" LL : " + args.LLGeo.x.ToString() + ", " + args.LLGeo.y.ToString());
            //System.Diagnostics.Debug.WriteLine(" LR : " + args.LRGeo.x.ToString() + ", " + args.LRGeo.y.ToString());
            //System.Diagnostics.Debug.WriteLine(" UL : " + args.ULGeo.x.ToString() + ", " + args.ULGeo.y.ToString());
            //System.Diagnostics.Debug.WriteLine(" UR : " + args.URGeo.x.ToString() + ", " + args.URGeo.y.ToString());
            //System.Diagnostics.Debug.WriteLine("====================================================================");
            //System.Diagnostics.Debug.WriteLine("");
            return false;
        }

        private void radioButton_ZoomByScaleIndex_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.WheelZoomAction = NXMilmapView.eWheelZoomAction.ByScaleIndex;
        }

        private void radioButton_ZoomByZoomFactor_CheckedChanged(object sender, EventArgs e)
        {
            nxMilmapView.WheelZoomAction = NXMilmapView.eWheelZoomAction.ByZoomFactor;
        }
    }
}
