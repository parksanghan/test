﻿namespace MilmapSceneEditor
{
    partial class PointExProperty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PointExProperty));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TextBox_ID = new System.Windows.Forms.TextBox();
            this.TextBox_Name = new System.Windows.Forms.TextBox();
            this.TextBox_PointFillColor = new System.Windows.Forms.TextBox();
            this.Button_ColorDlgFill = new System.Windows.Forms.Button();
            this.comboBox_Style = new System.Windows.Forms.ComboBox();
            this.ButtonApply = new System.Windows.Forms.Button();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.textBox_PointSize = new System.Windows.Forms.TextBox();
            this.checkBox_ShowName = new System.Windows.Forms.CheckBox();
            this.Button_TextColorDlg = new System.Windows.Forms.Button();
            this.TextBox_TextColor = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox_TextAlign = new System.Windows.Forms.ComboBox();
            this.Button_ColorDlgLine = new System.Windows.Forms.Button();
            this.TextBox_PointLineColor = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox_FillStyle = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.comboBox_LineStyle = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxLineWidth = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "▶ ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "▶ Name :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 92);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "▶ PointSize :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 119);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "▶ FillColor :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 251);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "▶ Style :";
            // 
            // TextBox_ID
            // 
            this.TextBox_ID.Location = new System.Drawing.Point(95, 17);
            this.TextBox_ID.Name = "TextBox_ID";
            this.TextBox_ID.ReadOnly = true;
            this.TextBox_ID.Size = new System.Drawing.Size(131, 21);
            this.TextBox_ID.TabIndex = 5;
            this.TextBox_ID.TabStop = false;
            // 
            // TextBox_Name
            // 
            this.TextBox_Name.Location = new System.Drawing.Point(95, 41);
            this.TextBox_Name.Name = "TextBox_Name";
            this.TextBox_Name.Size = new System.Drawing.Size(131, 21);
            this.TextBox_Name.TabIndex = 1;
            // 
            // TextBox_PointFillColor
            // 
            this.TextBox_PointFillColor.Location = new System.Drawing.Point(100, 116);
            this.TextBox_PointFillColor.Name = "TextBox_PointFillColor";
            this.TextBox_PointFillColor.ReadOnly = true;
            this.TextBox_PointFillColor.Size = new System.Drawing.Size(94, 21);
            this.TextBox_PointFillColor.TabIndex = 5;
            // 
            // Button_ColorDlgFill
            // 
            this.Button_ColorDlgFill.Location = new System.Drawing.Point(196, 117);
            this.Button_ColorDlgFill.Name = "Button_ColorDlgFill";
            this.Button_ColorDlgFill.Size = new System.Drawing.Size(27, 19);
            this.Button_ColorDlgFill.TabIndex = 4;
            this.Button_ColorDlgFill.Text = "...";
            this.Button_ColorDlgFill.UseVisualStyleBackColor = true;
            this.Button_ColorDlgFill.Click += new System.EventHandler(this.Button_ColorDlg_Click);
            // 
            // comboBox_Style
            // 
            this.comboBox_Style.FormattingEnabled = true;
            this.comboBox_Style.Items.AddRange(new object[] {
            "dot",
            "rect",
            "triangle",
            "+",
            "X"});
            this.comboBox_Style.Location = new System.Drawing.Point(100, 248);
            this.comboBox_Style.Name = "comboBox_Style";
            this.comboBox_Style.Size = new System.Drawing.Size(127, 20);
            this.comboBox_Style.TabIndex = 6;
            this.comboBox_Style.SelectedIndexChanged += new System.EventHandler(this.comboBox_Style_SelectedIndexChanged);
            // 
            // ButtonApply
            // 
            this.ButtonApply.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.ButtonApply.Location = new System.Drawing.Point(101, 345);
            this.ButtonApply.Name = "ButtonApply";
            this.ButtonApply.Size = new System.Drawing.Size(59, 25);
            this.ButtonApply.TabIndex = 8;
            this.ButtonApply.Text = "Apply";
            this.ButtonApply.UseVisualStyleBackColor = true;
            this.ButtonApply.Click += new System.EventHandler(this.ButtonApply_Click);
            // 
            // button_Cancel
            // 
            this.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Cancel.Location = new System.Drawing.Point(166, 345);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(59, 25);
            this.button_Cancel.TabIndex = 9;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // textBox_PointSize
            // 
            this.textBox_PointSize.Location = new System.Drawing.Point(96, 89);
            this.textBox_PointSize.Name = "textBox_PointSize";
            this.textBox_PointSize.Size = new System.Drawing.Size(131, 21);
            this.textBox_PointSize.TabIndex = 3;
            // 
            // checkBox_ShowName
            // 
            this.checkBox_ShowName.AutoSize = true;
            this.checkBox_ShowName.Location = new System.Drawing.Point(96, 66);
            this.checkBox_ShowName.Name = "checkBox_ShowName";
            this.checkBox_ShowName.Size = new System.Drawing.Size(94, 16);
            this.checkBox_ShowName.TabIndex = 2;
            this.checkBox_ShowName.Text = "Show Name";
            this.checkBox_ShowName.UseVisualStyleBackColor = true;
            this.checkBox_ShowName.CheckedChanged += new System.EventHandler(this.checkBox_ShowName_CheckedChanged);
            // 
            // Button_TextColorDlg
            // 
            this.Button_TextColorDlg.Location = new System.Drawing.Point(196, 171);
            this.Button_TextColorDlg.Name = "Button_TextColorDlg";
            this.Button_TextColorDlg.Size = new System.Drawing.Size(27, 19);
            this.Button_TextColorDlg.TabIndex = 5;
            this.Button_TextColorDlg.Text = "...";
            this.Button_TextColorDlg.UseVisualStyleBackColor = true;
            this.Button_TextColorDlg.Click += new System.EventHandler(this.Button_TextColorDlg_Click);
            // 
            // TextBox_TextColor
            // 
            this.TextBox_TextColor.Location = new System.Drawing.Point(100, 170);
            this.TextBox_TextColor.Name = "TextBox_TextColor";
            this.TextBox_TextColor.ReadOnly = true;
            this.TextBox_TextColor.Size = new System.Drawing.Size(94, 21);
            this.TextBox_TextColor.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 173);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 12);
            this.label6.TabIndex = 12;
            this.label6.Text = "▶ Text Color :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 308);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 12);
            this.label7.TabIndex = 15;
            this.label7.Text = "▶ Text Align :";
            // 
            // comboBox_TextAlign
            // 
            this.comboBox_TextAlign.FormattingEnabled = true;
            this.comboBox_TextAlign.Items.AddRange(new object[] {
            "Center",
            "Left",
            "Right"});
            this.comboBox_TextAlign.Location = new System.Drawing.Point(100, 305);
            this.comboBox_TextAlign.Name = "comboBox_TextAlign";
            this.comboBox_TextAlign.Size = new System.Drawing.Size(127, 20);
            this.comboBox_TextAlign.TabIndex = 7;
            this.comboBox_TextAlign.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Button_ColorDlgLine
            // 
            this.Button_ColorDlgLine.Location = new System.Drawing.Point(196, 144);
            this.Button_ColorDlgLine.Name = "Button_ColorDlgLine";
            this.Button_ColorDlgLine.Size = new System.Drawing.Size(27, 19);
            this.Button_ColorDlgLine.TabIndex = 41;
            this.Button_ColorDlgLine.Text = "...";
            this.Button_ColorDlgLine.UseVisualStyleBackColor = true;
            this.Button_ColorDlgLine.Click += new System.EventHandler(this.Button_ColorDlgLine_Click);
            // 
            // TextBox_PointLineColor
            // 
            this.TextBox_PointLineColor.Location = new System.Drawing.Point(101, 143);
            this.TextBox_PointLineColor.Name = "TextBox_PointLineColor";
            this.TextBox_PointLineColor.ReadOnly = true;
            this.TextBox_PointLineColor.Size = new System.Drawing.Size(94, 21);
            this.TextBox_PointLineColor.TabIndex = 42;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 146);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 12);
            this.label11.TabIndex = 40;
            this.label11.Text = "▶ LineColor :";
            // 
            // comboBox_FillStyle
            // 
            this.comboBox_FillStyle.FormattingEnabled = true;
            this.comboBox_FillStyle.Items.AddRange(new object[] {
            "Solid",
            "Bdiagonal",
            "Cross",
            "Diag Cross",
            "FDiagonal",
            "Horizontal",
            "Vertical",
            "Hollow"});
            this.comboBox_FillStyle.Location = new System.Drawing.Point(100, 225);
            this.comboBox_FillStyle.Name = "comboBox_FillStyle";
            this.comboBox_FillStyle.Size = new System.Drawing.Size(127, 20);
            this.comboBox_FillStyle.TabIndex = 46;
            this.comboBox_FillStyle.SelectedIndexChanged += new System.EventHandler(this.comboBox_FillStyle_SelectedIndexChanged);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(12, 228);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(77, 12);
            this.label12.TabIndex = 45;
            this.label12.Text = "▶ Fill Style :";
            // 
            // comboBox_LineStyle
            // 
            this.comboBox_LineStyle.FormattingEnabled = true;
            this.comboBox_LineStyle.Items.AddRange(new object[] {
            "Solid",
            "Dash",
            "Dot",
            "Dash-Dot",
            "Dash-Dot-Dot"});
            this.comboBox_LineStyle.Location = new System.Drawing.Point(100, 201);
            this.comboBox_LineStyle.Name = "comboBox_LineStyle";
            this.comboBox_LineStyle.Size = new System.Drawing.Size(127, 20);
            this.comboBox_LineStyle.TabIndex = 44;
            this.comboBox_LineStyle.SelectedIndexChanged += new System.EventHandler(this.comboBox_LineStyle_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(12, 204);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(81, 12);
            this.label13.TabIndex = 43;
            this.label13.Text = "▶ LineStyle :";
            // 
            // textBoxLineWidth
            // 
            this.textBoxLineWidth.Location = new System.Drawing.Point(100, 275);
            this.textBoxLineWidth.Name = "textBoxLineWidth";
            this.textBoxLineWidth.Size = new System.Drawing.Size(128, 21);
            this.textBoxLineWidth.TabIndex = 48;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(12, 279);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(83, 12);
            this.label14.TabIndex = 47;
            this.label14.Text = "▶ LineWidth :";
            // 
            // PointExProperty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(244, 388);
            this.Controls.Add(this.textBoxLineWidth);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.comboBox_FillStyle);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.comboBox_LineStyle);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Button_ColorDlgLine);
            this.Controls.Add(this.TextBox_PointLineColor);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.comboBox_TextAlign);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Button_TextColorDlg);
            this.Controls.Add(this.TextBox_TextColor);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.checkBox_ShowName);
            this.Controls.Add(this.textBox_PointSize);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.ButtonApply);
            this.Controls.Add(this.Button_ColorDlgFill);
            this.Controls.Add(this.comboBox_Style);
            this.Controls.Add(this.TextBox_PointFillColor);
            this.Controls.Add(this.TextBox_Name);
            this.Controls.Add(this.TextBox_ID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PointExProperty";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "PointEx Property";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.PointExProperty_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TextBox_ID;
        private System.Windows.Forms.TextBox TextBox_Name;
        private System.Windows.Forms.TextBox TextBox_PointFillColor;
        private System.Windows.Forms.Button Button_ColorDlgFill;
        private System.Windows.Forms.ComboBox comboBox_Style;
        private System.Windows.Forms.Button ButtonApply;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.TextBox textBox_PointSize;
        private System.Windows.Forms.CheckBox checkBox_ShowName;
        private System.Windows.Forms.Button Button_TextColorDlg;
        private System.Windows.Forms.TextBox TextBox_TextColor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox_TextAlign;
        private System.Windows.Forms.Button Button_ColorDlgLine;
        private System.Windows.Forms.TextBox TextBox_PointLineColor;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox_FillStyle;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.ComboBox comboBox_LineStyle;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBoxLineWidth;
        private System.Windows.Forms.Label label14;
    }
}