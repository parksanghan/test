﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL;
using Pixoneer.NXDL.NXMilmap;
using Pixoneer.NXDL.NCC;
using System.Reflection;
using Pixoneer.NXDL.NSCENE;

namespace MilmapSceneEditor
{
    public partial class MainForm : Form
    {
        public enum _Tag_TreeKey_
        {
            [Description("POINT")]            _TREE_KEY_POINT,
            [Description("POINTEX")]          _TREE_KEY_POINTEX,
            [Description("POLYLINE")]         _TREE_KEY_POLYLINE,
            [Description("POLYGON")]          _TREE_KEY_POLYGON,
            [Description("CIRCLE")]           _TREE_KEY_CIRCLE,
            [Description("SYMBOL")]           _TREE_KEY_SYMBOL,
            [Description("MODEL")]            _TREE_KEY_MODEL,
            [Description("Text")]             _TREE_KEY_TEXT,
        };
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

            if (NXMilmapView.m_MapEngine.InitFromXML("c:\\Pixoneer\\XDL3.0\\Config\\XMilmapConfig.xml") == false)
            {
                MessageBox.Show("XMilmapConfig.xml Load Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            nxMilmapLayerSceneEditor.AttachTo(nxMilmapView);
            nxMilmapLayerSceneDisplay.AttachTo(nxMilmapViewDisplay);

            int nScale = nxMilmapView.GetDrawArgs().ScaleIndex;
            XVertex2d vGeopos = new XVertex2d(128, 36);
            nxMilmapView.SetGeoToCenter(nScale, vGeopos);
            nxMilmapView.WheelZoomAction = NXMilmapView.eWheelZoomAction.ByZoomFactor;

            radioButton_OrderDefault.Checked = true;
            InitialTreeControl();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Xfn.Close();
        }

        private void AddSaveSceneButton_Click(object sender, EventArgs e)
        {
            XScene scene = nxMilmapLayerSceneEditor.GetScene();
            if (scene == null || scene.GetNextID() == 0)
            {
                MessageBox.Show("편집중인 Scene이 없습니다.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            SaveFileDialog saveScene = new SaveFileDialog();
            saveScene.Title = "Save Scene File";
            saveScene.DefaultExt = "sml";
            saveScene.Filter = "Scene Files|*.sml";
            XSpatialReference sr = null;
            sr = new XSpatialReference();
            sr.SetWellKnownGeogCS("WGS84");

            if (saveScene.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                bool bres = XScene.SaveScene(scene, saveScene.FileName, sr);
                if (bres)
                    MessageBox.Show("Scene File Save Succeed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Scene File Save Failed", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void AddLoadSceneButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Scene Files|*.sml";
            openFileDialog1.Title = "Select Scene File";

            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                bool bres = nxMilmapLayerSceneDisplay.Open(openFileDialog1.FileName);
                if (bres == true)
                    MessageBox.Show("Scene File Load Succeed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Scene File Load Failed", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            nxMilmapViewDisplay.Refresh();

        }
        public static string GetEnumDescription(Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            DescriptionAttribute[] attributes =
                (DescriptionAttribute[])fi.GetCustomAttributes(
                typeof(DescriptionAttribute),
                false);

            if (attributes != null &&
                attributes.Length > 0)
                return attributes[0].Description;
            else
                return value.ToString();
        }

        private bool nxMilmapLayerSceneEditor_OnObjectCreated(Pixoneer.NXDL.NSCENE.XscObj pObj)
        {
            if (pObj == null) return false;
            if (pObj.GetTypeName() == "XscPoint")
            {
                XscPoint ob = (XscPoint)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POINT);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscPointEx")
            {
                XscPointEx ob = (XscPointEx)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POINTEX);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscPolyLine")
            {
                XscPolyLine ob = (XscPolyLine)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POLYLINE);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscPolygon")
            {
                XscPolygon ob = (XscPolygon)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POLYGON);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscCircle")
            {
                XscCircle ob = (XscCircle)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_CIRCLE);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscSymbol")
            {
                XscSymbol ob = (XscSymbol)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_SYMBOL);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscText")
            {
                XscText ob = (XscText)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_TEXT);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            UpdateListView();
            nxMilmapView.RefreshScreen();
            return default(bool);
        }

        private void toolStripButtonMeasure_None_Click(object sender, EventArgs e)
        {
           nxMilmapView.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.None;
        }

        private void toolStripButtonMeasure_Distance_Click(object sender, EventArgs e)
        {
            nxMilmapView.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.DistanceMeasurer;
        }

        private void toolStripButtonMeasure_Path_Click(object sender, EventArgs e)
        {
            nxMilmapView.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.PathMeasurer;
        }

        private void toolStripButtonMeasure_Area_Click(object sender, EventArgs e)
        {
            nxMilmapView.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.AreaMeasurer;
        }

        private void toolStripButtonMeasure_Circle_Click(object sender, EventArgs e)
        {
            nxMilmapView.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.CircleMeasurer;
        }

        private void toolStripButtonMeasure_Angle_Click(object sender, EventArgs e)
        {
            nxMilmapView.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.AngleMeasurer;
        }

       

    }
}
