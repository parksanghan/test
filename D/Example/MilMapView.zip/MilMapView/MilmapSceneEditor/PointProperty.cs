﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NGR;

namespace MilmapSceneEditor
{
    public partial class PointProperty : Form
    {
        private int m_nID = -1;
        private double m_dPointSize = 0.0;
        private bool m_bShowName;
        private string m_strName;
        private Color m_Color;
        private Color m_TextColor;
        private Pixoneer.NXDL.NSCENE.XscPoint.ePointType m_type;
        private eTextAlign m_TextAlign;

        public Pixoneer.NXDL.NGR.eTextAlign TextAlign
        {
            get { return m_TextAlign; }
            set { m_TextAlign = value; }
        }
        public int ID
        {
            get { return m_nID; }
            set { m_nID = value; }
        }
        public string ObjectName
        {
            get { return m_strName; }
            set { m_strName = value; }
        }
        public System.Drawing.Color Color
        {
            get { return m_Color; }
            set { m_Color = value; }
        }
        public System.Drawing.Color TextColor
        {
            get { return m_TextColor; }
            set { m_TextColor = value; }
        }
        public Pixoneer.NXDL.NSCENE.XscPoint.ePointType Type
        {
            get { return m_type; }
            set { m_type = value; }
        }
        public double PointSize
        {
            get { return m_dPointSize; }
            set { m_dPointSize = value; }
        }
        public bool ShowName
        {
            get { return m_bShowName; }
            set { m_bShowName = value; }
        }
        public PointProperty()
        {
            InitializeComponent();
        }

        private void PointProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = string.Format("{0}", m_nID);
            TextBox_Name.Text = m_strName;
            textBox_PointSize.Text = string.Format("{0}", m_dPointSize);
            TextBox_PointColor.BackColor = m_Color;
            TextBox_TextColor.BackColor = m_TextColor;
            comboBox_Style.SelectedIndex = (int)m_type;
            comboBox_TextAlign.SelectedIndex = (int)m_TextAlign;
            checkBox_ShowName.Checked = ShowName;
        }

        private void Button_ColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_Color;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_Color = dlg.Color;
                TextBox_PointColor.BackColor = m_Color;
            }
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            m_strName = TextBox_Name.Text;
            m_dPointSize = double.Parse(textBox_PointSize.Text);
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
           
        }

        private void comboBox_Style_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_type = (Pixoneer.NXDL.NSCENE.XscPoint.ePointType)comboBox_Style.SelectedIndex;
        }

        private void checkBox_ShowName_CheckedChanged(object sender, EventArgs e)
        {
            ShowName = checkBox_ShowName.Checked;
        }

        private void Button_TextColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_Color;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_TextColor = dlg.Color;
                TextBox_TextColor.BackColor = m_TextColor;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlign = (eTextAlign)comboBox_TextAlign.SelectedIndex;
        }
    }
}
