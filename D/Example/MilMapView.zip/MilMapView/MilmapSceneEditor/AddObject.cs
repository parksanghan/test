﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NSCENE;

namespace MilmapSceneEditor
{
    public partial class MainForm : Form
    {

        private void AddPointButton_Click(object sender, EventArgs e)
        {
            nxMilmapLayerSceneEditor.CreateNewOBJ("XscPoint");
        }

        private void AddPointExButton_Click(object sender, EventArgs e)
        {
            nxMilmapLayerSceneEditor.CreateNewOBJ("XscPointEx");
        }

        private void AddPolyLineButton_Click(object sender, EventArgs e)
        {
            nxMilmapLayerSceneEditor.CreateNewOBJ("XscPolyLine");
        }

        private void AddPolygonButton_Click(object sender, EventArgs e)
        {
            nxMilmapLayerSceneEditor.CreateNewOBJ("XscPolygon");
        }

        private void AddCircleButton_Click(object sender, EventArgs e)
        {
            nxMilmapLayerSceneEditor.CreateNewOBJ("XscCircle");
        }

        private void AddSymbolButton_Click(object sender, EventArgs e)
        {
            nxMilmapLayerSceneEditor.CreateNewOBJ("XscSymbol");
        }
        private void AddTextButton_Click(object sender, EventArgs e)
        {
            nxMilmapLayerSceneEditor.CreateNewOBJ("XscText");
        }
    }
}
