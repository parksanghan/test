﻿namespace MilmapSceneEditor
{
    partial class SymbolProperty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SymbolProperty));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TextBox_ID = new System.Windows.Forms.TextBox();
            this.TextBox_Name = new System.Windows.Forms.TextBox();
            this.ButtonApply = new System.Windows.Forms.Button();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.checkBox_ShowName = new System.Windows.Forms.CheckBox();
            this.Button_TextColorDlg = new System.Windows.Forms.Button();
            this.TextBox_TextColor = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox_TextAlign = new System.Windows.Forms.ComboBox();
            this.comboBox_Symbol = new System.Windows.Forms.ComboBox();
            this.Radio_DefineSymbol = new System.Windows.Forms.RadioButton();
            this.Radio_UserSymbol = new System.Windows.Forms.RadioButton();
            this.textBox_UserSymbol = new System.Windows.Forms.TextBox();
            this.button_OpenUserSymbol = new System.Windows.Forms.Button();
            this.textBoxAngle = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "▶ ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "▶ Name :";
            // 
            // TextBox_ID
            // 
            this.TextBox_ID.Location = new System.Drawing.Point(95, 17);
            this.TextBox_ID.Name = "TextBox_ID";
            this.TextBox_ID.ReadOnly = true;
            this.TextBox_ID.Size = new System.Drawing.Size(131, 21);
            this.TextBox_ID.TabIndex = 5;
            // 
            // TextBox_Name
            // 
            this.TextBox_Name.Location = new System.Drawing.Point(95, 50);
            this.TextBox_Name.Name = "TextBox_Name";
            this.TextBox_Name.Size = new System.Drawing.Size(131, 21);
            this.TextBox_Name.TabIndex = 5;
            // 
            // ButtonApply
            // 
            this.ButtonApply.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.ButtonApply.Location = new System.Drawing.Point(99, 307);
            this.ButtonApply.Name = "ButtonApply";
            this.ButtonApply.Size = new System.Drawing.Size(59, 25);
            this.ButtonApply.TabIndex = 8;
            this.ButtonApply.Text = "Apply";
            this.ButtonApply.UseVisualStyleBackColor = true;
            this.ButtonApply.Click += new System.EventHandler(this.ButtonApply_Click);
            // 
            // button_Cancel
            // 
            this.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Cancel.Location = new System.Drawing.Point(164, 307);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(59, 25);
            this.button_Cancel.TabIndex = 9;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // checkBox_ShowName
            // 
            this.checkBox_ShowName.AutoSize = true;
            this.checkBox_ShowName.Location = new System.Drawing.Point(96, 80);
            this.checkBox_ShowName.Name = "checkBox_ShowName";
            this.checkBox_ShowName.Size = new System.Drawing.Size(94, 16);
            this.checkBox_ShowName.TabIndex = 11;
            this.checkBox_ShowName.Text = "Show Name";
            this.checkBox_ShowName.UseVisualStyleBackColor = true;
            this.checkBox_ShowName.CheckedChanged += new System.EventHandler(this.checkBox_ShowName_CheckedChanged);
            // 
            // Button_TextColorDlg
            // 
            this.Button_TextColorDlg.Location = new System.Drawing.Point(197, 108);
            this.Button_TextColorDlg.Name = "Button_TextColorDlg";
            this.Button_TextColorDlg.Size = new System.Drawing.Size(27, 19);
            this.Button_TextColorDlg.TabIndex = 14;
            this.Button_TextColorDlg.Text = "...";
            this.Button_TextColorDlg.UseVisualStyleBackColor = true;
            this.Button_TextColorDlg.Click += new System.EventHandler(this.Button_TextColorDlg_Click);
            // 
            // TextBox_TextColor
            // 
            this.TextBox_TextColor.Location = new System.Drawing.Point(96, 107);
            this.TextBox_TextColor.Name = "TextBox_TextColor";
            this.TextBox_TextColor.ReadOnly = true;
            this.TextBox_TextColor.Size = new System.Drawing.Size(94, 21);
            this.TextBox_TextColor.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(11, 110);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 12);
            this.label6.TabIndex = 12;
            this.label6.Text = "▶ Text Color :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 12);
            this.label7.TabIndex = 15;
            this.label7.Text = "▶ Text Align :";
            // 
            // comboBox_TextAlign
            // 
            this.comboBox_TextAlign.FormattingEnabled = true;
            this.comboBox_TextAlign.Items.AddRange(new object[] {
            "Center",
            "Left",
            "Right"});
            this.comboBox_TextAlign.Location = new System.Drawing.Point(96, 138);
            this.comboBox_TextAlign.Name = "comboBox_TextAlign";
            this.comboBox_TextAlign.Size = new System.Drawing.Size(127, 20);
            this.comboBox_TextAlign.TabIndex = 16;
            this.comboBox_TextAlign.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // comboBox_Symbol
            // 
            this.comboBox_Symbol.FormattingEnabled = true;
            this.comboBox_Symbol.Items.AddRange(new object[] {
            "Image",
            "Apartment",
            "Model",
            "Public",
            "Stadium",
            "TextChart",
            "UserDefine"});
            this.comboBox_Symbol.Location = new System.Drawing.Point(95, 192);
            this.comboBox_Symbol.Name = "comboBox_Symbol";
            this.comboBox_Symbol.Size = new System.Drawing.Size(129, 20);
            this.comboBox_Symbol.TabIndex = 18;
            this.comboBox_Symbol.SelectedIndexChanged += new System.EventHandler(this.comboBox_Symbol_SelectedIndexChanged);
            // 
            // Radio_DefineSymbol
            // 
            this.Radio_DefineSymbol.AutoSize = true;
            this.Radio_DefineSymbol.Location = new System.Drawing.Point(14, 170);
            this.Radio_DefineSymbol.Name = "Radio_DefineSymbol";
            this.Radio_DefineSymbol.Size = new System.Drawing.Size(109, 16);
            this.Radio_DefineSymbol.TabIndex = 19;
            this.Radio_DefineSymbol.TabStop = true;
            this.Radio_DefineSymbol.Text = "Define Symbol ";
            this.Radio_DefineSymbol.UseVisualStyleBackColor = true;
            this.Radio_DefineSymbol.CheckedChanged += new System.EventHandler(this.Radio_DefineSymbol_CheckedChanged);
            // 
            // Radio_UserSymbol
            // 
            this.Radio_UserSymbol.AutoSize = true;
            this.Radio_UserSymbol.Location = new System.Drawing.Point(14, 218);
            this.Radio_UserSymbol.Name = "Radio_UserSymbol";
            this.Radio_UserSymbol.Size = new System.Drawing.Size(92, 16);
            this.Radio_UserSymbol.TabIndex = 20;
            this.Radio_UserSymbol.TabStop = true;
            this.Radio_UserSymbol.Text = "UserSymbol";
            this.Radio_UserSymbol.UseVisualStyleBackColor = true;
            this.Radio_UserSymbol.CheckedChanged += new System.EventHandler(this.Radio_UserSymbol_CheckedChanged);
            // 
            // textBox_UserSymbol
            // 
            this.textBox_UserSymbol.Location = new System.Drawing.Point(23, 240);
            this.textBox_UserSymbol.Name = "textBox_UserSymbol";
            this.textBox_UserSymbol.ReadOnly = true;
            this.textBox_UserSymbol.Size = new System.Drawing.Size(167, 21);
            this.textBox_UserSymbol.TabIndex = 21;
            // 
            // button_OpenUserSymbol
            // 
            this.button_OpenUserSymbol.Location = new System.Drawing.Point(196, 240);
            this.button_OpenUserSymbol.Name = "button_OpenUserSymbol";
            this.button_OpenUserSymbol.Size = new System.Drawing.Size(27, 19);
            this.button_OpenUserSymbol.TabIndex = 22;
            this.button_OpenUserSymbol.Text = "...";
            this.button_OpenUserSymbol.UseVisualStyleBackColor = true;
            this.button_OpenUserSymbol.Click += new System.EventHandler(this.button_OpenUserSymbol_Click);
            // 
            // textBoxAngle
            // 
            this.textBoxAngle.Location = new System.Drawing.Point(96, 267);
            this.textBoxAngle.Name = "textBoxAngle";
            this.textBoxAngle.Size = new System.Drawing.Size(131, 21);
            this.textBoxAngle.TabIndex = 24;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 270);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 12);
            this.label3.TabIndex = 23;
            this.label3.Text = "▶ Angle :";
            // 
            // SymbolProperty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(244, 344);
            this.Controls.Add(this.textBoxAngle);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button_OpenUserSymbol);
            this.Controls.Add(this.textBox_UserSymbol);
            this.Controls.Add(this.Radio_UserSymbol);
            this.Controls.Add(this.Radio_DefineSymbol);
            this.Controls.Add(this.comboBox_Symbol);
            this.Controls.Add(this.comboBox_TextAlign);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Button_TextColorDlg);
            this.Controls.Add(this.TextBox_TextColor);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.checkBox_ShowName);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.ButtonApply);
            this.Controls.Add(this.TextBox_Name);
            this.Controls.Add(this.TextBox_ID);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "SymbolProperty";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Symbol Property";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.SymbolProperty_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TextBox_ID;
        private System.Windows.Forms.TextBox TextBox_Name;
        private System.Windows.Forms.Button ButtonApply;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.CheckBox checkBox_ShowName;
        private System.Windows.Forms.Button Button_TextColorDlg;
        private System.Windows.Forms.TextBox TextBox_TextColor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox_TextAlign;
        private System.Windows.Forms.ComboBox comboBox_Symbol;
        private System.Windows.Forms.RadioButton Radio_DefineSymbol;
        private System.Windows.Forms.RadioButton Radio_UserSymbol;
        private System.Windows.Forms.TextBox textBox_UserSymbol;
        private System.Windows.Forms.Button button_OpenUserSymbol;
        private System.Windows.Forms.TextBox textBoxAngle;
        private System.Windows.Forms.Label label3;
    }
}