﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NGR;

namespace MilmapSceneEditor
{
    public partial class SymbolProperty : Form
    {
        private int m_nID = -1;
        private bool m_bShowName;
        private string m_strName;
        private string m_strImageFile;
        private string m_symbol;
        private Color m_TextColor;
        private eTextAlign m_TextAlign;
        private bool m_bUseDefaultSymbol = true;
        private double m_dblAngle;

        public bool UseDefaultSymbol
        {
            get { return m_bUseDefaultSymbol; }
            set { m_bUseDefaultSymbol = value; }
        }
        public string ImageFile
        {
            get { return m_strImageFile; }
            set { m_strImageFile = value; }
        }
        public string Symbol
        {
            get { return m_symbol; }
            set { m_symbol = value; }
        }
        public Pixoneer.NXDL.NGR.eTextAlign TextAlign
        {
            get { return m_TextAlign; }
            set { m_TextAlign = value; }
        }
        public int ID
        {
            get { return m_nID; }
            set { m_nID = value; }
        }
        public string ObjectName
        {
            get { return m_strName; }
            set { m_strName = value; }
        }
        public System.Drawing.Color TextColor
        {
            get { return m_TextColor; }
            set { m_TextColor = value; }
        }
        public bool ShowName
        {
            get { return m_bShowName; }
            set { m_bShowName = value; }
        }
        public double RotateAngle
        {
            get { return m_dblAngle; }
            set { m_dblAngle = value;  }
        }
        public SymbolProperty()
        {
            InitializeComponent();
        }

        private void SymbolProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = string.Format("{0}", m_nID);
            TextBox_Name.Text = m_strName;
            TextBox_TextColor.BackColor = m_TextColor;
            comboBox_TextAlign.SelectedIndex = (int)m_TextAlign;
            checkBox_ShowName.Checked = ShowName;
            Radio_DefineSymbol.Checked = true;
            Radio_UserSymbol.Checked = false;

            for (int i = 0; i < comboBox_Symbol.Items.Count; i++)
            {
                string itemName = comboBox_Symbol.GetItemText(comboBox_Symbol.Items[i]);
                if (itemName == m_symbol)
                {
                    comboBox_Symbol.SelectedIndex = i;
                    break;
                }
            }

            textBoxAngle.Text = m_dblAngle.ToString();
        }


        private void ButtonApply_Click(object sender, EventArgs e)
        {
            m_strName = TextBox_Name.Text;
            m_strImageFile = textBox_UserSymbol.Text;
            m_symbol = comboBox_Symbol.GetItemText(comboBox_Symbol.Items[comboBox_Symbol.SelectedIndex]);
            m_dblAngle = Double.Parse(textBoxAngle.Text);
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
           
        }
        
        private void checkBox_ShowName_CheckedChanged(object sender, EventArgs e)
        {
            ShowName = checkBox_ShowName.Checked;
        }

        private void Button_TextColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_TextColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_TextColor = dlg.Color;
                TextBox_TextColor.BackColor = m_TextColor;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlign = (eTextAlign)comboBox_TextAlign.SelectedIndex;
        }

        private void button_OpenUserSymbol_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "PNG Files|*.png";
            openFileDialog1.Title = "Select Symbol File";

            // Show the Dialog.
            // If the user clicked OK in the dialog and
            // a .CUR file was selected, open it.
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_strImageFile = openFileDialog1.FileName;
                textBox_UserSymbol.Text = m_strImageFile;
            }
        }

        private void comboBox_Symbol_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Radio_DefineSymbol_CheckedChanged(object sender, EventArgs e)
        {
            button_OpenUserSymbol.Enabled = !Radio_DefineSymbol.Checked;
            comboBox_Symbol.Enabled = Radio_DefineSymbol.Checked;
            m_bUseDefaultSymbol = Radio_DefineSymbol.Checked;
        }

        private void Radio_UserSymbol_CheckedChanged(object sender, EventArgs e)
        {
            button_OpenUserSymbol.Enabled = Radio_UserSymbol.Checked;
            comboBox_Symbol.Enabled = !Radio_UserSymbol.Checked;
            m_bUseDefaultSymbol = !Radio_UserSymbol.Checked;
        }
    }
}
