﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NGR;

namespace MilmapSceneEditor
{
    public partial class CircleProperty : Form
    {
        private int m_nID = -1;
        private double m_dLineWidth = 0.0;
        private double m_dRadius;
        private bool m_bShowName;
        private string m_strName;
        private Color m_LineColor;
        private Color m_FillColor;
        private Color m_TextColor;
        private Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType m_type;
        private eTextAlign m_TextAlign;
        public double Radius
        {
            get { return m_dRadius; }
            set { m_dRadius = value; }
        }
        public System.Drawing.Color FillColor
        {
            get { return m_FillColor; }
            set { m_FillColor = value; }
        }

        public Pixoneer.NXDL.NGR.eTextAlign TextAlign
        {
            get { return m_TextAlign; }
            set { m_TextAlign = value; }
        }
        public int ID
        {
            get { return m_nID; }
            set { m_nID = value; }
        }
        public string ObjectName
        {
            get { return m_strName; }
            set { m_strName = value; }
        }
        public System.Drawing.Color LineColor
        {
            get { return m_LineColor; }
            set { m_LineColor = value; }
        }
        public System.Drawing.Color TextColor
        {
            get { return m_TextColor; }
            set { m_TextColor = value; }
        }
        public Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType Type
        {
            get { return m_type; }
            set { m_type = value; }
        }
        public double LineWidth
        {
            get { return m_dLineWidth; }
            set { m_dLineWidth = value; }
        }
        public bool ShowName
        {
            get { return m_bShowName; }
            set { m_bShowName = value; }
        }
        public CircleProperty()
        {
            InitializeComponent();
        }

        private void CircleProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = string.Format("{0}", m_nID);
            TextBox_Name.Text = m_strName;
            textBox_PointSize.Text = string.Format("{0}", m_dLineWidth);
            TextBox_PointColor.BackColor = m_LineColor;
            TextBox_TextColor.BackColor = m_TextColor;
            textBox_Radius.Text = string.Format("{0}", m_dRadius);
            textBox_FillColor.BackColor = Color.FromArgb(m_FillColor.R, m_FillColor.G, m_FillColor.B);
            switch(m_type)
            {
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid:
                    comboBox_Style.SelectedIndex = 0; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dash:
                    comboBox_Style.SelectedIndex = 1; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dot:
                    comboBox_Style.SelectedIndex = 2; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDot:
                    comboBox_Style.SelectedIndex = 3; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDotDot:
                    comboBox_Style.SelectedIndex = 4; break;
            }
            comboBox_TextAlign.SelectedIndex = (int)m_TextAlign;
            checkBox_ShowName.Checked = ShowName;
        }

        private void Button_ColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_LineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_LineColor = dlg.Color;
                TextBox_PointColor.BackColor = m_LineColor;
            }
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            m_strName = TextBox_Name.Text;
            m_dLineWidth = double.Parse(textBox_PointSize.Text);
            m_dRadius = double.Parse(textBox_Radius.Text);
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
           
        }

        private void comboBox_Style_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Style.SelectedIndex)
            {
                case 0:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid;
                    break;
                case 1:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dash;
                    break;
                case 2:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dot;
                    break;
                case 3:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDot;
                    break;
                case 4:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDotDot;
                    break;
            }
        }

        private void checkBox_ShowName_CheckedChanged(object sender, EventArgs e)
        {
            ShowName = checkBox_ShowName.Checked;
        }

        private void Button_TextColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_LineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_TextColor = dlg.Color;
                TextBox_TextColor.BackColor = m_TextColor;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlign = (eTextAlign)comboBox_TextAlign.SelectedIndex;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_LineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                byte alpha = m_FillColor.A;
                m_FillColor = dlg.Color;
                textBox_FillColor.BackColor = m_FillColor;
                m_FillColor = Color.FromArgb(255, dlg.Color.R, dlg.Color.G, dlg.Color.B);
            }
        }
    }
}
