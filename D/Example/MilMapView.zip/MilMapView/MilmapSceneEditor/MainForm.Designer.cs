﻿namespace MilmapSceneEditor
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.MainToolBar = new System.Windows.Forms.ToolStrip();
            this.AddLabel = new System.Windows.Forms.ToolStripLabel();
            this.AddPointButton = new System.Windows.Forms.ToolStripButton();
            this.AddPointExButton = new System.Windows.Forms.ToolStripButton();
            this.AddPolyLineButton = new System.Windows.Forms.ToolStripButton();
            this.AddPolygonButton = new System.Windows.Forms.ToolStripButton();
            this.AddCircleButton = new System.Windows.Forms.ToolStripButton();
            this.AddSymbolButton = new System.Windows.Forms.ToolStripButton();
            this.AddTextButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.LabelIO = new System.Windows.Forms.ToolStripLabel();
            this.AddSaveSceneButton = new System.Windows.Forms.ToolStripButton();
            this.AddLoadSceneButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButtonMeasure_None = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonMeasure_Distance = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonMeasure_Path = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonMeasure_Area = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonMeasure_Circle = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonMeasure_Angle = new System.Windows.Forms.ToolStripButton();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.ObjectTree = new System.Windows.Forms.TreeView();
            this.listView_DisplayOrder = new System.Windows.Forms.ListView();
            this.columnHeader_DisplayDefault = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_DisplaySequence = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_DisplayUser = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox_DisplayOrder = new System.Windows.Forms.GroupBox();
            this.radioButton_OrderUser = new System.Windows.Forms.RadioButton();
            this.radioButton_OrderSequence = new System.Windows.Forms.RadioButton();
            this.radioButton_OrderDefault = new System.Windows.Forms.RadioButton();
            this.splitContainerView = new System.Windows.Forms.SplitContainer();
            this.nxMilmapView = new Pixoneer.NXDL.NXMilmap.NXMilmapView();
            this.nxMilmapViewDisplay = new Pixoneer.NXDL.NXMilmap.NXMilmapView();
            this.nxMilmapLayerSceneEditor = new Pixoneer.NXDL.NSCENE.NXMilmapLayerSceneEditor();
            this.itemContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MenuProperty = new System.Windows.Forms.ToolStripMenuItem();
            this.nxMilmapLayerSceneDisplay = new Pixoneer.NXDL.NSCENE.NXMilmapLayerSceneDisplay();
            this.MainToolBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox_DisplayOrder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerView)).BeginInit();
            this.splitContainerView.Panel1.SuspendLayout();
            this.splitContainerView.Panel2.SuspendLayout();
            this.splitContainerView.SuspendLayout();
            this.itemContextMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainToolBar
            // 
            this.MainToolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddLabel,
            this.AddPointButton,
            this.AddPointExButton,
            this.AddPolyLineButton,
            this.AddPolygonButton,
            this.AddCircleButton,
            this.AddSymbolButton,
            this.AddTextButton,
            this.toolStripSeparator1,
            this.LabelIO,
            this.AddSaveSceneButton,
            this.AddLoadSceneButton,
            this.toolStripSeparator2,
            this.toolStripLabel1,
            this.toolStripButtonMeasure_None,
            this.toolStripButtonMeasure_Distance,
            this.toolStripButtonMeasure_Path,
            this.toolStripButtonMeasure_Area,
            this.toolStripButtonMeasure_Circle,
            this.toolStripButtonMeasure_Angle});
            this.MainToolBar.Location = new System.Drawing.Point(0, 0);
            this.MainToolBar.Name = "MainToolBar";
            this.MainToolBar.Size = new System.Drawing.Size(1095, 25);
            this.MainToolBar.TabIndex = 0;
            this.MainToolBar.Text = "MainToolbar";
            // 
            // AddLabel
            // 
            this.AddLabel.Name = "AddLabel";
            this.AddLabel.Size = new System.Drawing.Size(75, 22);
            this.AddLabel.Text = "Add Object :";
            // 
            // AddPointButton
            // 
            this.AddPointButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddPointButton.Image = ((System.Drawing.Image)(resources.GetObject("AddPointButton.Image")));
            this.AddPointButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddPointButton.Name = "AddPointButton";
            this.AddPointButton.Size = new System.Drawing.Size(39, 22);
            this.AddPointButton.Text = "Point";
            this.AddPointButton.Click += new System.EventHandler(this.AddPointButton_Click);
            // 
            // AddPointExButton
            // 
            this.AddPointExButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddPointExButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddPointExButton.Name = "AddPointExButton";
            this.AddPointExButton.Size = new System.Drawing.Size(51, 22);
            this.AddPointExButton.Text = "PointEx";
            this.AddPointExButton.Click += new System.EventHandler(this.AddPointExButton_Click);
            // 
            // AddPolyLineButton
            // 
            this.AddPolyLineButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddPolyLineButton.Image = ((System.Drawing.Image)(resources.GetObject("AddPolyLineButton.Image")));
            this.AddPolyLineButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddPolyLineButton.Name = "AddPolyLineButton";
            this.AddPolyLineButton.Size = new System.Drawing.Size(56, 22);
            this.AddPolyLineButton.Text = "PolyLine";
            this.AddPolyLineButton.Click += new System.EventHandler(this.AddPolyLineButton_Click);
            // 
            // AddPolygonButton
            // 
            this.AddPolygonButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddPolygonButton.Image = ((System.Drawing.Image)(resources.GetObject("AddPolygonButton.Image")));
            this.AddPolygonButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddPolygonButton.Name = "AddPolygonButton";
            this.AddPolygonButton.Size = new System.Drawing.Size(55, 22);
            this.AddPolygonButton.Text = "Polygon";
            this.AddPolygonButton.Click += new System.EventHandler(this.AddPolygonButton_Click);
            // 
            // AddCircleButton
            // 
            this.AddCircleButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddCircleButton.Image = ((System.Drawing.Image)(resources.GetObject("AddCircleButton.Image")));
            this.AddCircleButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddCircleButton.Name = "AddCircleButton";
            this.AddCircleButton.Size = new System.Drawing.Size(41, 22);
            this.AddCircleButton.Text = "Circle";
            this.AddCircleButton.Click += new System.EventHandler(this.AddCircleButton_Click);
            // 
            // AddSymbolButton
            // 
            this.AddSymbolButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddSymbolButton.Image = ((System.Drawing.Image)(resources.GetObject("AddSymbolButton.Image")));
            this.AddSymbolButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddSymbolButton.Name = "AddSymbolButton";
            this.AddSymbolButton.Size = new System.Drawing.Size(52, 22);
            this.AddSymbolButton.Text = "Symbol";
            this.AddSymbolButton.Click += new System.EventHandler(this.AddSymbolButton_Click);
            // 
            // AddTextButton
            // 
            this.AddTextButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddTextButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddTextButton.Name = "AddTextButton";
            this.AddTextButton.Size = new System.Drawing.Size(31, 22);
            this.AddTextButton.Text = "text";
            this.AddTextButton.Click += new System.EventHandler(this.AddTextButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // LabelIO
            // 
            this.LabelIO.Name = "LabelIO";
            this.LabelIO.Size = new System.Drawing.Size(30, 22);
            this.LabelIO.Text = "IO : ";
            // 
            // AddSaveSceneButton
            // 
            this.AddSaveSceneButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddSaveSceneButton.Image = ((System.Drawing.Image)(resources.GetObject("AddSaveSceneButton.Image")));
            this.AddSaveSceneButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddSaveSceneButton.Name = "AddSaveSceneButton";
            this.AddSaveSceneButton.Size = new System.Drawing.Size(68, 22);
            this.AddSaveSceneButton.Text = "SaveScene";
            this.AddSaveSceneButton.Click += new System.EventHandler(this.AddSaveSceneButton_Click);
            // 
            // AddLoadSceneButton
            // 
            this.AddLoadSceneButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddLoadSceneButton.Image = ((System.Drawing.Image)(resources.GetObject("AddLoadSceneButton.Image")));
            this.AddLoadSceneButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddLoadSceneButton.Name = "AddLoadSceneButton";
            this.AddLoadSceneButton.Size = new System.Drawing.Size(73, 22);
            this.AddLoadSceneButton.Text = "Load Scene";
            this.AddLoadSceneButton.Click += new System.EventHandler(this.AddLoadSceneButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(87, 22);
            this.toolStripLabel1.Text = "Measurement :";
            // 
            // toolStripButtonMeasure_None
            // 
            this.toolStripButtonMeasure_None.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonMeasure_None.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonMeasure_None.Image")));
            this.toolStripButtonMeasure_None.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonMeasure_None.Name = "toolStripButtonMeasure_None";
            this.toolStripButtonMeasure_None.Size = new System.Drawing.Size(40, 22);
            this.toolStripButtonMeasure_None.Text = "None";
            this.toolStripButtonMeasure_None.Click += new System.EventHandler(this.toolStripButtonMeasure_None_Click);
            // 
            // toolStripButtonMeasure_Distance
            // 
            this.toolStripButtonMeasure_Distance.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonMeasure_Distance.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonMeasure_Distance.Image")));
            this.toolStripButtonMeasure_Distance.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonMeasure_Distance.Name = "toolStripButtonMeasure_Distance";
            this.toolStripButtonMeasure_Distance.Size = new System.Drawing.Size(57, 22);
            this.toolStripButtonMeasure_Distance.Text = "Distance";
            this.toolStripButtonMeasure_Distance.Click += new System.EventHandler(this.toolStripButtonMeasure_Distance_Click);
            // 
            // toolStripButtonMeasure_Path
            // 
            this.toolStripButtonMeasure_Path.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonMeasure_Path.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonMeasure_Path.Image")));
            this.toolStripButtonMeasure_Path.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonMeasure_Path.Name = "toolStripButtonMeasure_Path";
            this.toolStripButtonMeasure_Path.Size = new System.Drawing.Size(35, 22);
            this.toolStripButtonMeasure_Path.Text = "Path";
            this.toolStripButtonMeasure_Path.Click += new System.EventHandler(this.toolStripButtonMeasure_Path_Click);
            // 
            // toolStripButtonMeasure_Area
            // 
            this.toolStripButtonMeasure_Area.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonMeasure_Area.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonMeasure_Area.Image")));
            this.toolStripButtonMeasure_Area.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonMeasure_Area.Name = "toolStripButtonMeasure_Area";
            this.toolStripButtonMeasure_Area.Size = new System.Drawing.Size(35, 22);
            this.toolStripButtonMeasure_Area.Text = "Area";
            this.toolStripButtonMeasure_Area.Click += new System.EventHandler(this.toolStripButtonMeasure_Area_Click);
            // 
            // toolStripButtonMeasure_Circle
            // 
            this.toolStripButtonMeasure_Circle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonMeasure_Circle.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonMeasure_Circle.Image")));
            this.toolStripButtonMeasure_Circle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonMeasure_Circle.Name = "toolStripButtonMeasure_Circle";
            this.toolStripButtonMeasure_Circle.Size = new System.Drawing.Size(41, 22);
            this.toolStripButtonMeasure_Circle.Text = "Circle";
            this.toolStripButtonMeasure_Circle.Click += new System.EventHandler(this.toolStripButtonMeasure_Circle_Click);
            // 
            // toolStripButtonMeasure_Angle
            // 
            this.toolStripButtonMeasure_Angle.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonMeasure_Angle.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonMeasure_Angle.Image")));
            this.toolStripButtonMeasure_Angle.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonMeasure_Angle.Name = "toolStripButtonMeasure_Angle";
            this.toolStripButtonMeasure_Angle.Size = new System.Drawing.Size(42, 22);
            this.toolStripButtonMeasure_Angle.Text = "Angle";
            this.toolStripButtonMeasure_Angle.Click += new System.EventHandler(this.toolStripButtonMeasure_Angle_Click);
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 25);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.splitContainer1);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.splitContainerView);
            this.splitContainer.Size = new System.Drawing.Size(1095, 627);
            this.splitContainer.SplitterDistance = 289;
            this.splitContainer.TabIndex = 1;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.ObjectTree);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.listView_DisplayOrder);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox_DisplayOrder);
            this.splitContainer1.Size = new System.Drawing.Size(289, 627);
            this.splitContainer1.SplitterDistance = 385;
            this.splitContainer1.TabIndex = 1;
            // 
            // ObjectTree
            // 
            this.ObjectTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ObjectTree.Location = new System.Drawing.Point(0, 0);
            this.ObjectTree.Name = "ObjectTree";
            this.ObjectTree.Size = new System.Drawing.Size(289, 385);
            this.ObjectTree.TabIndex = 0;
            this.ObjectTree.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ObjectTree_MouseDown);
            // 
            // listView_DisplayOrder
            // 
            this.listView_DisplayOrder.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader_DisplayDefault,
            this.columnHeader_DisplaySequence,
            this.columnHeader_DisplayUser});
            this.listView_DisplayOrder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView_DisplayOrder.FullRowSelect = true;
            this.listView_DisplayOrder.GridLines = true;
            this.listView_DisplayOrder.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listView_DisplayOrder.HideSelection = false;
            this.listView_DisplayOrder.HoverSelection = true;
            this.listView_DisplayOrder.Location = new System.Drawing.Point(0, 48);
            this.listView_DisplayOrder.MultiSelect = false;
            this.listView_DisplayOrder.Name = "listView_DisplayOrder";
            this.listView_DisplayOrder.Size = new System.Drawing.Size(289, 190);
            this.listView_DisplayOrder.TabIndex = 0;
            this.listView_DisplayOrder.UseCompatibleStateImageBehavior = false;
            this.listView_DisplayOrder.View = System.Windows.Forms.View.Details;
            this.listView_DisplayOrder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listView_DisplayOrder_MouseDown);
            // 
            // columnHeader_DisplayDefault
            // 
            this.columnHeader_DisplayDefault.Text = "Default Order";
            this.columnHeader_DisplayDefault.Width = 87;
            // 
            // columnHeader_DisplaySequence
            // 
            this.columnHeader_DisplaySequence.Text = "Order By Seq.";
            this.columnHeader_DisplaySequence.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader_DisplaySequence.Width = 96;
            // 
            // columnHeader_DisplayUser
            // 
            this.columnHeader_DisplayUser.Text = "Order By User";
            this.columnHeader_DisplayUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader_DisplayUser.Width = 100;
            // 
            // groupBox_DisplayOrder
            // 
            this.groupBox_DisplayOrder.Controls.Add(this.radioButton_OrderUser);
            this.groupBox_DisplayOrder.Controls.Add(this.radioButton_OrderSequence);
            this.groupBox_DisplayOrder.Controls.Add(this.radioButton_OrderDefault);
            this.groupBox_DisplayOrder.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_DisplayOrder.Location = new System.Drawing.Point(0, 0);
            this.groupBox_DisplayOrder.Name = "groupBox_DisplayOrder";
            this.groupBox_DisplayOrder.Size = new System.Drawing.Size(289, 48);
            this.groupBox_DisplayOrder.TabIndex = 4;
            this.groupBox_DisplayOrder.TabStop = false;
            this.groupBox_DisplayOrder.Text = "DisplayOrder";
            // 
            // radioButton_OrderUser
            // 
            this.radioButton_OrderUser.AutoSize = true;
            this.radioButton_OrderUser.Location = new System.Drawing.Point(235, 20);
            this.radioButton_OrderUser.Name = "radioButton_OrderUser";
            this.radioButton_OrderUser.Size = new System.Drawing.Size(103, 16);
            this.radioButton_OrderUser.TabIndex = 3;
            this.radioButton_OrderUser.TabStop = true;
            this.radioButton_OrderUser.Text = "Order By User";
            this.radioButton_OrderUser.UseVisualStyleBackColor = true;
            this.radioButton_OrderUser.CheckedChanged += new System.EventHandler(this.radioButton_OrderUser_CheckedChanged);
            // 
            // radioButton_OrderSequence
            // 
            this.radioButton_OrderSequence.AutoSize = true;
            this.radioButton_OrderSequence.Location = new System.Drawing.Point(96, 20);
            this.radioButton_OrderSequence.Name = "radioButton_OrderSequence";
            this.radioButton_OrderSequence.Size = new System.Drawing.Size(134, 16);
            this.radioButton_OrderSequence.TabIndex = 2;
            this.radioButton_OrderSequence.TabStop = true;
            this.radioButton_OrderSequence.Text = "Order By Sequence";
            this.radioButton_OrderSequence.UseVisualStyleBackColor = true;
            this.radioButton_OrderSequence.CheckedChanged += new System.EventHandler(this.radioButton_OrderSequence_CheckedChanged);
            // 
            // radioButton_OrderDefault
            // 
            this.radioButton_OrderDefault.AutoSize = true;
            this.radioButton_OrderDefault.Location = new System.Drawing.Point(11, 20);
            this.radioButton_OrderDefault.Name = "radioButton_OrderDefault";
            this.radioButton_OrderDefault.Size = new System.Drawing.Size(61, 16);
            this.radioButton_OrderDefault.TabIndex = 1;
            this.radioButton_OrderDefault.TabStop = true;
            this.radioButton_OrderDefault.Text = "Default";
            this.radioButton_OrderDefault.UseVisualStyleBackColor = true;
            this.radioButton_OrderDefault.CheckedChanged += new System.EventHandler(this.radioButton_OrderDefault_CheckedChanged);
            // 
            // splitContainerView
            // 
            this.splitContainerView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainerView.Location = new System.Drawing.Point(0, 0);
            this.splitContainerView.Name = "splitContainerView";
            // 
            // splitContainerView.Panel1
            // 
            this.splitContainerView.Panel1.Controls.Add(this.nxMilmapView);
            // 
            // splitContainerView.Panel2
            // 
            this.splitContainerView.Panel2.Controls.Add(this.nxMilmapViewDisplay);
            this.splitContainerView.Size = new System.Drawing.Size(802, 627);
            this.splitContainerView.SplitterDistance = 444;
            this.splitContainerView.TabIndex = 1;
            // 
            // nxMilmapView
            // 
            this.nxMilmapView.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.nxMilmapView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nxMilmapView.EnableControlRatio = false;
            this.nxMilmapView.ForeColor = System.Drawing.SystemColors.ControlText;
            this.nxMilmapView.FreezeViewArea = false;
            this.nxMilmapView.GridType = Pixoneer.NXDL.NXMilmap.NXMilmapView.eGridType.GridNone;
            this.nxMilmapView.InverseMouseButton = false;
            this.nxMilmapView.InverseMouseWheel = false;
            this.nxMilmapView.Location = new System.Drawing.Point(0, 0);
            this.nxMilmapView.Name = "nxMilmapView";
            this.nxMilmapView.RenderCycleOn = false;
            this.nxMilmapView.Rotatable = false;
            this.nxMilmapView.ShowGrid = false;
            this.nxMilmapView.ShowPlaceName = false;
            this.nxMilmapView.Size = new System.Drawing.Size(444, 627);
            this.nxMilmapView.TabIndex = 0;
            this.nxMilmapView.ToolboxAreaUnit = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxAreaUnit.SquareMeter;
            this.nxMilmapView.ToolboxDistUnit = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxDistUnit.Meter;
            this.nxMilmapView.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.None;
            this.nxMilmapView.WheelZoomAction = Pixoneer.NXDL.NXMilmap.NXMilmapView.eWheelZoomAction.ByScaleIndex;
            this.nxMilmapView.ZoomType = Pixoneer.NXDL.NXMilmap.NXMilmapView.eZoomType.ViewCenter;
            // 
            // nxMilmapViewDisplay
            // 
            this.nxMilmapViewDisplay.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.nxMilmapViewDisplay.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nxMilmapViewDisplay.EnableControlRatio = false;
            this.nxMilmapViewDisplay.ForeColor = System.Drawing.SystemColors.ControlText;
            this.nxMilmapViewDisplay.FreezeViewArea = false;
            this.nxMilmapViewDisplay.GridType = Pixoneer.NXDL.NXMilmap.NXMilmapView.eGridType.GridNone;
            this.nxMilmapViewDisplay.InverseMouseButton = false;
            this.nxMilmapViewDisplay.InverseMouseWheel = false;
            this.nxMilmapViewDisplay.Location = new System.Drawing.Point(0, 0);
            this.nxMilmapViewDisplay.Name = "nxMilmapViewDisplay";
            this.nxMilmapViewDisplay.RenderCycleOn = false;
            this.nxMilmapViewDisplay.Rotatable = false;
            this.nxMilmapViewDisplay.ShowGrid = false;
            this.nxMilmapViewDisplay.ShowPlaceName = false;
            this.nxMilmapViewDisplay.Size = new System.Drawing.Size(354, 627);
            this.nxMilmapViewDisplay.TabIndex = 0;
            this.nxMilmapViewDisplay.ToolboxAreaUnit = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxAreaUnit.SquareMeter;
            this.nxMilmapViewDisplay.ToolboxDistUnit = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxDistUnit.Meter;
            this.nxMilmapViewDisplay.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.None;
            this.nxMilmapViewDisplay.WheelZoomAction = Pixoneer.NXDL.NXMilmap.NXMilmapView.eWheelZoomAction.ByScaleIndex;
            this.nxMilmapViewDisplay.ZoomType = Pixoneer.NXDL.NXMilmap.NXMilmapView.eZoomType.ViewCenter;
            // 
            // nxMilmapLayerSceneEditor
            // 
            this.nxMilmapLayerSceneEditor.AutoDelete = false;
            this.nxMilmapLayerSceneEditor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nxMilmapLayerSceneEditor.EditableScene = false;
            this.nxMilmapLayerSceneEditor.LayerCapture = true;
            this.nxMilmapLayerSceneEditor.LayerVisible = true;
            this.nxMilmapLayerSceneEditor.Location = new System.Drawing.Point(0, 0);
            this.nxMilmapLayerSceneEditor.Name = "nxMilmapLayerSceneEditor";
            this.nxMilmapLayerSceneEditor.Size = new System.Drawing.Size(145, 30);
            this.nxMilmapLayerSceneEditor.TabIndex = 0;
            this.nxMilmapLayerSceneEditor.UsableKeyboard = false;
            this.nxMilmapLayerSceneEditor.UseDisplayList = true;
            this.nxMilmapLayerSceneEditor.Visible = false;
            this.nxMilmapLayerSceneEditor.OnObjectCreated += new Pixoneer.NXDL.NSCENE.NXSCEditEvent(this.nxMilmapLayerSceneEditor_OnObjectCreated);
            // 
            // itemContextMenu
            // 
            this.itemContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuProperty});
            this.itemContextMenu.Name = "itemContextMenu";
            this.itemContextMenu.Size = new System.Drawing.Size(99, 26);
            // 
            // MenuProperty
            // 
            this.MenuProperty.Name = "MenuProperty";
            this.MenuProperty.Size = new System.Drawing.Size(98, 22);
            this.MenuProperty.Text = "속성";
            // 
            // nxMilmapLayerSceneDisplay
            // 
            this.nxMilmapLayerSceneDisplay.AutoDelete = false;
            this.nxMilmapLayerSceneDisplay.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nxMilmapLayerSceneDisplay.LayerCapture = true;
            this.nxMilmapLayerSceneDisplay.LayerVisible = true;
            this.nxMilmapLayerSceneDisplay.Location = new System.Drawing.Point(0, 0);
            this.nxMilmapLayerSceneDisplay.Name = "nxMilmapLayerSceneDisplay";
            this.nxMilmapLayerSceneDisplay.Size = new System.Drawing.Size(145, 30);
            this.nxMilmapLayerSceneDisplay.TabIndex = 0;
            this.nxMilmapLayerSceneDisplay.UseDisplayList = true;
            this.nxMilmapLayerSceneDisplay.Visible = false;
            this.nxMilmapLayerSceneDisplay.ZFar = 1.7E+308D;
            this.nxMilmapLayerSceneDisplay.ZNear = 1.7E+308D;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1095, 652);
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.MainToolBar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "MilmapSceneEditor";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MainToolBar.ResumeLayout(false);
            this.MainToolBar.PerformLayout();
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox_DisplayOrder.ResumeLayout(false);
            this.groupBox_DisplayOrder.PerformLayout();
            this.splitContainerView.Panel1.ResumeLayout(false);
            this.splitContainerView.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainerView)).EndInit();
            this.splitContainerView.ResumeLayout(false);
            this.itemContextMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip MainToolBar;
        private System.Windows.Forms.ToolStripLabel AddLabel;
        private System.Windows.Forms.ToolStripButton AddPointButton;
        private System.Windows.Forms.ToolStripButton AddPointExButton;
        private System.Windows.Forms.ToolStripButton AddPolyLineButton;
        private System.Windows.Forms.ToolStripButton AddPolygonButton;
        private System.Windows.Forms.ToolStripButton AddCircleButton;
        private System.Windows.Forms.ToolStripButton AddSymbolButton;
        private System.Windows.Forms.ToolStripButton AddTextButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripLabel LabelIO;
        private System.Windows.Forms.ToolStripButton AddSaveSceneButton;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.TreeView ObjectTree;
        private Pixoneer.NXDL.NXMilmap.NXMilmapView nxMilmapView;
        private Pixoneer.NXDL.NSCENE.NXMilmapLayerSceneEditor nxMilmapLayerSceneEditor;
        private System.Windows.Forms.ContextMenuStrip itemContextMenu;
        private System.Windows.Forms.ToolStripMenuItem MenuProperty;
        private System.Windows.Forms.SplitContainer splitContainerView;
        private Pixoneer.NXDL.NXMilmap.NXMilmapView nxMilmapViewDisplay;
        private Pixoneer.NXDL.NSCENE.NXMilmapLayerSceneDisplay nxMilmapLayerSceneDisplay;
        private System.Windows.Forms.ToolStripButton AddLoadSceneButton;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.RadioButton radioButton_OrderUser;
        private System.Windows.Forms.RadioButton radioButton_OrderSequence;
        private System.Windows.Forms.RadioButton radioButton_OrderDefault;
        private System.Windows.Forms.ListView listView_DisplayOrder;
        private System.Windows.Forms.ColumnHeader columnHeader_DisplayDefault;
        private System.Windows.Forms.ColumnHeader columnHeader_DisplaySequence;
        private System.Windows.Forms.ColumnHeader columnHeader_DisplayUser;
        private System.Windows.Forms.GroupBox groupBox_DisplayOrder;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButtonMeasure_None;
        private System.Windows.Forms.ToolStripButton toolStripButtonMeasure_Distance;
        private System.Windows.Forms.ToolStripButton toolStripButtonMeasure_Path;
        private System.Windows.Forms.ToolStripButton toolStripButtonMeasure_Area;
        private System.Windows.Forms.ToolStripButton toolStripButtonMeasure_Circle;
        private System.Windows.Forms.ToolStripButton toolStripButtonMeasure_Angle;
    }
}

