﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NGR;

namespace MilmapSceneGenerator
{
    public partial class SymbolProperty : Form
    {
        private int m_nID = -1;
        private bool m_bShowName;
        private string m_strName;
        private string m_strImageFile;
        private string m_symbol;
        private Color m_TextColor;
        private eTextAlign m_TextAlign;
        private bool m_bUseDefaultSymbol = true;
        private double m_dLatDegree = 0.0;
        private double m_dLonDegree = 0.0;
        private double m_dHeight = 0.0;
        private double m_dRotationAng = 0.0;
        private bool m_Hide;

        public bool ObjectHide
        {
            get { return m_Hide; }
            set { m_Hide = value; }
        }
        public double HeightMeter
        {
            get { return m_dHeight; }
            set { m_dHeight = value; }
        }
        public double LonDegree
        {
            get { return m_dLonDegree; }
            set { m_dLonDegree = value; }
        }
        public double LatDegree
        {   
            get { return m_dLatDegree; }
            set { m_dLatDegree = value; }
        }
        public double Rotation
        {
            get { return m_dRotationAng; }
            set { m_dRotationAng = value; }
        }
        public bool UseDefaultSymbol
        {
            get { return m_bUseDefaultSymbol; }
            set { m_bUseDefaultSymbol = value; }
        }
        public string ImageFile
        {
            get { return m_strImageFile; }
            set { m_strImageFile = value; }
        }
        public string Symbol
        {
            get { return m_symbol; }
            set { m_symbol = value; }
        }
        public Pixoneer.NXDL.NGR.eTextAlign TextAlign
        {
            get { return m_TextAlign; }
            set { m_TextAlign = value; }
        }
        public int ID
        {
            get { return m_nID; }
            set { m_nID = value; }
        }
        public string ObjectName
        {
            get { return m_strName; }
            set { m_strName = value; }
        }
        public System.Drawing.Color TextColor
        {
            get { return m_TextColor; }
            set { m_TextColor = value; }
        }
        public bool ShowName
        {
            get { return m_bShowName; }
            set { m_bShowName = value; }
        }
        public SymbolProperty()
        {
            InitializeComponent();
        }

        private void SymbolProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = string.Format("{0}", m_nID);
            TextBox_Name.Text = m_strName;
            TextBox_TextColor.BackColor = m_TextColor;
            comboBox_TextAlign.SelectedIndex = (int)m_TextAlign;
            checkBox_ShowName.Checked = ShowName;
            Radio_DefineSymbol.Checked = true;
            Radio_UserSymbol.Checked = false;

            for (int i = 0; i < comboBox_Symbol.Items.Count; i++)
            {
                string itemName = comboBox_Symbol.GetItemText(comboBox_Symbol.Items[i]);
                if (itemName == m_symbol)
                {
                    comboBox_Symbol.SelectedIndex = i;
                    break;
                }
            }
            if (comboBox_Symbol.SelectedIndex < 0)
                comboBox_Symbol.SelectedIndex = 0;
            textBox_Long.Text = string.Format("{0}", m_dLonDegree);
            textBox_Lat.Text = string.Format("{0}", m_dLatDegree);
            textBox_Hgt.Text = string.Format("{0}", m_dHeight);
            switch (m_Hide)
            {
                case true:
                    comboBox_Hide.SelectedIndex = 0;
                    break;
                case false:
                    comboBox_Hide.SelectedIndex = 1;
                    break;
            }

            textBox_Rotation.Text = m_dRotationAng.ToString();
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            m_strName = TextBox_Name.Text;
            m_strImageFile = textBox_UserSymbol.Text;
            m_symbol = comboBox_Symbol.GetItemText(comboBox_Symbol.Items[comboBox_Symbol.SelectedIndex]);
            m_dLonDegree = double.Parse(textBox_Long.Text);
            m_dLatDegree = double.Parse(textBox_Lat.Text);
            m_dHeight = double.Parse(textBox_Hgt.Text);
            m_dRotationAng = double.Parse(textBox_Rotation.Text);
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
           
        }
        
        private void checkBox_ShowName_CheckedChanged(object sender, EventArgs e)
        {
            ShowName = checkBox_ShowName.Checked;
        }

        private void Button_TextColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_TextColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_TextColor = dlg.Color;
                TextBox_TextColor.BackColor = m_TextColor;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlign = (eTextAlign)comboBox_TextAlign.SelectedIndex;
        }

        private void button_OpenUserSymbol_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "PNG Files|*.png";
            openFileDialog1.Title = "Select Symbol File";

            // Show the Dialog.
            // If the user clicked OK in the dialog and
            // a .CUR file was selected, open it.
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_strImageFile = openFileDialog1.FileName;
                textBox_UserSymbol.Text = m_strImageFile;
            }
        }

        private void comboBox_Symbol_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Radio_DefineSymbol_CheckedChanged(object sender, EventArgs e)
        {
            button_OpenUserSymbol.Enabled = !Radio_DefineSymbol.Checked;
            comboBox_Symbol.Enabled = Radio_DefineSymbol.Checked;
            m_bUseDefaultSymbol = Radio_DefineSymbol.Checked;
        }

        private void Radio_UserSymbol_CheckedChanged(object sender, EventArgs e)
        {
            button_OpenUserSymbol.Enabled = Radio_UserSymbol.Checked;
            comboBox_Symbol.Enabled = !Radio_UserSymbol.Checked;
            m_bUseDefaultSymbol = !Radio_UserSymbol.Checked;
        }

        private void comboBox_Hide_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Hide.SelectedIndex)
            {
                case 0:
                    m_Hide = true;
                    break;
                case 1:
                    m_Hide = false;
                    break;
            }
        }
    }
}
