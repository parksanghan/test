﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL;
using Pixoneer.NXDL.NXMilmap;
using Pixoneer.NXDL.NCC;
using System.Reflection;
using Pixoneer.NXDL.NSCENE;
using Pixoneer.NXDL.NGR;

namespace MilmapSceneGenerator
{
    public partial class MainForm : Form
    {
        public enum _Tag_TreeKey_
        {
            [Description("POINT")]            _TREE_KEY_POINT,
            [Description("POINTEX")]          _TREE_KEY_POINTEX,
            [Description("POLYLINE")]         _TREE_KEY_POLYLINE,
            [Description("POLYGON")]          _TREE_KEY_POLYGON,
            [Description("CIRCLE")]           _TREE_KEY_CIRCLE,
            [Description("SYMBOL")]           _TREE_KEY_SYMBOL,
            [Description("MODEL")]            _TREE_KEY_MODEL,
            [Description("Text")]             _TREE_KEY_TEXT,
        };

        public Pixoneer.NXDL.NXMilmap.NXMilmapLayer milmapLayer = new NXMilmapLayer();
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            if (NXMilmapView.m_MapEngine.InitFromXML("c:\\Pixoneer\\XDL3.0\\Config\\XMilmapConfig.xml") == false)
            {
                MessageBox.Show("XMilmapConfig.xml Load Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            nxMilmapLayerSceneDisplay.AttachTo(nxMilmapViewDisplay);
            nxMilmapViewDisplay.AddRenderLayer(ref milmapLayer);

           milmapLayer.OnRender += new NXMilmapLayerRenderEvent(milmapLayer_OnRender);
           milmapLayer.OnOrthoRender += new NXMilmapLayerRenderEvent(milmapLayer_OnOrthoRender);

            XSpatialReference sr = new XSpatialReference();
            sr.SetWellKnownGeogCS("WGS84");

            nxMilmapLayerSceneDisplay.New();
            nxMilmapLayerSceneDisplay.GetScene().SR = sr;

            int nScale = nxMilmapViewDisplay.GetDrawArgs().ScaleIndex;
            XVertex2d vGeopos = new XVertex2d(128, 36);
            nxMilmapViewDisplay.SetGeoToCenter(nScale, vGeopos);

            nxMilmapViewDisplay.WheelZoomAction = NXMilmapView.eWheelZoomAction.ByZoomFactor;
            nxMilmapViewDisplay.GridType = NXMilmapView.eGridType.GridDegrees;
            nxMilmapViewDisplay.ShowGrid = true;

            radioButton_OrderDefault.Checked = true;
            InitialTreeControl();
        }

        XVertex3d TempPos = new XVertex3d(127, 37, 0);
        bool milmapLayer_OnRender(object sender, NXMilmapDrawArgs e)
        {
            e.Graphics.glDisable(XGraphics.GL_DEPTH_TEST);
            e.Graphics.glEnable(XGraphics.GL_BLEND);
            e.Graphics.glBlendFunc(XGraphics.GL_SRC_ALPHA, XGraphics.GL_ONE_MINUS_SRC_ALPHA);

            /*1번코드*/
            e.Graphics.glLineWidth(1);
            NXMilmapDrawArgs drawArgs = nxMilmapViewDisplay.GetDrawArgs();
            //그리기할 센터위치 생성
            XVertex3d RenderPos = drawArgs.GeographicToWorld(new XVertex2d(TempPos.x, TempPos.y));
            e.Graphics.glPushMatrix();
            e.Graphics.glTranslated(RenderPos.x, RenderPos.y);

            e.Graphics.glScaled(1, 1, 1);
            e.Graphics.glBegin(XGraphics.GL_LINE_LOOP);
            for (double i = 0; i < 30; i++)
            {
                double theta = 360 * i / 30;
                XVertex3d CurPos = CalcPosAngle_And_Dist(TempPos, theta, 1600000);
                XVertex3d XYZ = drawArgs.GeographicToWorld(new XVertex2d(CurPos.x, CurPos.y));
                e.Graphics.glVertex2d(XYZ.x, XYZ.y);
            }
            e.Graphics.glEnd();
            e.Graphics.glPopMatrix();

            e.Graphics.glEnable(XGraphics.GL_DEPTH_TEST);
            return default(bool);
        }

        bool milmapLayer_OnOrthoRender(object sender, NXMilmapDrawArgs e)
        {
            // ortho render
            return default(bool);
        }

        public XVertex3d CalcPosAngle_And_Dist(XVertex3d _DestPos, double _Angle, double _Dist)
        {
            XAngle Lon1 = XAngle.FromDegree(_DestPos.x);
            XAngle Lat1 = XAngle.FromDegree(_DestPos.y);
            XAngle Angle = XAngle.FromDegree(_Angle);
            XAngle Lon2 = new XAngle();
            XAngle Lat2 = new XAngle();
            Xfn.CalcPosByBearingAndDist(Lon1, Lat1, Angle, _Dist, ref Lon2, ref Lat2);

            return new XVertex3d(Lon2.deg, Lat2.deg, 0);
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Xfn.Close();
        }

        private void AddSaveSceneButton_Click(object sender, EventArgs e)
        {
            XScene scene = nxMilmapLayerSceneDisplay.GetScene();
            if (scene == null || scene.GetNextID() == 0)
            {
                MessageBox.Show("편집중인 Scene이 없습니다.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            SaveFileDialog saveScene = new SaveFileDialog();
            saveScene.Title = "Save Scene File";
            saveScene.DefaultExt = "sml";
            saveScene.Filter = "Scene Files|*.sml";
            XSpatialReference sr = null;
            sr = new XSpatialReference();
            sr.SetWellKnownGeogCS("WGS84");

            if (saveScene.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                bool bres = XScene.SaveScene(scene, saveScene.FileName, sr);
                if (bres)
                    MessageBox.Show("Scene File Save Succeed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Scene File Save Failed", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void AddLoadSceneButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Scene Files|*.sml";
            openFileDialog1.Title = "Select Scene File";

            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                bool bres = nxMilmapLayerSceneDisplay.Open(openFileDialog1.FileName);
                if (bres == true)
                    MessageBox.Show("Scene File Load Succeed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Scene File Load Failed", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            nxMilmapViewDisplay.Refresh();
        }

        public static string GetEnumDescription(Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            DescriptionAttribute[] attributes =
                (DescriptionAttribute[])fi.GetCustomAttributes(
                typeof(DescriptionAttribute),
                false);

            if (attributes != null &&
                attributes.Length > 0)
                return attributes[0].Description;
            else
                return value.ToString();
        }

        private bool nxMilmapLayerSceneEditor_OnObjectCreated(Pixoneer.NXDL.NSCENE.XscObj pObj)
        {
            if (pObj == null) return false;
            if (pObj.GetTypeName() == "XscPoint")
            {
                XscPoint ob = (XscPoint)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POINT);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscPointEx")
            {
                XscPointEx ob = (XscPointEx)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POINTEX);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscPolyLine")
            {
                XscPolyLine ob = (XscPolyLine)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POLYLINE);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscPolygon")
            {
                XscPolygon ob = (XscPolygon)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POLYGON);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscCircle")
            {
                XscCircle ob = (XscCircle)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_CIRCLE);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscSymbol")
            {
                XscSymbol ob = (XscSymbol)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_SYMBOL);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscText")
            {
                XscText ob = (XscText)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_TEXT);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            UpdateListView();
            nxMilmapViewDisplay.RefreshScreen();
            return default(bool);
        }

        private void toolStripButtonMeasure_None_Click(object sender, EventArgs e)
        {
           nxMilmapViewDisplay.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.None;
        }

        private void toolStripButtonMeasure_Distance_Click(object sender, EventArgs e)
        {
            nxMilmapViewDisplay.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.DistanceMeasurer;
        }

        private void toolStripButtonMeasure_Path_Click(object sender, EventArgs e)
        {
            nxMilmapViewDisplay.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.PathMeasurer;
        }

        private void toolStripButtonMeasure_Area_Click(object sender, EventArgs e)
        {
            nxMilmapViewDisplay.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.AreaMeasurer;
        }

        private void toolStripButtonMeasure_Circle_Click(object sender, EventArgs e)
        {
            nxMilmapViewDisplay.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.CircleMeasurer;
        }

        private void toolStripButtonMeasure_Angle_Click(object sender, EventArgs e)
        {
            nxMilmapViewDisplay.ToolboxMode = Pixoneer.NXDL.NXMilmap.NXMilmapView.eToolboxMode.AngleMeasurer;
        }
    }
}
