﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NGR;

namespace MilmapSceneGenerator
{
    public partial class PointExProperty : Form
    {
        private int m_nID = -1;
        private double m_dPointSize = 0.0;
        private double m_dLineWidth = 1.0;
        private bool m_bShowName;
        private string m_strName;
        private Color m_ColorFill;
        private Color m_ColorLine;
        private Color m_TextColor;
        private Pixoneer.NXDL.NSCENE.XscPoint.ePointType m_type;
        private eTextAlign m_TextAlign;
        private double m_dLatDegree = 0.0;
        private double m_dLonDegree = 0.0;
        private double m_dHeight = 0.0;
        private bool m_Hide;
        private Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType m_LineStyle;
        private Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType m_FillStyle;


        public bool ObjectHide
        {
            get { return m_Hide; }
            set { m_Hide = value; }
        }
        public double HeightMeter
        {
            get { return m_dHeight; }
            set { m_dHeight = value; }
        }
        public double LonDegree
        {
            get { return m_dLonDegree; }
            set { m_dLonDegree = value; }
        }
        public double LatDegree
        {
            get { return m_dLatDegree; }
            set { m_dLatDegree = value; }
        }
        public Pixoneer.NXDL.NGR.eTextAlign TextAlign
        {
            get { return m_TextAlign; }
            set { m_TextAlign = value; }
        }
        public int ID
        {
            get { return m_nID; }
            set { m_nID = value; }
        }
        public string ObjectName
        {
            get { return m_strName; }
            set { m_strName = value; }
        }
        public System.Drawing.Color ColorFill
        {
            get { return m_ColorFill; }
            set { m_ColorFill = value; }
        }
        public System.Drawing.Color ColorLine
        {
            get { return m_ColorLine; }
            set { m_ColorLine = value; }
        }
        public System.Drawing.Color TextColor
        {
            get { return m_TextColor; }
            set { m_TextColor = value; }
        }
        public Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType LineStyle
        {
            get { return m_LineStyle; }
            set { m_LineStyle = value; }
        }
        public Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType FillStyle
        {
            get { return m_FillStyle; }
            set { m_FillStyle = value; }
        }
        public Pixoneer.NXDL.NSCENE.XscPoint.ePointType Type
        {
            get { return m_type; }
            set { m_type = value; }
        }
        public double PointSize
        {
            get { return m_dPointSize; }
            set { m_dPointSize = value; }
        }
        public double LineWidth
        {
            get { return m_dLineWidth; }
            set { m_dLineWidth = value; }
        }
        public bool ShowName
        {
            get { return m_bShowName; }
            set { m_bShowName = value; }
        }
        public PointExProperty()
        {
            InitializeComponent();
        }

        private void PointExProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = string.Format("{0}", m_nID);
            TextBox_Name.Text = m_strName;
            textBox_PointSize.Text = string.Format("{0}", m_dPointSize);
            TextBox_PointFillColor.BackColor = m_ColorFill;
            TextBox_PointLineColor.BackColor = m_ColorLine;
            TextBox_TextColor.BackColor = m_TextColor;
            comboBox_Style.SelectedIndex = (int)m_type;
            comboBox_TextAlign.SelectedIndex = (int)m_TextAlign;
            checkBox_ShowName.Checked = ShowName;
            textBox_Long.Text = string.Format("{0}", m_dLonDegree);
            textBox_Lat.Text = string.Format("{0}", m_dLatDegree);
            textBox_Hgt.Text = string.Format("{0}", m_dHeight);
            textBoxLineWidth.Text = string.Format("{0}", m_dLineWidth);
            switch (m_Hide)
            {
                case true:
                    comboBox_Hide.SelectedIndex = 0;
                    break;
                case false:
                    comboBox_Hide.SelectedIndex = 1;
                    break;
            }

            switch (m_LineStyle)
            {
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid:
                    comboBox_LineStyle.SelectedIndex = 0; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dash:
                    comboBox_LineStyle.SelectedIndex = 1; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dot:
                    comboBox_LineStyle.SelectedIndex = 2; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDot:
                    comboBox_LineStyle.SelectedIndex = 3; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDotDot:
                    comboBox_LineStyle.SelectedIndex = 4; break;
                default:
                    comboBox_LineStyle.SelectedIndex = 0; break;
            }

            switch (m_FillStyle)
            {
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid:
                    comboBox_FillStyle.SelectedIndex = 0; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.BDiagonal:
                    comboBox_FillStyle.SelectedIndex = 1; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross:
                    comboBox_FillStyle.SelectedIndex = 2; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.DiagCross:
                    comboBox_FillStyle.SelectedIndex = 3; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.FDiagonal:
                    comboBox_FillStyle.SelectedIndex = 4; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Horizontal:
                    comboBox_FillStyle.SelectedIndex = 5; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Vertical:
                    comboBox_FillStyle.SelectedIndex = 6; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Hollow:
                    comboBox_FillStyle.SelectedIndex = 7; break;
            }

            switch (m_type)
            {
                case Pixoneer.NXDL.NSCENE.XscPoint.ePointType.Dot:
                    comboBox_Style.SelectedIndex = 0;   break;
                case Pixoneer.NXDL.NSCENE.XscPoint.ePointType.Rect:
                    comboBox_Style.SelectedIndex = 1;   break;
                case Pixoneer.NXDL.NSCENE.XscPoint.ePointType.Triangle:
                    comboBox_Style.SelectedIndex = 2;   break;
                case Pixoneer.NXDL.NSCENE.XscPoint.ePointType.Cross:
                    comboBox_Style.SelectedIndex = 3;   break;
                case Pixoneer.NXDL.NSCENE.XscPoint.ePointType.X:
                    comboBox_Style.SelectedIndex = 4;   break;
            }
        }

        private void Button_ColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_ColorFill;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_ColorFill = dlg.Color;
                TextBox_PointFillColor.BackColor = m_ColorFill;
            }
        }

        private void Button_ColorDlgLine_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_ColorLine;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_ColorLine = dlg.Color;
                TextBox_PointLineColor.BackColor = m_ColorLine;
            }
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            m_strName = TextBox_Name.Text;
            m_dPointSize = double.Parse(textBox_PointSize.Text);
            m_dLonDegree = double.Parse(textBox_Long.Text);
            m_dLatDegree = double.Parse(textBox_Lat.Text);
            m_dHeight = double.Parse(textBox_Hgt.Text);
            m_dLineWidth = double.Parse(textBoxLineWidth.Text);
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
           
        }

        private void comboBox_Style_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_type = (Pixoneer.NXDL.NSCENE.XscPoint.ePointType)comboBox_Style.SelectedIndex;
        }

        private void checkBox_ShowName_CheckedChanged(object sender, EventArgs e)
        {
            ShowName = checkBox_ShowName.Checked;
        }

        private void Button_TextColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_TextColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_TextColor = dlg.Color;
                TextBox_TextColor.BackColor = m_TextColor;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlign = (eTextAlign)comboBox_TextAlign.SelectedIndex;
        }

        private void comboBox_Hide_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Hide.SelectedIndex)
            {
                case 0:
                    m_Hide = true;
                    break;
                case 1:
                    m_Hide = false;
                    break;
            }
        }

        private void comboBox_LineStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_LineStyle.SelectedIndex)
            {
                case 0:
                    m_LineStyle = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid;
                    break;
                case 1:
                    m_LineStyle = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dash;
                    break;
                case 2:
                    m_LineStyle = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dot;
                    break;
                case 3:
                    m_LineStyle = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDot;
                    break;
                case 4:
                    m_LineStyle = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDotDot;
                    break;
            }
        }

        private void comboBox_FillStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_FillStyle.SelectedIndex)
            {
                case 0:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid;
                    break;
                case 1:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.BDiagonal;
                    break;
                case 2:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross;
                    break;
                case 3:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.DiagCross;
                    break;
                case 4:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.FDiagonal;
                    break;
                case 5:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Horizontal;
                    break;
                case 6:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Vertical;
                    break;
                case 7:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Hollow;
                    break;
                default:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid;
                    break;
            }
        }       
    }
}
