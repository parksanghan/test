﻿namespace MilmapSceneGenerator
{
    partial class TextProperty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TextProperty));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TextBox_ID = new System.Windows.Forms.TextBox();
            this.TextBox_Text = new System.Windows.Forms.TextBox();
            this.TextBox_OutlineColor = new System.Windows.Forms.TextBox();
            this.Button_ColorDlg = new System.Windows.Forms.Button();
            this.comboBox_BorderlineStyle = new System.Windows.Forms.ComboBox();
            this.ButtonApply = new System.Windows.Forms.Button();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.textBox_FontSize = new System.Windows.Forms.TextBox();
            this.checkBox_ShowText = new System.Windows.Forms.CheckBox();
            this.Button_TextColorDlg = new System.Windows.Forms.Button();
            this.TextBox_TextColor = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox_TextAlign = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.TextBox_FontName = new System.Windows.Forms.TextBox();
            this.button_FontDialog = new System.Windows.Forms.Button();
            this.checkBox_ShowOutline = new System.Windows.Forms.CheckBox();
            this.checkBox_Underline = new System.Windows.Forms.CheckBox();
            this.checkBox_Strikeout = new System.Windows.Forms.CheckBox();
            this.checkBox_Italic = new System.Windows.Forms.CheckBox();
            this.checkBox_Bold = new System.Windows.Forms.CheckBox();
            this.checkBox_ShowBorder = new System.Windows.Forms.CheckBox();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox_BorderLineWidth = new System.Windows.Forms.TextBox();
            this.groupBox_Position = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_Hgt = new System.Windows.Forms.TextBox();
            this.textBox_Lat = new System.Windows.Forms.TextBox();
            this.textBox_Long = new System.Windows.Forms.TextBox();
            this.comboBox_Hide = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox_TextAlignV = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox_Position.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "▶ ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "▶ Text :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 145);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "▶ Font Size :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "▶ Outline Color :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 366);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "▶ Border line Style :";
            // 
            // TextBox_ID
            // 
            this.TextBox_ID.Location = new System.Drawing.Point(95, 17);
            this.TextBox_ID.Name = "TextBox_ID";
            this.TextBox_ID.ReadOnly = true;
            this.TextBox_ID.Size = new System.Drawing.Size(131, 21);
            this.TextBox_ID.TabIndex = 5;
            // 
            // TextBox_Text
            // 
            this.TextBox_Text.Location = new System.Drawing.Point(95, 50);
            this.TextBox_Text.Name = "TextBox_Text";
            this.TextBox_Text.Size = new System.Drawing.Size(131, 21);
            this.TextBox_Text.TabIndex = 5;
            // 
            // TextBox_OutlineColor
            // 
            this.TextBox_OutlineColor.Location = new System.Drawing.Point(121, 196);
            this.TextBox_OutlineColor.Name = "TextBox_OutlineColor";
            this.TextBox_OutlineColor.ReadOnly = true;
            this.TextBox_OutlineColor.Size = new System.Drawing.Size(70, 21);
            this.TextBox_OutlineColor.TabIndex = 5;
            // 
            // Button_ColorDlg
            // 
            this.Button_ColorDlg.Location = new System.Drawing.Point(200, 197);
            this.Button_ColorDlg.Name = "Button_ColorDlg";
            this.Button_ColorDlg.Size = new System.Drawing.Size(27, 19);
            this.Button_ColorDlg.TabIndex = 7;
            this.Button_ColorDlg.Text = "...";
            this.Button_ColorDlg.UseVisualStyleBackColor = true;
            this.Button_ColorDlg.Click += new System.EventHandler(this.Button_ColorDlg_Click);
            // 
            // comboBox_BorderlineStyle
            // 
            this.comboBox_BorderlineStyle.FormattingEnabled = true;
            this.comboBox_BorderlineStyle.Items.AddRange(new object[] {
            "SOLID",
            "DASH",
            "DOT",
            "DASHDOT",
            "DASHDOTDOT"});
            this.comboBox_BorderlineStyle.Location = new System.Drawing.Point(141, 363);
            this.comboBox_BorderlineStyle.Name = "comboBox_BorderlineStyle";
            this.comboBox_BorderlineStyle.Size = new System.Drawing.Size(84, 20);
            this.comboBox_BorderlineStyle.TabIndex = 6;
            this.comboBox_BorderlineStyle.SelectedIndexChanged += new System.EventHandler(this.comboBox_BorderlineStyle_SelectedIndexChanged);
            // 
            // ButtonApply
            // 
            this.ButtonApply.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.ButtonApply.Location = new System.Drawing.Point(97, 595);
            this.ButtonApply.Name = "ButtonApply";
            this.ButtonApply.Size = new System.Drawing.Size(59, 25);
            this.ButtonApply.TabIndex = 8;
            this.ButtonApply.Text = "Apply";
            this.ButtonApply.UseVisualStyleBackColor = true;
            this.ButtonApply.Click += new System.EventHandler(this.ButtonApply_Click);
            // 
            // button_Cancel
            // 
            this.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Cancel.Location = new System.Drawing.Point(168, 595);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(59, 25);
            this.button_Cancel.TabIndex = 9;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // textBox_FontSize
            // 
            this.textBox_FontSize.Location = new System.Drawing.Point(96, 142);
            this.textBox_FontSize.Name = "textBox_FontSize";
            this.textBox_FontSize.Size = new System.Drawing.Size(131, 21);
            this.textBox_FontSize.TabIndex = 10;
            // 
            // checkBox_ShowText
            // 
            this.checkBox_ShowText.AutoSize = true;
            this.checkBox_ShowText.Location = new System.Drawing.Point(96, 80);
            this.checkBox_ShowText.Name = "checkBox_ShowText";
            this.checkBox_ShowText.Size = new System.Drawing.Size(85, 16);
            this.checkBox_ShowText.TabIndex = 11;
            this.checkBox_ShowText.Text = "Show Text";
            this.checkBox_ShowText.UseVisualStyleBackColor = true;
            this.checkBox_ShowText.CheckedChanged += new System.EventHandler(this.checkBox_ShowText_CheckedChanged);
            // 
            // Button_TextColorDlg
            // 
            this.Button_TextColorDlg.Location = new System.Drawing.Point(199, 170);
            this.Button_TextColorDlg.Name = "Button_TextColorDlg";
            this.Button_TextColorDlg.Size = new System.Drawing.Size(27, 19);
            this.Button_TextColorDlg.TabIndex = 14;
            this.Button_TextColorDlg.Text = "...";
            this.Button_TextColorDlg.UseVisualStyleBackColor = true;
            this.Button_TextColorDlg.Click += new System.EventHandler(this.Button_TextColorDlg_Click);
            // 
            // TextBox_TextColor
            // 
            this.TextBox_TextColor.Location = new System.Drawing.Point(97, 169);
            this.TextBox_TextColor.Name = "TextBox_TextColor";
            this.TextBox_TextColor.ReadOnly = true;
            this.TextBox_TextColor.Size = new System.Drawing.Size(94, 21);
            this.TextBox_TextColor.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 172);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 12);
            this.label6.TabIndex = 12;
            this.label6.Text = "▶ Text Color :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 248);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 12);
            this.label7.TabIndex = 15;
            this.label7.Text = "▶ Text Align(H) :";
            // 
            // comboBox_TextAlign
            // 
            this.comboBox_TextAlign.FormattingEnabled = true;
            this.comboBox_TextAlign.Items.AddRange(new object[] {
            "Center",
            "Left",
            "Right"});
            this.comboBox_TextAlign.Location = new System.Drawing.Point(121, 245);
            this.comboBox_TextAlign.Name = "comboBox_TextAlign";
            this.comboBox_TextAlign.Size = new System.Drawing.Size(103, 20);
            this.comboBox_TextAlign.TabIndex = 16;
            this.comboBox_TextAlign.SelectedIndexChanged += new System.EventHandler(this.comboBox_TextAlign_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 109);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(91, 12);
            this.label8.TabIndex = 2;
            this.label8.Text = "▶ Font Name :";
            // 
            // TextBox_FontName
            // 
            this.TextBox_FontName.Location = new System.Drawing.Point(96, 106);
            this.TextBox_FontName.Name = "TextBox_FontName";
            this.TextBox_FontName.Size = new System.Drawing.Size(94, 21);
            this.TextBox_FontName.TabIndex = 10;
            // 
            // button_FontDialog
            // 
            this.button_FontDialog.Location = new System.Drawing.Point(199, 106);
            this.button_FontDialog.Name = "button_FontDialog";
            this.button_FontDialog.Size = new System.Drawing.Size(27, 19);
            this.button_FontDialog.TabIndex = 7;
            this.button_FontDialog.Text = "...";
            this.button_FontDialog.UseVisualStyleBackColor = true;
            this.button_FontDialog.Click += new System.EventHandler(this.button_FontDialog_Click);
            // 
            // checkBox_ShowOutline
            // 
            this.checkBox_ShowOutline.AutoSize = true;
            this.checkBox_ShowOutline.Location = new System.Drawing.Point(96, 223);
            this.checkBox_ShowOutline.Name = "checkBox_ShowOutline";
            this.checkBox_ShowOutline.Size = new System.Drawing.Size(103, 16);
            this.checkBox_ShowOutline.TabIndex = 11;
            this.checkBox_ShowOutline.Text = "Show OutLine";
            this.checkBox_ShowOutline.UseVisualStyleBackColor = true;
            this.checkBox_ShowOutline.CheckedChanged += new System.EventHandler(this.checkBox_ShowOutline_CheckedChanged);
            // 
            // checkBox_Underline
            // 
            this.checkBox_Underline.AutoSize = true;
            this.checkBox_Underline.Location = new System.Drawing.Point(15, 316);
            this.checkBox_Underline.Name = "checkBox_Underline";
            this.checkBox_Underline.Size = new System.Drawing.Size(87, 16);
            this.checkBox_Underline.TabIndex = 11;
            this.checkBox_Underline.Text = "Under-Line";
            this.checkBox_Underline.UseVisualStyleBackColor = true;
            this.checkBox_Underline.CheckedChanged += new System.EventHandler(this.checkBox_Underline_CheckedChanged);
            // 
            // checkBox_Strikeout
            // 
            this.checkBox_Strikeout.AutoSize = true;
            this.checkBox_Strikeout.Location = new System.Drawing.Point(15, 338);
            this.checkBox_Strikeout.Name = "checkBox_Strikeout";
            this.checkBox_Strikeout.Size = new System.Drawing.Size(78, 16);
            this.checkBox_Strikeout.TabIndex = 11;
            this.checkBox_Strikeout.Text = "Strike-out";
            this.checkBox_Strikeout.UseVisualStyleBackColor = true;
            this.checkBox_Strikeout.CheckedChanged += new System.EventHandler(this.checkBox_Strikeout_CheckedChanged);
            // 
            // checkBox_Italic
            // 
            this.checkBox_Italic.AutoSize = true;
            this.checkBox_Italic.Location = new System.Drawing.Point(132, 338);
            this.checkBox_Italic.Name = "checkBox_Italic";
            this.checkBox_Italic.Size = new System.Drawing.Size(50, 16);
            this.checkBox_Italic.TabIndex = 11;
            this.checkBox_Italic.Text = "Italic";
            this.checkBox_Italic.UseVisualStyleBackColor = true;
            this.checkBox_Italic.CheckedChanged += new System.EventHandler(this.checkBox_Italic_CheckedChanged);
            // 
            // checkBox_Bold
            // 
            this.checkBox_Bold.AutoSize = true;
            this.checkBox_Bold.Location = new System.Drawing.Point(132, 316);
            this.checkBox_Bold.Name = "checkBox_Bold";
            this.checkBox_Bold.Size = new System.Drawing.Size(49, 16);
            this.checkBox_Bold.TabIndex = 11;
            this.checkBox_Bold.Text = "Bold";
            this.checkBox_Bold.UseVisualStyleBackColor = true;
            this.checkBox_Bold.CheckedChanged += new System.EventHandler(this.checkBox_Bold_CheckedChanged);
            // 
            // checkBox_ShowBorder
            // 
            this.checkBox_ShowBorder.AutoSize = true;
            this.checkBox_ShowBorder.Location = new System.Drawing.Point(15, 445);
            this.checkBox_ShowBorder.Name = "checkBox_ShowBorder";
            this.checkBox_ShowBorder.Size = new System.Drawing.Size(97, 16);
            this.checkBox_ShowBorder.TabIndex = 17;
            this.checkBox_ShowBorder.Text = "Show Border";
            this.checkBox_ShowBorder.UseVisualStyleBackColor = true;
            this.checkBox_ShowBorder.CheckedChanged += new System.EventHandler(this.checkBox_ShowBorder_CheckedChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 395);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(128, 12);
            this.label11.TabIndex = 1;
            this.label11.Text = "▶ Border Line width :";
            // 
            // textBox_BorderLineWidth
            // 
            this.textBox_BorderLineWidth.Location = new System.Drawing.Point(141, 392);
            this.textBox_BorderLineWidth.Name = "textBox_BorderLineWidth";
            this.textBox_BorderLineWidth.Size = new System.Drawing.Size(85, 21);
            this.textBox_BorderLineWidth.TabIndex = 5;
            // 
            // groupBox_Position
            // 
            this.groupBox_Position.Controls.Add(this.label10);
            this.groupBox_Position.Controls.Add(this.label9);
            this.groupBox_Position.Controls.Add(this.label12);
            this.groupBox_Position.Controls.Add(this.textBox_Hgt);
            this.groupBox_Position.Controls.Add(this.textBox_Lat);
            this.groupBox_Position.Controls.Add(this.textBox_Long);
            this.groupBox_Position.Location = new System.Drawing.Point(10, 475);
            this.groupBox_Position.Name = "groupBox_Position";
            this.groupBox_Position.Size = new System.Drawing.Size(217, 114);
            this.groupBox_Position.TabIndex = 18;
            this.groupBox_Position.TabStop = false;
            this.groupBox_Position.Text = "World Position";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 86);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 12);
            this.label10.TabIndex = 15;
            this.label10.Text = "▶ Height (Meter)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(119, 12);
            this.label9.TabIndex = 15;
            this.label9.Text = "▶ Latitude (Degree)";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 30);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(130, 12);
            this.label12.TabIndex = 15;
            this.label12.Text = "▶ Longitude(Degree) ";
            // 
            // textBox_Hgt
            // 
            this.textBox_Hgt.Location = new System.Drawing.Point(141, 83);
            this.textBox_Hgt.Name = "textBox_Hgt";
            this.textBox_Hgt.Size = new System.Drawing.Size(68, 21);
            this.textBox_Hgt.TabIndex = 10;
            // 
            // textBox_Lat
            // 
            this.textBox_Lat.Location = new System.Drawing.Point(141, 54);
            this.textBox_Lat.Name = "textBox_Lat";
            this.textBox_Lat.Size = new System.Drawing.Size(68, 21);
            this.textBox_Lat.TabIndex = 9;
            // 
            // textBox_Long
            // 
            this.textBox_Long.Location = new System.Drawing.Point(141, 23);
            this.textBox_Long.Name = "textBox_Long";
            this.textBox_Long.Size = new System.Drawing.Size(68, 21);
            this.textBox_Long.TabIndex = 8;
            // 
            // comboBox_Hide
            // 
            this.comboBox_Hide.FormattingEnabled = true;
            this.comboBox_Hide.Items.AddRange(new object[] {
            "True",
            "False"});
            this.comboBox_Hide.Location = new System.Drawing.Point(105, 419);
            this.comboBox_Hide.Name = "comboBox_Hide";
            this.comboBox_Hide.Size = new System.Drawing.Size(127, 20);
            this.comboBox_Hide.TabIndex = 39;
            this.comboBox_Hide.SelectedIndexChanged += new System.EventHandler(this.comboBox_Hide_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 422);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(54, 12);
            this.label16.TabIndex = 38;
            this.label16.Text = "▶ Hide :";
            // 
            // comboBox_TextAlignV
            // 
            this.comboBox_TextAlignV.FormattingEnabled = true;
            this.comboBox_TextAlignV.Items.AddRange(new object[] {
            "Middle",
            "Top",
            "Bottom"});
            this.comboBox_TextAlignV.Location = new System.Drawing.Point(121, 271);
            this.comboBox_TextAlignV.Name = "comboBox_TextAlignV";
            this.comboBox_TextAlignV.Size = new System.Drawing.Size(104, 20);
            this.comboBox_TextAlignV.TabIndex = 41;
            this.comboBox_TextAlignV.SelectedIndexChanged += new System.EventHandler(this.comboBox_TextAlignV_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 274);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(104, 12);
            this.label13.TabIndex = 40;
            this.label13.Text = "▶ Text Align(V) :";
            // 
            // TextProperty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(244, 638);
            this.Controls.Add(this.comboBox_TextAlignV);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.comboBox_Hide);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.groupBox_Position);
            this.Controls.Add(this.checkBox_ShowBorder);
            this.Controls.Add(this.comboBox_TextAlign);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Button_TextColorDlg);
            this.Controls.Add(this.TextBox_TextColor);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.checkBox_Bold);
            this.Controls.Add(this.checkBox_Italic);
            this.Controls.Add(this.checkBox_Strikeout);
            this.Controls.Add(this.checkBox_Underline);
            this.Controls.Add(this.checkBox_ShowOutline);
            this.Controls.Add(this.checkBox_ShowText);
            this.Controls.Add(this.TextBox_FontName);
            this.Controls.Add(this.textBox_FontSize);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.ButtonApply);
            this.Controls.Add(this.button_FontDialog);
            this.Controls.Add(this.Button_ColorDlg);
            this.Controls.Add(this.comboBox_BorderlineStyle);
            this.Controls.Add(this.TextBox_OutlineColor);
            this.Controls.Add(this.textBox_BorderLineWidth);
            this.Controls.Add(this.TextBox_Text);
            this.Controls.Add(this.TextBox_ID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TextProperty";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Text Property";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.TextProperty_Load);
            this.groupBox_Position.ResumeLayout(false);
            this.groupBox_Position.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TextBox_ID;
        private System.Windows.Forms.TextBox TextBox_Text;
        private System.Windows.Forms.TextBox TextBox_OutlineColor;
        private System.Windows.Forms.Button Button_ColorDlg;
        private System.Windows.Forms.ComboBox comboBox_BorderlineStyle;
        private System.Windows.Forms.Button ButtonApply;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.TextBox textBox_FontSize;
        private System.Windows.Forms.CheckBox checkBox_ShowText;
        private System.Windows.Forms.Button Button_TextColorDlg;
        private System.Windows.Forms.TextBox TextBox_TextColor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox_TextAlign;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox TextBox_FontName;
        private System.Windows.Forms.Button button_FontDialog;
        private System.Windows.Forms.CheckBox checkBox_ShowOutline;
        private System.Windows.Forms.CheckBox checkBox_Underline;
        private System.Windows.Forms.CheckBox checkBox_Strikeout;
        private System.Windows.Forms.CheckBox checkBox_Italic;
        private System.Windows.Forms.CheckBox checkBox_Bold;
        private System.Windows.Forms.CheckBox checkBox_ShowBorder;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox textBox_BorderLineWidth;
        private System.Windows.Forms.GroupBox groupBox_Position;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_Hgt;
        private System.Windows.Forms.TextBox textBox_Lat;
        private System.Windows.Forms.TextBox textBox_Long;
        private System.Windows.Forms.ComboBox comboBox_Hide;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBox_TextAlignV;
        private System.Windows.Forms.Label label13;
    }
}