﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL;
using Pixoneer.NXDL.NSCENE;

namespace MilmapSceneGenerator
{
    public class XscObjTreeItem
    {
        public XscObj pObj;
        public String strName;
        public int nID;

        public XscObjTreeItem()
        {
            pObj = null;
            strName = "";
            nID = 0;
        }
    }


    public partial class MainForm : Form
    {
        private void InitialTreeControl()
        {
            ObjectTree.ResetText();
            TreeNode tnCategory = null;
            AddTreeNode("XScene", "XScene", ref tnCategory);
            AddTreeNode("Point", "Point", ref tnCategory);
            AddTreeNode("PointEx", "PointEx", ref tnCategory);
            AddTreeNode("Polyline", "Polyline", ref tnCategory);
            AddTreeNode("Polygon", "Polygon", ref tnCategory);
            AddTreeNode("Circle", "Circle", ref tnCategory);
            AddTreeNode("Symbol", "Symbol", ref tnCategory);
            AddTreeNode("Text", "Text", ref tnCategory);
            ObjectTree.Nodes.Add(tnCategory);
            ObjectTree.ExpandAll();
        }
        
        private void AddTreeNode(String strKey, String strNodeName, ref TreeNode Parent)
        {
            if (Parent == null)
            {
                Parent = new TreeNode(strNodeName);
                return;
            }
            Parent.Nodes.Add(strKey, strNodeName);
        }

        private bool AddTreeNode(String strObjectName, String strNodeName, ref String strError)
        {

            TreeNode[]  NodeItem = ObjectTree.Nodes.Find(strObjectName, true);

            if (NodeItem.Length == 0)
            {
                strError = String.Format("{0} Item Is Not Exist", strObjectName);
                return false;
            }
            
            ObjectTree.Nodes.Find(strObjectName, true)[0].Nodes.Add(strObjectName, strNodeName);
            ObjectTree.ExpandAll();

            return true;
        }
        private void ShowPointPropertyDlg(string strItemName)
        {
            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null) return;

            XscPoint obj2D = (XscPoint)scMilmap.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            PointProperty dlg = new PointProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.Color = obj2D.LineColor;
            dlg.Type = obj2D.PointType;
            dlg.PointSize = obj2D.LineWidth;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;
            double dx, dy, dz;
            dx = dy = dz = 0.0;
            obj2D.GetPoint(ref dx, ref dy, ref dz);
            dlg.LonDegree = dx;
            dlg.LatDegree = dy;
            dlg.HeightMeter = dz;
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.Color;
                obj2D.PointType = dlg.Type;
                obj2D.LineWidth = dlg.PointSize;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.CalcRange();

                nxMilmapViewDisplay.RefreshScreen();
            }
        }

        private void ShowPointExPropertyDlg(string strItemName)
        {
            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null) return;

            XscPointEx obj2D = (XscPointEx)scMilmap.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            PointExProperty dlg = new PointExProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.ColorFill = obj2D.FillColor;
            dlg.ColorLine = obj2D.BorderColor;
            dlg.FillStyle = obj2D.FillPattern;
            dlg.LineStyle = obj2D.LinePattern;
            dlg.Type = obj2D.PointType;
            dlg.PointSize = obj2D.PointSize;
            dlg.LineWidth = obj2D.LineWidth;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;

            double dx, dy, dz;
            dx = dy = dz = 0.0;
            obj2D.GetPoint(ref dx, ref dy, ref dz);
            dlg.LonDegree = dx;
            dlg.LatDegree = dy;
            dlg.HeightMeter = dz;
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.BorderColor = dlg.ColorLine;
                obj2D.FillColor = dlg.ColorFill;
                obj2D.LinePattern = dlg.LineStyle;
                obj2D.FillPattern = dlg.FillStyle;
                obj2D.PointType = dlg.Type;
                obj2D.PointSize = dlg.PointSize;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.CalcRange();

                this.nxMilmapViewDisplay.RefreshScreen();
            }
        }

        private void ShowPolylinePropertyDlg(string strItemName)
        {
            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null) return;

            XscPolyLine obj2D = (XscPolyLine)scMilmap.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            PolylineProperty dlg = new PolylineProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.Color = obj2D.LineColor;
            dlg.Type = obj2D.LinePattern;
            dlg.LineWidth = obj2D.LineWidth;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;
            int nItemCount = obj2D.GetNumOfVertex();
            for (int i = 0; i < nItemCount; i++)
            {
                XVertex3d pos = new XVertex3d();
                obj2D.GetPoint(i, ref pos.x, ref pos.y, ref pos.z);
                dlg.PositionArray.Add(pos);
            }
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.Color;
                obj2D.LinePattern = dlg.Type;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ShowObj = !(dlg.ObjectHide);
                if (obj2D.GetNumOfVertex() > dlg.PositionArray.Count)
                {
                    int i = 0;
                    for (; i < dlg.PositionArray.Count; i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                    for (int x = i ; x < obj2D.GetNumOfVertex(); x++)
                    {
                        obj2D.RemovePointAt(i);
                    }
                }
                else if (obj2D.GetNumOfVertex() < dlg.PositionArray.Count)
                {
                    int i = 0;
                    for (; i < obj2D.GetNumOfVertex(); i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                    for (int x = i; x < dlg.PositionArray.Count; x++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[x];
                        obj2D.AddPoint(pos.x, pos.y, pos.z);
                    }
                }
                else
                {
                    int i = 0;
                    for (; i < dlg.PositionArray.Count; i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                }
                
                obj2D.CalcRange();
                nxMilmapViewDisplay.RefreshScreen();
            }
        }
        private void ShowPolygonPropertyDlg(string strItemName)
        {
            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null) return;

            XscPolygon obj2D = (XscPolygon)scMilmap.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            PolygonProperty dlg = new PolygonProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.LineColor = obj2D.BorderColor;
            dlg.Type = obj2D.LinePattern;
            dlg.FillStyle = obj2D.FillPattern;
            dlg.LineWidth = obj2D.BorderSize;
            dlg.FillColor = obj2D.FillColor;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;

            int nItemCount = obj2D.GetNumOfVertex();
            for (int i = 0; i < nItemCount; i++)
            {
                XVertex3d pos = new XVertex3d();
                obj2D.GetPoint(i, ref pos.x, ref pos.y, ref pos.z);
                dlg.PositionArray.Add(pos);
            }
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.BorderColor = dlg.LineColor;
                obj2D.LinePattern = dlg.Type;
                obj2D.FillPattern = dlg.FillStyle;                
                obj2D.BorderSize = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.FillColor = dlg.FillColor;
                obj2D.ShowObj = !(dlg.ObjectHide);

                if (obj2D.GetNumOfVertex() > dlg.PositionArray.Count)
                {
                    int i = 0;
                    for (; i < dlg.PositionArray.Count; i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                    for (int x = i; x < obj2D.GetNumOfVertex(); x++)
                    {
                        obj2D.RemovePointAt(i);
                    }
                }
                else if (obj2D.GetNumOfVertex() < dlg.PositionArray.Count)
                {
                    int i = 0;
                    for (; i < obj2D.GetNumOfVertex(); i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                    for (int x = i; x < dlg.PositionArray.Count; x++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[x];
                        obj2D.AddPoint(pos.x, pos.y, pos.z);
                    }
                }
                else
                {
                    int i = 0;
                    for (; i < dlg.PositionArray.Count; i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                }
                obj2D.DoTriangulate();
                obj2D.CalcRange();

                nxMilmapViewDisplay.RefreshScreen();
            }
        }

        private void ShowCirclePropertyDlg(string strItemName)
        {
            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null) return;

            XscCircle obj2D = (XscCircle)scMilmap.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            CircleProperty dlg = new CircleProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.LineColor = obj2D.LineColor;
            dlg.Type = obj2D.LinePattern;
            dlg.FillStyle = obj2D.FillPattern;
            dlg.LineWidth = obj2D.LineWidth;
            dlg.FillColor = obj2D.FillColor;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;
            dlg.Radius = obj2D.Radius;
            double dx, dy, dz;
            dx = dy = dz = 0.0;
            
            obj2D.GetPoint(ref dx, ref dy, ref dz);
            dlg.LonDegree = dx;
            dlg.LatDegree = dy;
            dlg.HeightMeter = dz;
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.LineColor;
                obj2D.LinePattern = dlg.Type;
                obj2D.FillPattern = dlg.FillStyle;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.FillColor = dlg.FillColor;
                obj2D.Radius = dlg.Radius;
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.CalcRange();

                nxMilmapViewDisplay.RefreshScreen();
            }
        }

        private void ShowSymbolPropertyDlg(string strItemName)
        {
            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null) return;

            XscSymbol obj2D = (XscSymbol)scMilmap.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            SymbolProperty dlg = new SymbolProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;
            double dx, dy, dz;
            dx = dy = dz = 0.0;
            obj2D.GetPoint(ref dx, ref dy, ref dz);
            dlg.LonDegree = dx;
            dlg.LatDegree = dy;
            dlg.HeightMeter = dz;
            dlg.Symbol = obj2D.DefaultSymbolName;
            dlg.ImageFile = obj2D.UserSymbolPath;
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                if (dlg.UseDefaultSymbol)
                    obj2D.DefaultSymbolName = dlg.Symbol;
                else
                {
                    if (dlg.ImageFile != "")
                        obj2D.UserSymbolPath = dlg.ImageFile;
                }

                obj2D.CalcRange();
                obj2D.UpdateSymbol();
                nxMilmapViewDisplay.RefreshScreen();
            }
        }
        private void ShowTextPropertyDlg(string strItemName)
        {
            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null) return;

            XscText obj2D = (XscText)scMilmap.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            TextProperty dlg = new TextProperty();
            dlg.nID = obj2D.ObjID;
            dlg.strText = obj2D.Text;
            dlg.bShowText = obj2D.ShowObj;
            dlg.strFontname = obj2D.FontName;
            dlg.nFontSize = obj2D.FontHeight;
            dlg.textcolor = obj2D.TextColor;
            dlg.outlineColor = obj2D.TextOutLineColor;
            dlg.bShowOutline = obj2D.ShowOutLine;
            dlg.m_TextAlign = obj2D.TextAlign;
            dlg.m_TextAlignV = obj2D.TextAlignV;
            dlg.bUnderLine = obj2D.IsUnderLine;
            dlg.bBold = obj2D.IsBold;
            dlg.bStrikeout = obj2D.IsStrikeOut;
            dlg.bItalic = obj2D.IsItalic;
            dlg.BorderLineStyle = obj2D.TextBorderStyle;
            dlg.bShowBorder = obj2D.IsTextBorder;
            dlg.nBorderLineWidth = obj2D.BorderLineWidth;
            double dx, dy, dz;
            dx = dy = dz = 0.0;
            obj2D.GetPoint(ref dx, ref dy, ref dz);
            dlg.m_dLonDegree = dx;
            dlg.m_dLatDegree = dy;
            dlg.m_dHeight = dz;
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Text = dlg.strText;
                obj2D.ShowObj = dlg.bShowText;
                obj2D.FontName = dlg.strFontname;
                obj2D.FontHeight = dlg.nFontSize;
                obj2D.TextColor = dlg.textcolor;
                obj2D.TextOutLineColor = dlg.outlineColor;
                obj2D.ShowOutLine = dlg.bShowOutline;
                obj2D.TextAlign = dlg.m_TextAlign;
                obj2D.TextAlignV = dlg.m_TextAlignV;
                obj2D.IsUnderLine = dlg.bUnderLine;
                obj2D.IsBold = dlg.bBold;
                obj2D.IsStrikeOut = dlg.bStrikeout;
                obj2D.IsItalic = dlg.bItalic;
                obj2D.TextBorderStyle = dlg.BorderLineStyle;
                obj2D.IsTextBorder = dlg.bShowBorder;
                obj2D.BorderLineWidth = dlg.nBorderLineWidth;
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.SetPoint(dlg.m_dLonDegree, dlg.m_dLatDegree, dlg.m_dHeight);
                obj2D.CalcRange();

                nxMilmapViewDisplay.RefreshScreen();
            }
        }

        private void ShowPropertyDlg(string strItemName, string objType)
        {

            if ("Point" == objType)
                ShowPointPropertyDlg(strItemName);
            else if ("PointEx" == objType)
                ShowPointExPropertyDlg(strItemName);
            else if ("Polyline" == objType)
                ShowPolylinePropertyDlg(strItemName);
            else if ("Polygon" == objType)
                ShowPolygonPropertyDlg(strItemName);
            else if ("Circle" == objType)
                ShowCirclePropertyDlg(strItemName);
            else if ("Symbol" == objType)
                ShowSymbolPropertyDlg(strItemName);
            else if ("Text" == objType)
                ShowTextPropertyDlg(strItemName);
        }

        private void ObjectTree_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                TreeNode nodeitem = ObjectTree.GetNodeAt(e.X, e.Y);
                if (nodeitem == null) return;
                string selectedNickname = nodeitem.Text;

                if( "XScene"   != selectedNickname &&
                    "Point"    != selectedNickname &&
                    "Polyline" != selectedNickname &&
                    "Polygon"  != selectedNickname &&
                    "Circle"   != selectedNickname &&
                    "Symbol"   != selectedNickname &&
                    "Model"    != selectedNickname &&
                    "Text"     != selectedNickname )
                {

                    ContextMenu m = new ContextMenu();

                    MenuItem property = new MenuItem();
                    property.Text = "속성";
                    property.Click += (senders, es) =>
                    {
                        ShowPropertyDlg(selectedNickname,nodeitem.Parent.Text);
                    };

                    m.MenuItems.Add(property);
                    m.Show(ObjectTree, new Point(e.X, e.Y));

                }
            }
        }
    }
}
