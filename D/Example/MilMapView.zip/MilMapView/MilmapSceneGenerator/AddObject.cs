﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL;
using Pixoneer.NXDL.NSCENE;

namespace MilmapSceneGenerator
{
    public partial class MainForm : Form
    {
        private void AddPointButton_Click(object sender, EventArgs e)
        {
            PointProperty dlg = new PointProperty();

            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int nID = scMilmap.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Point Object";
            dlg.PointSize = 1.0;
            dlg.ShowName = true;
            dlg.Color = Color.Red;
            dlg.TextColor = Color.White;
            dlg.ObjectHide = !(scMilmap.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscPoint obj2D = new XscPoint();
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.Color;
                obj2D.PointType = dlg.Type;
                obj2D.LineWidth = dlg.PointSize;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;
                if (scMilmap.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POINT);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                    return;

                nxMilmapViewDisplay.RefreshScreen();
                UpdateListView();
            }
        }

        private void AddPointExButton_Click(object sender, EventArgs e)
        {
            PointExProperty dlg = new PointExProperty();

            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int nID = scMilmap.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New PointEx Object";
            dlg.PointSize = 6.0;
            dlg.ShowName = true;
            dlg.ColorFill = Color.Red;
            dlg.ColorLine = Color.Yellow;
            dlg.TextColor = Color.White;
            dlg.FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross;
            dlg.LineStyle = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid;
            dlg.LineWidth = 1.0;
            dlg.ObjectHide = !(scMilmap.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscPointEx obj2D = new XscPointEx();
                obj2D.Name = dlg.ObjectName;
                obj2D.BorderColor = dlg.ColorLine;
                obj2D.FillColor = dlg.ColorFill;
                obj2D.FillPattern = dlg.FillStyle;
                obj2D.LinePattern = dlg.LineStyle;
                obj2D.PointType = dlg.Type;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.PointSize = dlg.PointSize;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;
                obj2D.LineWidth = dlg.LineWidth;

                if (scMilmap.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POINTEX);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else 
                    return;

                nxMilmapViewDisplay.RefreshScreen();
                UpdateListView();

            }
        }

        private void AddPolyLineButton_Click(object sender, EventArgs e)
        {
            PolylineProperty dlg = new PolylineProperty();

            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int nID = scMilmap.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New PolyLine Object";
            dlg.LineWidth = 1.0;
            dlg.ShowName = true;
            dlg.Color = Color.Red;
            dlg.TextColor = Color.White;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscPolyLine obj2D = new XscPolyLine();
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.Color;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.LinePattern = dlg.Type;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;
                for (int i = 0; i < dlg.PositionArray.Count; i++)
                {
                    XVertex3d  pos = (XVertex3d)dlg.PositionArray[i];
                    obj2D.AddPoint(pos.x, pos.y, pos.z);
                }
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;
                if (scMilmap.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POLYLINE);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else 
                    return;

                nxMilmapViewDisplay.RefreshScreen();
                UpdateListView();
            }
        }

        private void AddPolygonButton_Click(object sender, EventArgs e)
        {
            PolygonProperty dlg = new PolygonProperty();

            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int nID = scMilmap.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Polygon Object";
            dlg.LineWidth = 1.0;
            dlg.ShowName = true;
            dlg.LineColor = Color.Red;
            dlg.FillColor = Color.White;
            dlg.TextColor = Color.White;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscPolygon obj2D = new XscPolygon();
                if (dlg.FillColor.A == 0 || dlg.FillColor.A == 255)
                    dlg.FillColor = Color.FromArgb(160, dlg.FillColor.R, dlg.FillColor.G, dlg.FillColor.B);

                obj2D.Name = dlg.ObjectName;
                obj2D.BorderColor = dlg.LineColor;
                obj2D.LinePattern = dlg.Type;
                obj2D.FillPattern = dlg.FillStyle;
                obj2D.BorderSize = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.FillColor = dlg.FillColor;

                for (int i = 0; i < dlg.PositionArray.Count; i++)
                {
                    XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                    obj2D.AddPoint(pos.x, pos.y, pos.z);
                }
               
                if (scMilmap.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POLYGON);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;

                nxMilmapViewDisplay.RefreshScreen();
                UpdateListView();
            }
        }

        private void AddCircleButton_Click(object sender, EventArgs e)
        {
            CircleProperty dlg = new CircleProperty();

            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int nID = scMilmap.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Circle Object";
            dlg.LineWidth = 1.0;
            dlg.ShowName = true;
            dlg.LineColor = Color.Red;
            dlg.FillColor = Color.White;
            dlg.TextColor = Color.White;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscCircle obj2D = new XscCircle();
                if (dlg.FillColor.A == 0 || dlg.FillColor.A == 255)
                    dlg.FillColor = Color.FromArgb(160, dlg.FillColor.R, dlg.FillColor.G, dlg.FillColor.B);
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.LineColor;
                obj2D.LinePattern = dlg.Type;
                obj2D.FillPattern = dlg.FillStyle;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.FillColor = dlg.FillColor;
                obj2D.Radius = dlg.Radius;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
               // obj2D.SetPoint( XscCoord.FromDegree(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter));
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;

                if (scMilmap.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_CIRCLE);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;

                nxMilmapViewDisplay.RefreshScreen();
                UpdateListView();
            }
        }

        private void AddSymbolButton_Click(object sender, EventArgs e)
        {
            SymbolProperty dlg = new SymbolProperty();

            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int nID = scMilmap.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Symbol Object";
            dlg.ShowName = true;
            dlg.TextColor = Color.White;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscSymbol obj2D = new XscSymbol();
                obj2D.Name = dlg.ObjectName;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.RotateAngle = XAngle.FromDegree(dlg.Rotation);
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;
                if (dlg.UseDefaultSymbol)
                    obj2D.DefaultSymbolName = dlg.Symbol;
                else
                {
                    if (dlg.ImageFile != "")
                        obj2D.UserSymbolPath = dlg.ImageFile;
                }

                if (scMilmap.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_SYMBOL);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;

                obj2D.CalcRange();
                obj2D.UpdateSymbol();
                this.nxMilmapViewDisplay.RefreshScreen();
                UpdateListView();
            }
        }
        private void AddTextButton_Click(object sender, EventArgs e)
        {
            TextProperty dlg = new TextProperty();

            XScene scMilmap = nxMilmapLayerSceneDisplay.GetScene();
            if (scMilmap == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int nID = scMilmap.GetNextID();
            dlg.nID = nID;
            dlg.strText = "Test Text";
            dlg.bShowText = true;
            dlg.strFontname = "Batang";
            dlg.nFontSize = 15;
            dlg.textcolor = Color.Gray;
            dlg.outlineColor = Color.Black ;
            dlg.bShowOutline = true;
            dlg.m_TextAlign = Pixoneer.NXDL.NGR.eTextAlign.Align_Center;
            dlg.m_TextAlignV = Pixoneer.NXDL.NGR.eTextAlignV.Align_Middle;
            dlg.bUnderLine = false;
            dlg.bBold = false;
            dlg.bStrikeout = false;
            dlg.bItalic = false;
            dlg.BorderLineStyle = Pixoneer.NXDL.NSCENE.XscText.eTextBorderLinePatternType.Solid;
            dlg.bShowBorder = false;
            dlg.nBorderLineWidth = 1;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscText obj2D = new XscText();
                obj2D.Text = dlg.strText;
                obj2D.ShowObj = dlg.bShowText;
                obj2D.FontName = dlg.strFontname;
                obj2D.FontHeight = dlg.nFontSize;
                obj2D.TextColor = dlg.textcolor;
                obj2D.TextOutLineColor = dlg.outlineColor;
                obj2D.ShowOutLine = dlg.bShowOutline;
                obj2D.TextAlign = dlg.m_TextAlign;
                obj2D.IsUnderLine = dlg.bUnderLine;
                obj2D.IsBold = dlg.bBold;
                obj2D.IsStrikeOut = dlg.bStrikeout;
                obj2D.IsItalic = dlg.bItalic;
                obj2D.TextBorderStyle = dlg.BorderLineStyle;
                obj2D.IsTextBorder = dlg.bShowBorder;
                obj2D.BorderLineWidth = dlg.nBorderLineWidth;
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;
                obj2D.SetPoint(dlg.m_dLonDegree, dlg.m_dLatDegree, dlg.m_dHeight);

                if (scMilmap.AddNode(nID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_TEXT);
                    string itemID = string.Format("{0}", nID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else 
                    return;

                this.nxMilmapViewDisplay.RefreshScreen();
                UpdateListView();
            }
        }
    }
}
