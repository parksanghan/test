﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Drawing;
using System.Configuration;
using System.Threading;
using Pixoneer.NXDL.NXVideo;
using Pixoneer.NXDL;
using Pixoneer.NXDL.NSM;
using Pixoneer.NXDL.NGR;


namespace XDL_VideoView
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        enum VideoAction { STOP, PLAYING, PAUSED }
        struct VideoState
        {
            public Pixoneer.NXDL.NXVideo.XVideo video;                // 파일이나 네트워크로부터 입력되는 스트리밍데이터를 제어하는 기능을 수행할 객체 선언
            public Pixoneer.NXDL.NXVideo.XVideoChannel videoChannel;  // 동영상 개체에 포함된 채널 객체 선언
            public string videoFilePath;                              // 동영상 파일 경로
            public VideoAction action;                                // 비디오 플레이 상태를 정의하는 객체 선언 
            public long currentFrame;                                 // 재생중인 동영상의 현재 프레임 위치
            public long totalFrame;                                   // 동영상 전체 프레임 수
        }

        private Pixoneer.NXDL.NXVideo.XVideoIO videoIO = null;        // 비디오 IO 처리 객체 선언
        private VideoState VS;                                        // 비디오 상태를 관리하는 객체 선언

        private System.Threading.Timer m_timer;                       // 재생 컨트롤 바 동작을 위한 타이머
        private object lockCurFrame = new object();                   // 재생 컨트롤 바와의 동기화를 위한 Lock 객체

        private XTextPrinter textPrinter = null;                      // 텍스트를 화면에 뿌리기 위한 객체 선언

        private bool IsZoomRect = false;                              // Zoom Rect 설정 상태 정보 
        private XVertex2d DrawRectLL = new XVertex2d();               // Zoom Rect 설정시 좌하단 위치 정보
        private XVertex2d DrawRectUR = new XVertex2d();               // Zoom Rect 설정시 우상단 위치 정보
        private bool IsDrawRect = false;                              // Zoom Rect 설정시 화면에 사각형을 그리는 시점을 갖는 정보
        private int ZoomRectX = 0;                                    // Zoom Rect 초기값  
        private int ZoomRectY = 0;                                    // Zoom Rect 초기값
        private XVertex2d PrevCursorPos = new XVertex2d();            // 이전 마우스 커서 위치 정보
        private XVertex2d OriginScale = new XVertex2d();              // 초기 화면 스케일 정보

        public MainWindow()
        {
            InitializeComponent();
            videoIO = new Pixoneer.NXDL.NXVideo.XVideoIO();  // VideoIO를 생성

            VideoInit();
            nxVideoLayerOverlay1.LayerVisible = true;

            // 재생 컨트롤 바 동작을 위한 타이머 생성
            m_timer = new System.Threading.Timer(timer_Tick);

            // 타이머 옵션 변경
            m_timer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);

            // TextPrinter 객체 생성
            this.textPrinter = new XTextPrinter();
            Font font = new Font("arial", 13, System.Drawing.FontStyle.Bold);
            this.textPrinter.Initialize(font);
        }

        private void VideoInit()
        {
            // VideoState의 초기화
            VS.video = null;
            VS.videoChannel = null;
            VS.videoFilePath = string.Empty;
            VS.totalFrame = 0;
            VS.currentFrame = 0;
            VS.action = VideoAction.STOP;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            OnStop();

            if (videoIO != null)
            {
                // 동영상 입출력 객체 Dispose
                videoIO.Dispose();
            }

            Xfn.Close();
        }

        private void openFileMenuItem_Click(object sender, RoutedEventArgs e)
        {
            // 새로운 파일 Open을 수행한다.
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "TS file(*ts)|*.ts||";
            openFileDialog.RestoreDirectory = true;

            Nullable<bool> result = openFileDialog.ShowDialog();
            if (result != true) return;

            string videoPath = openFileDialog.FileName;

            // 동영상 파일의 존재 유무 체크
            if (System.IO.File.Exists(videoPath) == false)
            {
                MessageBox.Show(this, "해당 경로에 영상이 존재하지 않습니다.", "오류");
                return;
            }

            // 파일 경로를 저장한다.
            VS.videoFilePath = videoPath;

            // 동영상의 재생상태가 중지가 아닐 경우 동영상 재생 중지
            OnStop();

            // 동영상 상태를 업데이트 시키기 위해 Timer를 작동시킨다. 100 msec간격으로 설정한다.
            OnTimer();

            // 동영상 스트리밍 환경을 생성시킨다.
            OnOpen();

            // Play 되는 시간 정보를 도시하기 위해 Timer 설정과 Slider와 Label을 초기화한다.
            InitSliderLabel();

            // 동영상을 Play 시킨다.
            OnPlay();
        }

        public void OnTimer()
        {
            m_timer.Change(0, 100);
        }

        public void StopTimer()
        {
            if (m_timer != null)
            {
                m_timer.Change(System.Threading.Timeout.Infinite, System.Threading.Timeout.Infinite);
            }
        }

        // 동영상 파일 열기
        public void OnOpen()
        {
            try
            {
                string strError = null;
                // 동영상 스트림 정보 가져오기
                VS.video = videoIO.OpenFile(VS.videoFilePath, "XFFMPDRIVER", out strError);

                if (VS.video == null)
                {
                    MessageBox.Show(this, "동영상 재생에 실패하셨습니다. 파일을 확인해주십시오.", "파일 열기");
                    return;
                }

                // 다중 채널을 가진 동영상 객체의 Channel 인덱스
                int nIdxChannel = 0;

                // 동영상 뷰에 재생할 동영상 채널의 설정
                nxVideoView1.SetVideoChannel(VS.video, nIdxChannel);

                // 입력 인덱스에 해당하는 Channel 가져오기
                VS.videoChannel = VS.video.GetChannel(nIdxChannel);

                // GetChannel에 실패할 경우 Null 객체가 return되며, 그에 대한 예외처리
                if (VS.videoChannel == null)
                {
                    MessageBox.Show(this, "동영상 재생에 실패하였습니다. 파일을 확인해 주십시오.", "파일 열기");
                    return;
                }

                // 동영상 객체에 포함된 Channel 객체 중 해당 Channel 객체를 활성화
                // 활성화된 객체만 스트리밍이 수행
                VS.videoChannel.Activate();

                // 동영상의 Frame 정보 얻어오기
                VS.totalFrame = VS.videoChannel.GetNumFramesVideo();

                OriginScale = nxVideoView1.Scale;
                OriginScale.x = (double)nxVideoView1.Width / (double)VS.videoChannel.FrameWidth;
                OriginScale.y = (double)nxVideoView1.Width / (double)VS.videoChannel.FrameWidth;
                nxVideoView1.Translation = new XVertex2d(0, 0);
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex);
                MessageBox.Show(this, "Fail to play!", "Video");
                VS.action = VideoAction.STOP;
            }
        }

        private void OnPlay()
        {
            if (VS.videoChannel != null)
            {
                if (VS.action == VideoAction.PAUSED)      // 동영상이 중지 상태가 아닐경우
                {
                    VS.videoChannel.Resume();             // 동영상 채널 Resume
                    VS.action = VideoAction.PLAYING;
                }
                else if (VS.action == VideoAction.STOP)  // 동영상이 중지 상태일 경우
                {
                    // 동영상 Channel을 처음부터 재생하다록 Play 신호 설정
                    VS.videoChannel.Play();
                    VS.action = VideoAction.PLAYING;
                }
            }
        }

        // 동영상 정지버튼 클릭 이벤트
        private void OnStop()
        {
            if (VS.videoChannel != null)
            {
                // 재생 Frame Buffer를 삭제
                VS.videoChannel.ClearFrameBuffer();
                // 동영상 재생 스크린을 갱신한다.
                nxVideoView1.RefreshScreen();
                // 동영상 재생 중지
                VS.videoChannel.Stop();
                VS.videoChannel = null;
            }

            // 동영상 채널 정보 초기화
            nxVideoView1.ResetVideoChannel();

            if (VS.video != null)
            {
                // 동영상 객체 Close
                VS.video.Close();
                VS.video = null;
            }

            VS.currentFrame = 0;
            VS.action = VideoAction.STOP;
        }

        // 동영상 멈춤버튼클릭 이벤트
        private void OnPause()
        {

            if (VS.action == VideoAction.PLAYING)
            {
                VS.videoChannel.Pause();   // 동영상 채널 Pause
                VS.action = VideoAction.PAUSED;
            }
        }

        private void InitSliderLabel()
        {
            // Slider를 설정하기 위해 컨트롤의 최대값을 설정한다. 
            playControlSlider.Maximum = unchecked((int)VS.totalFrame);

            // Total 시간에 대해 정보를 Label로 설정한다. 
            int nTotalSec = unchecked((int)(VS.totalFrame * (1.0 / 30)));
            TimeSpan getTotalTimeSpan = TimeSpan.FromSeconds(nTotalSec);
            string strTime = getTotalTimeSpan.ToString("hh':'mm':'ss");
            totalTimeLabel.Content = strTime;
        }

        private void playButton_Click(object sender, RoutedEventArgs e)
        {
            // 비디오가 Stop인 상태인 경우 다시 비디오를 저장된 파일 경로로부터 Open해서 설정한다.
            if (VS.action == VideoAction.STOP)
            {
                // 동영상 상태를 업데이트 시키기 위해 Timer를 작동 시킨다.
                OnTimer();

                OnOpen();
            }

            // 설정된 비디오를 Play 한다.
            OnPlay();
        }

        private void pauseButton_Click(object sender, RoutedEventArgs e)
        {
            // Play 되고 있는 비디오를 Pause 시킨다.
            OnPause();
        }

        private void stopButton_Click(object sender, RoutedEventArgs e)
        {
            // Play가 종료되었으므로 Timer를 종료시킨다.
            StopTimer();

            // Play 되고 있는 비디오를 Stop 시킨다.
            OnStop();

            InitSliderLabel();
        }

        private bool nxVideoLayerOverlay1_OnOrthoRender(NXVideoLayer sender, NXVideoDrawArgs DrawArgs)
        {
            if (DrawArgs.VideoFrame == null || DrawArgs.FrameSensor == null) return true;
            try
            {
                lock (lockCurFrame)
                {
                    // 현재 재생중인 화면이 PTS(Presentation TimeStamp) 값 얻어오기
                    Int64 pts = DrawArgs.PTS;

                    if (VS.videoChannel == null) return false;

                    // PTS를 이용한 현재 재생중인 화면의 프레임 위치를 얻어오기
                    VS.currentFrame = VS.videoChannel.PtsToFrameNumber(pts);
                    if (VS.currentFrame >= VS.totalFrame) VS.currentFrame = VS.totalFrame;
                    if (VS.currentFrame < 0) VS.currentFrame = 0;

                    // 센서 모델링 정보 얻기
                    XFrameSensorParams sensor_params = DrawArgs.FrameSensor.GetModelParams();
                    if (sensor_params != null)
                    {
                        XVertex3d[] ptArr = new XVertex3d[5] { new XVertex3d(), new XVertex3d(), new XVertex3d(), new XVertex3d(), new XVertex3d() };

                        double fy = (double)DrawArgs.MetadFrame.FrameHeight / 2.0 / Math.Tan(Math.PI * 31 / 180.0);
                        sensor_params.FocalLength = fy;
                        XFrameSensor sensor = new XFrameSensor();
                        sensor.SetParamsEarth(sensor_params);

                        // 비디오 영상의 모서리 1
                        sensor.ImageToWorldG(new XVertex2d(0, 0), 0.0, out ptArr[0]);
                        // 비디오 영상의 모서리 2
                        sensor.ImageToWorldG(new XVertex2d(0, sensor_params.Height - 1), 0.0, out ptArr[1]);
                        // 비디오 영상의 모서리 3
                        sensor.ImageToWorldG(new XVertex2d(sensor_params.Width - 1, sensor_params.Height - 1), 0.0, out ptArr[2]);
                        // 비디오 영상의 모서리 4
                        sensor.ImageToWorldG(new XVertex2d(sensor_params.Width - 1, 0), 0.0, out ptArr[3]);
                        // 비디오 영상의 모서리 센터
                        sensor.ImageToWorldG(new XVertex2d(sensor_params.Width / 2, sensor_params.Height / 2), 0.0, out ptArr[4]);

                        // UAV 촬영 센서의 자세를 얻는다.
                        XVertex3d uav = DrawArgs.FrameSensor.GetModelParams().SensorPos;
                        double yaw = DrawArgs.FrameSensor.GetModelParams().SensorYaw.deg;
                        double pitch = DrawArgs.FrameSensor.GetModelParams().SensorPitch.deg;
                        double roll = DrawArgs.FrameSensor.GetModelParams().SensorRoll.deg;

                        // UAV 위치를 ECEF좌표계로부터 Geographic Coordiante로 변환시킨다.
                        XGeoPoint geouav = XGeoPoint.FromEcr(uav.x, uav.y, uav.z);

                        uav.x = geouav.lond;
                        uav.y = geouav.latd;
                        uav.z = geouav.hgt;

                        // UAV의 위치와 센서의 자세, 그리고 비디오 Foot Print를 화면에 도시한다.
                        string text = string.Empty;

                        text = string.Format("Drone Position : {0:000.0000000} {1:00.0000000} {2}", uav.x, uav.y, uav.z);
                        textPrinter.Print(text, new XVertex3d(10, 20, 0), eTextAlign.Align_Left, System.Drawing.Color.Yellow, true, System.Drawing.Color.Black);

                        text = string.Format("Drone Attitude : {0:###.0000000}{1:###.0000000}{2:###.0000000}", yaw, pitch, roll);
                        textPrinter.Print(text, new XVertex3d(10, 40, 0), eTextAlign.Align_Left, System.Drawing.Color.Yellow, true, System.Drawing.Color.Black);

                        for (int i = 0; i < 4; i++)
                        {
                            text = string.Format("Video Corner {0} :{1:000.0000000} {2:00.0000000} {3:###.000000}", i + 1, ptArr[i].x, ptArr[i].y, ptArr[i].z);
                            textPrinter.Print(text, new XVertex3d(10, 60 + (20 * i), 0), eTextAlign.Align_Left, System.Drawing.Color.Yellow, true, System.Drawing.Color.Black);
                        }

                        text = string.Format("Video Center    :{0:000.0000000} {1:00.0000000} {2:###.000000}", ptArr[4].x, ptArr[4].y, ptArr[4].z);
                        textPrinter.Print(text, new XVertex3d(10, 140, 0), eTextAlign.Align_Left, System.Drawing.Color.Yellow, true, System.Drawing.Color.Black);
                    }
                    else
                    {
                        string text = string.Empty;
                        text = string.Format("No Metadata");
                        textPrinter.Print(text, new XVertex3d(10, 20, 0), eTextAlign.Align_Left, System.Drawing.Color.Yellow, true, System.Drawing.Color.Black);
                        return true;
                    }
                }
            }

            catch (System.Exception ex)
            {
                Console.WriteLine(ex);
            }

            return default(bool);
        }

        private bool nxVideoLayerOverlay1_OnRender(NXVideoLayer sender, NXVideoDrawArgs DrawArgs)
        {
            if (IsZoomRect)
            {
                XGraphics g = DrawArgs.Graphics;
                g.glDisable(XGraphics.GL_DEPTH_TEST);
                g.glDisable(XGraphics.GL_TEXTURE_2D);
                g.glEnable(XGraphics.GL_BLEND);
                g.glBlendFunc(XGraphics.GL_SRC_ALPHA, XGraphics.GL_ONE_MINUS_SRC_ALPHA);

                g.glColor3f(0.0f, 0.0f, 1.0f);
                g.glBegin(XGraphics.GL_LINE_LOOP);
                g.glVertex3d(DrawRectLL.x, DrawRectLL.y, 0);
                g.glVertex3d(DrawRectLL.x, DrawRectUR.y, 0);
                g.glVertex3d(DrawRectUR.x, DrawRectUR.y, 0);
                g.glVertex3d(DrawRectUR.x, DrawRectLL.y, 0);
                g.glEnd();

                g.glEnable(XGraphics.GL_DEPTH_TEST);
                g.glDisable(XGraphics.GL_BLEND);
            }

            return default(bool);
        }

        private void timer_Tick(object state)
        {
            lock (lockCurFrame)
            {
                if (VS.action != VideoAction.STOP)
                {
                    // 현재 재생되고 있는 동영상의 시간을 계산
                    int nSec = unchecked((int)(VS.currentFrame * (1.0 / 30)));
                    int nTotalSec = unchecked((int)(VS.totalFrame * (1.0 / 30)));

                    long nCheckFrame = VS.totalFrame - VS.currentFrame;

                    if (nCheckFrame <= 30)
                    {
                        nSec = nTotalSec;
                    }

                    string strTime;

                    TimeSpan getTimeSpan = TimeSpan.FromSeconds(nSec);
                    strTime = getTimeSpan.ToString("hh':'mm':'ss");
                    int nCurFrame = unchecked((int)VS.currentFrame);

                    Dispatcher.BeginInvoke(new Action(delegate
                    {
                        // 현재 재생되고 있는 동영상의 시간을 문자형태로 화면 도시
                        currentTimeLabel.Content = strTime;

                        // 현재 재생되고 있는 동영상의 시간을 Slider 컨트롤에 도시
                        playControlSlider.Value = nCurFrame;
                        if (nSec == nTotalSec)
                        {
                            // Play가 종료되었으므로 Timer를 종료 시킨다.
                            StopTimer();

                            // Play를 중단한다.
                            OnStop();

                            // Play가 Stop되었으므로 Slider컨트롤과 Label을 초기화 시킨다.
                            InitSliderLabel();
                        }
                    }));
                }
            }
        }

        // ZoomIn 메뉴 아이템 클릭 시 호출되는 이벤트 함수
        private void zoomInViewMenuItem_Click(object sender, RoutedEventArgs e)
        {
            XVertex2d VideoScale = nxVideoView1.Scale;

            if (VideoScale.x > 0)
            {
                if (VideoScale.x >= 2.0) return;
            }
            else
            {
                if (VideoScale.x <= -2.0) return;
            }

            if (VideoScale.y > 0)
            {
                if (VideoScale.y >= 2.0) return;
            }
            else
            {
                if (VideoScale.y <= -2.0) return;
            }

            if (VideoScale.x > 0) VideoScale.x += 0.2; else VideoScale.x -= 0.2;
            if (VideoScale.y > 0) VideoScale.y += 0.2; else VideoScale.y -= 0.2;

            nxVideoView1.Scale = VideoScale;
        }

        // ZoomOut 메뉴 아이템 클릭시 호출되는 이벤트 함수
        private void zoomOutViewMenuItem_Click(object sender, RoutedEventArgs e)
        {
            XVertex2d VideoScale = nxVideoView1.Scale;

            if (VideoScale.x > 0)
            {
                if (VideoScale.x < 0.5) return;
            }
            else
            {
                if (VideoScale.x > -0.5) return;
            }

            if (VideoScale.y > 0)
            {
                if (VideoScale.y < 0.5) return;
            }
            else
            {
                if (VideoScale.y > -0.5) return;
            }

            if (VideoScale.x > 0) VideoScale.x -= 0.2; else VideoScale.x += 0.2;
            if (VideoScale.y > 0) VideoScale.y -= 0.2; else VideoScale.y += 0.2;

            nxVideoView1.Scale = VideoScale;
        }

        // ZoomRect 메뉴 아이템 클릭시 호출되는 이벤트 함수
        // 마우스를 이용하여 사각형을 그리면 해당 영역이 확대됨        
        private void zoomRectMenuItem_Click(object sender, RoutedEventArgs e)
        {
            IsZoomRect = true;
        }

        // 초기화 메뉴 아이템 클릭시 호출되는 이벤트 함수
        // 초기 Zoom 화면으로 설정
        private void zoomInitMenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Scale = OriginScale;
            ZoomRectX = 0;
            ZoomRectY = 0;
            nxVideoView1.Translation = new XVertex2d(0, 0);
            nxVideoView1.RefreshScreen();
        }

        // 재생되고 있는 동영상의 화면을 회전(45도)
        private void rotate45RotateMenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Rotation = new XAngle(45);
        }

        // 재생되고 있는 동영상의 화면을 회전(-45도)
        private void rotate45Rotate2MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Rotation = new XAngle(-45);
        }

        // 재생되고 있는 동영상의 화면을 회전(0도)
        private void rotate0RotateMenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Rotation = new XAngle(0);
        }

        // 동영상 화면을 수직 방향으로 Flip
        private void vflipFilpMenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Scale = new XVertex2d(nxVideoView1.Scale.x, nxVideoView1.Scale.y * -1);
        }

        // 동영상 화면을 수평 방향으로 Flip
        private void HflipFilpMenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Scale = new XVertex2d(nxVideoView1.Scale.x * -1, nxVideoView1.Scale.y);
        }

        private void shift200ShiftMenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Translation = new XVertex2d(200, 200);
        }

        private void shift200Shift2MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Translation = new XVertex2d(-200, -200);
        }

        private void shift0ShiftMenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Translation = new XVertex2d(0, 0);
        }

        private void speedx10MenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (VS.videoChannel == null) return;
            VS.videoChannel.SetSpeed(1.0);
        }
        private void speedx20MenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (VS.videoChannel == null) return;
            VS.videoChannel.SetSpeed(3.0);
        }
        private void speedx80MenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (VS.videoChannel == null) return;
            VS.videoChannel.SetSpeed(8.0);
        }

        private void speedx05MenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (VS.videoChannel == null) return;
            VS.videoChannel.SetSpeed(0.5);
        }

        private void seek05MenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (VS.videoChannel == null) return;
            VS.videoChannel.Seek(5.0 * 60);
        }

        private void seek10MenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (VS.videoChannel == null) return;
            VS.videoChannel.Seek(10.0 * 60);
        }

        private void seek30MenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (VS.videoChannel == null) return;
            VS.videoChannel.Seek(30.0 * 60);
        }

        private void contrast10MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Contrast = 1.0f;
        }

        private void contrast05MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Contrast = 0.5f;
        }

        private void contrast01MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Contrast = 0.1f;
        }

        private void bright10MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Brightness = 1.0f;
        }

        private void bright05MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Brightness = 0.5f;
        }

        private void bright01MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Brightness = 0.1f;
        }

        //
        private void saturation10MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Saturation = 1.0f;
        }

        private void saturation05MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Saturation = 0.5f;
        }

        private void saturation01MenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.Saturation = 0.1f;
        }


        private void edgeDetectionAlgorMenuItem_Click(object sender, RoutedEventArgs e)
        {
            // Sharp를 통해 Edge 필터를 설정
            nxVideoView1.FilterType = eVideoFilterType.Edge;
        }

        private void bassoAlgorMenuItem_Click(object sender, RoutedEventArgs e)
        { 
            // Sharp를 통해 Basso 필터를 설정
            nxVideoView1.FilterType = eVideoFilterType.Basso;
        }

        private void MedianAlgorMenuItem_Click(object sender, RoutedEventArgs e)
        {
            // Sharp를 통해 Median 필터를 설정
            nxVideoView1.FilterType = eVideoFilterType.Median;
        }

        private void averageAlgorMenuItem_Click(object sender, RoutedEventArgs e)
        {
            // Sharp를 통해 Average 필터를 설정
            nxVideoView1.FilterType = eVideoFilterType.Average;
        }

        private void sharpenAlgorMenuItem_Click(object sender, RoutedEventArgs e)
        {
            nxVideoView1.SharpenSigma = 1.0f;
        }
        private void diableAlgorMenuItem_Click(object sender, RoutedEventArgs e)
        {
            // 필터 설정 해제
            nxVideoView1.FilterType = eVideoFilterType.None;
            nxVideoView1.SharpenSigma = 0.0f;
        }

        // 도시되고 있는 현재 프레임을 저장한다.
        private void saveCurrentFrameCaptureMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (VS.video == null)
            {
                MessageBox.Show(this, "동영상을 먼저 Open 하세요.", "오류");
                return;
            }

            // 함수 콜 시점의 도시된 영상을 RGB 형식으로 담고 있는 XFramePicture 객체를 생성하여 반환
            XFramePicture frameRGB = VS.videoChannel.GetRenderedFrameRGB();

            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Title = "저장 경로를 설정하세요";
            dlg.OverwritePrompt = true;
            dlg.Filter = "JPEG File(*.jpg)|*.jpg";

            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                string strError;
                string strFileName = dlg.FileName;

                // XFramePicture 객체의 화면 프레임을 이미지로 저장
                // 저장을 위한 파일 포맷으로는 TIFF, NITF, JPEG, BMP, JPEG2000 등 지원
                bool bres = frameRGB.SaveFrame(strFileName, "JPEG", out strError, null);

                if (!bres)
                {
                    MessageBox.Show(this, "프레임 저장에 실패하였습니다.", "오류");
                    return;
                }
            }
        }

        private void saveFrame_FirstFrameCaputreMenuItem_Click(object sender, RoutedEventArgs e)
        {
            if (VS.video == null)
            {
                MessageBox.Show(this, "동영상을 먼저 Open 하세요.", "오류");
                return;
            }

            SaveFileDialog dlg = new SaveFileDialog();
            dlg.Title = "저장 경로를 설정하세요";
            dlg.OverwritePrompt = true;
            dlg.Filter = "JPEG File(*.jpg)|*.jpg";

            Nullable<bool> result = dlg.ShowDialog();
            if (result == true)
            {
                string strError;
                string strFileName = dlg.FileName;

                // XVideoIO 객체를 통해 가져온 동영상 스트림의 첫번째 프레임을 반환
                XFramePicture frameRGB = videoIO.GetFirstFrameRGB(VS.videoFilePath, "XFFMPDRIVER", out strError);

                // XFramePucture 객체의 화면 프레임을 이미지로 저장
                // 저장을 위한 파일 포맷으로는 TIFF, NITF, JPEG, BMP, JPEG200 등 지원
                bool bres = frameRGB.SaveFrame(strFileName, "JPEG", out strError, null);

                if (!bres)
                {
                    MessageBox.Show(this, "프레임 저장에 실패하였습니다.", "오류");
                    return;
                }
            }
        }

        private void nxVideoView1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (IsZoomRect)
            {
                if (e.Button == System.Windows.Forms.MouseButtons.Left)
                {
                    XVertex2d ptWorld = new XVertex2d();
                    nxVideoView1.ScreenToWorld(new XVertex2d(e.X, e.Y), out ptWorld);
                    int nX = (int)ptWorld.x;
                    int nY = (int)ptWorld.y;

                    DrawRectUR.x += (nX - PrevCursorPos.x);
                    DrawRectUR.y += (nY - PrevCursorPos.y);

                    IsDrawRect = true;

                    PrevCursorPos.x = nX;
                    PrevCursorPos.y = nY;

                    nxVideoView1.RefreshScreen();
                }
            }
        }

        private void nxVideoView1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (IsZoomRect)
            {
                if (e.Button == System.Windows.Forms.MouseButtons.Left)
                {
                    nxVideoView1.RefreshScreen();
                    XVertex2d ptWorld = new XVertex2d();
                    nxVideoView1.ScreenToWorld(new XVertex2d(e.X, e.Y), out ptWorld);
                    int nX = (int)ptWorld.x;
                    int nY = (int)ptWorld.y;

                    DrawRectLL.x = nX;
                    DrawRectLL.y = nY;
                    DrawRectUR.x = nX;
                    DrawRectUR.y = nY;

                    PrevCursorPos.x = nX;
                    PrevCursorPos.y = nY;
                }
            }
        }

        private void nxVideoView1_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (IsDrawRect)
            {
                System.Drawing.Size nxVideoSize = this.nxVideoView1.Size;

                IsZoomRect = false;
                IsDrawRect = false;
                
                XVertex2d screenLL = null;
                XVertex2d screenUR = null;

                // 영상위에 그린 Rectangle 좌표정보를 화면(스크린) 좌표로 변경
                nxVideoView1.WorldToScreen(DrawRectLL, out screenLL);
                nxVideoView1.WorldToScreen(DrawRectUR, out screenUR);

                // 화면 이동할 중심점 좌표 계산
                ZoomRectX = (int)((screenUR.x + screenLL.x) / 2);
                ZoomRectY = (int)((screenUR.y + screenLL.y) / 2);                

                // 화면 크기와 재생중인 동영상 크기가 다를수 있으므로 화면 크기에 맞게 위치 변경
                // 변경된 위치 정보로 동영상 중심을 위치 이동
                nxVideoView1.Translation = new XVertex2d(-(ZoomRectX - (nxVideoSize.Width/2)), (ZoomRectY - (nxVideoSize.Height/2)));

                // 동영상 확대 축소를 위한 스케일 계산
                double nTemp = Math.Abs(DrawRectUR.y - DrawRectLL.y);
                double dScale = nxVideoSize.Height / nTemp;
                
                XVertex2d scale = new XVertex2d();
                scale.x = dScale;
                scale.y = dScale;
                
                XVertex2d VideoScale = nxVideoView1.Scale;
                if (VideoScale.x > 0) VideoScale.x = dScale; else VideoScale.x = -dScale;
                if (VideoScale.y > 0) VideoScale.y = dScale; else VideoScale.y = -dScale;

                // 동영상 화면의 스케일에 재계산된 스케일 정보 설정
                nxVideoView1.Scale = VideoScale;

                DrawRectLL.x = 0;
                DrawRectLL.y = 0;
                DrawRectUR.x = 0;
                DrawRectUR.y = 0;
                nxVideoView1.RefreshScreen();
            }
        }       
    }
}
    

