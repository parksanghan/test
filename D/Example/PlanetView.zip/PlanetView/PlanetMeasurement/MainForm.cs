﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL;

namespace PlanetMeasurement
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            XGeoPoint pos = new XGeoPoint();
            pos.latd = 37.5;
            pos.lond = 127.5;
            pos.hgt = 2000000.0;
            nxPlanetView2D.SetCameraPosition(pos, XAngle.FromDegree(0.0));
            nxPlanetView2D.GridType = Pixoneer.NXDL.NXPlanet.NXPlanetView.eGridType.GridDegrees;
            nxPlanetView2D.ShowGrid = true;
            nxPlanetView3D.ShowGrid = true;
            nxPlanetView2D.Rotatable = false;

            pos.hgt = 1050000.0;
            nxPlanetView3D.SetCameraPosition(pos, XAngle.FromDegree(0.0), XAngle.FromDegree(-90.0), XAngle.FromDegree(0.0));
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Xfn.Close();
        }
    }
}
