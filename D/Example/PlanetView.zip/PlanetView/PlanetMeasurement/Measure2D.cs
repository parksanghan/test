﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL;
namespace PlanetMeasurement
{
    public partial class MainForm : Form
    {
        private void None2D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView2D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.None;
        }

        private void DistanceMeasurer2D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView2D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.DistanceMeasurer;
            Pixoneer.NXDL.NXPlanet.NXPlanetEngine.SetPBPDefaultDataSet("66");
        }

        private void PathMeasurer2D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView2D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.PathMeasurer;
        }

        private void RelationMeasurer2D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView2D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.RelationMeasurer;
        }

        private void AreaMeasurer2D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView2D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.AreaMeasurer;
        }

        private void CircleMeasurer2D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView2D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.CircleMeasurer;
        }

        private void AngleMeasurer2D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView2D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.AngleMeasurer;
        }

        private void Angle2Measurer2D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView2D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.AngleMeasurer2;
        }
    }
}
