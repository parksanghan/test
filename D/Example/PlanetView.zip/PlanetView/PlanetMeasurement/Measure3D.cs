﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL;
namespace PlanetMeasurement
{
    public partial class MainForm : Form
    {
        private void None3D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView3D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.None;
        }

        private void DistanceMeasurer3D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView3D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.DistanceMeasurer;
        }

        private void PathMeasurer3D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView3D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.PathMeasurer;
        }

        private void RelationMeasurer3D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView3D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.RelationMeasurer;
        }

        private void AreaMeasurer3D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView3D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.AreaMeasurer;
        }

        private void CircleMeasurer3D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView3D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.CircleMeasurer;
        }

        private void AngleMeasurer3D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView3D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.AngleMeasurer;
        }

        private void Angle2Measurer3D_CheckedChanged(object sender, EventArgs e)
        {
            nxPlanetView3D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.AngleMeasurer2;
        }
    }
}
