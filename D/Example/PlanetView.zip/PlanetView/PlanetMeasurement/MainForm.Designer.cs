﻿namespace PlanetMeasurement
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Pixoneer.NXDL.XAngle xAngle1 = new Pixoneer.NXDL.XAngle();
            Pixoneer.NXDL.XAngle xAngle2 = new Pixoneer.NXDL.XAngle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.PlanetViewsplitContainer = new System.Windows.Forms.SplitContainer();
            this.Planet3DToolBox = new System.Windows.Forms.Panel();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Angle2Measurer3D = new System.Windows.Forms.RadioButton();
            this.AngleMeasurer3D = new System.Windows.Forms.RadioButton();
            this.CircleMeasurer3D = new System.Windows.Forms.RadioButton();
            this.AreaMeasurer3D = new System.Windows.Forms.RadioButton();
            this.RelationMeasurer3D = new System.Windows.Forms.RadioButton();
            this.PathMeasurer3D = new System.Windows.Forms.RadioButton();
            this.DistanceMeasurer3D = new System.Windows.Forms.RadioButton();
            this.None3D = new System.Windows.Forms.RadioButton();
            this.nxPlanetView3D = new Pixoneer.NXDL.NXPlanet.NXPlanetView();
            this.Planet2DToolBox = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Angle2Measurer2D = new System.Windows.Forms.RadioButton();
            this.AngleMeasurer2D = new System.Windows.Forms.RadioButton();
            this.CircleMeasurer2D = new System.Windows.Forms.RadioButton();
            this.AreaMeasurer2D = new System.Windows.Forms.RadioButton();
            this.RelationMeasurer2D = new System.Windows.Forms.RadioButton();
            this.PathMeasurer2D = new System.Windows.Forms.RadioButton();
            this.DistanceMeasurer2D = new System.Windows.Forms.RadioButton();
            this.None2D = new System.Windows.Forms.RadioButton();
            this.nxPlanetView2D = new Pixoneer.NXDL.NXPlanet.NXPlanetView();
            ((System.ComponentModel.ISupportInitialize)(this.PlanetViewsplitContainer)).BeginInit();
            this.PlanetViewsplitContainer.Panel1.SuspendLayout();
            this.PlanetViewsplitContainer.Panel2.SuspendLayout();
            this.PlanetViewsplitContainer.SuspendLayout();
            this.Planet3DToolBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.Planet2DToolBox.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // PlanetViewsplitContainer
            // 
            this.PlanetViewsplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PlanetViewsplitContainer.Location = new System.Drawing.Point(0, 0);
            this.PlanetViewsplitContainer.Name = "PlanetViewsplitContainer";
            // 
            // PlanetViewsplitContainer.Panel1
            // 
            this.PlanetViewsplitContainer.Panel1.Controls.Add(this.Planet3DToolBox);
            this.PlanetViewsplitContainer.Panel1.Controls.Add(this.nxPlanetView3D);
            // 
            // PlanetViewsplitContainer.Panel2
            // 
            this.PlanetViewsplitContainer.Panel2.Controls.Add(this.Planet2DToolBox);
            this.PlanetViewsplitContainer.Panel2.Controls.Add(this.nxPlanetView2D);
            this.PlanetViewsplitContainer.Size = new System.Drawing.Size(989, 519);
            this.PlanetViewsplitContainer.SplitterDistance = 492;
            this.PlanetViewsplitContainer.TabIndex = 1;
            // 
            // Planet3DToolBox
            // 
            this.Planet3DToolBox.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Planet3DToolBox.Controls.Add(this.groupBox1);
            this.Planet3DToolBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Planet3DToolBox.Location = new System.Drawing.Point(0, 389);
            this.Planet3DToolBox.Name = "Planet3DToolBox";
            this.Planet3DToolBox.Size = new System.Drawing.Size(492, 130);
            this.Planet3DToolBox.TabIndex = 1;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Angle2Measurer3D);
            this.groupBox1.Controls.Add(this.AngleMeasurer3D);
            this.groupBox1.Controls.Add(this.CircleMeasurer3D);
            this.groupBox1.Controls.Add(this.AreaMeasurer3D);
            this.groupBox1.Controls.Add(this.RelationMeasurer3D);
            this.groupBox1.Controls.Add(this.PathMeasurer3D);
            this.groupBox1.Controls.Add(this.DistanceMeasurer3D);
            this.groupBox1.Controls.Add(this.None3D);
            this.groupBox1.Location = new System.Drawing.Point(3, 22);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(492, 106);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "[ 3D ToolBox Measurement ]";
            // 
            // Angle2Measurer3D
            // 
            this.Angle2Measurer3D.AutoSize = true;
            this.Angle2Measurer3D.Location = new System.Drawing.Point(150, 69);
            this.Angle2Measurer3D.Name = "Angle2Measurer3D";
            this.Angle2Measurer3D.Size = new System.Drawing.Size(115, 16);
            this.Angle2Measurer3D.TabIndex = 9;
            this.Angle2Measurer3D.Text = "Angle2Measurer";
            this.Angle2Measurer3D.UseVisualStyleBackColor = true;
            this.Angle2Measurer3D.CheckedChanged += new System.EventHandler(this.Angle2Measurer3D_CheckedChanged);
            // 
            // AngleMeasurer3D
            // 
            this.AngleMeasurer3D.AutoSize = true;
            this.AngleMeasurer3D.Location = new System.Drawing.Point(11, 69);
            this.AngleMeasurer3D.Name = "AngleMeasurer3D";
            this.AngleMeasurer3D.Size = new System.Drawing.Size(109, 16);
            this.AngleMeasurer3D.TabIndex = 8;
            this.AngleMeasurer3D.Text = "AngleMeasurer";
            this.AngleMeasurer3D.UseVisualStyleBackColor = true;
            this.AngleMeasurer3D.CheckedChanged += new System.EventHandler(this.AngleMeasurer3D_CheckedChanged);
            // 
            // CircleMeasurer3D
            // 
            this.CircleMeasurer3D.AutoSize = true;
            this.CircleMeasurer3D.Location = new System.Drawing.Point(317, 41);
            this.CircleMeasurer3D.Name = "CircleMeasurer3D";
            this.CircleMeasurer3D.Size = new System.Drawing.Size(110, 16);
            this.CircleMeasurer3D.TabIndex = 6;
            this.CircleMeasurer3D.Text = "CircleMeasurer";
            this.CircleMeasurer3D.UseVisualStyleBackColor = true;
            this.CircleMeasurer3D.CheckedChanged += new System.EventHandler(this.CircleMeasurer3D_CheckedChanged);
            // 
            // AreaMeasurer3D
            // 
            this.AreaMeasurer3D.AutoSize = true;
            this.AreaMeasurer3D.Location = new System.Drawing.Point(150, 42);
            this.AreaMeasurer3D.Name = "AreaMeasurer3D";
            this.AreaMeasurer3D.Size = new System.Drawing.Size(103, 16);
            this.AreaMeasurer3D.TabIndex = 4;
            this.AreaMeasurer3D.Text = "AreaMeasurer";
            this.AreaMeasurer3D.UseVisualStyleBackColor = true;
            this.AreaMeasurer3D.CheckedChanged += new System.EventHandler(this.AreaMeasurer3D_CheckedChanged);
            // 
            // RelationMeasurer3D
            // 
            this.RelationMeasurer3D.AutoSize = true;
            this.RelationMeasurer3D.Location = new System.Drawing.Point(11, 43);
            this.RelationMeasurer3D.Name = "RelationMeasurer3D";
            this.RelationMeasurer3D.Size = new System.Drawing.Size(122, 16);
            this.RelationMeasurer3D.TabIndex = 3;
            this.RelationMeasurer3D.Text = "RelationMeasurer";
            this.RelationMeasurer3D.UseVisualStyleBackColor = true;
            this.RelationMeasurer3D.CheckedChanged += new System.EventHandler(this.RelationMeasurer3D_CheckedChanged);
            // 
            // PathMeasurer3D
            // 
            this.PathMeasurer3D.AutoSize = true;
            this.PathMeasurer3D.Location = new System.Drawing.Point(317, 19);
            this.PathMeasurer3D.Name = "PathMeasurer3D";
            this.PathMeasurer3D.Size = new System.Drawing.Size(102, 16);
            this.PathMeasurer3D.TabIndex = 2;
            this.PathMeasurer3D.Text = "PathMeasurer";
            this.PathMeasurer3D.UseVisualStyleBackColor = true;
            this.PathMeasurer3D.CheckedChanged += new System.EventHandler(this.PathMeasurer3D_CheckedChanged);
            // 
            // DistanceMeasurer3D
            // 
            this.DistanceMeasurer3D.AutoSize = true;
            this.DistanceMeasurer3D.Location = new System.Drawing.Point(150, 20);
            this.DistanceMeasurer3D.Name = "DistanceMeasurer3D";
            this.DistanceMeasurer3D.Size = new System.Drawing.Size(126, 16);
            this.DistanceMeasurer3D.TabIndex = 1;
            this.DistanceMeasurer3D.Text = "DistanceMeasurer";
            this.DistanceMeasurer3D.UseVisualStyleBackColor = true;
            this.DistanceMeasurer3D.CheckedChanged += new System.EventHandler(this.DistanceMeasurer3D_CheckedChanged);
            // 
            // None3D
            // 
            this.None3D.AutoSize = true;
            this.None3D.Checked = true;
            this.None3D.Location = new System.Drawing.Point(11, 19);
            this.None3D.Name = "None3D";
            this.None3D.Size = new System.Drawing.Size(53, 16);
            this.None3D.TabIndex = 0;
            this.None3D.TabStop = true;
            this.None3D.Text = "None";
            this.None3D.UseVisualStyleBackColor = true;
            this.None3D.CheckedChanged += new System.EventHandler(this.None3D_CheckedChanged);
            // 
            // nxPlanetView3D
            // 
            this.nxPlanetView3D.AutoFocus = false;
            this.nxPlanetView3D.AutoRefreshRate = 0;
            this.nxPlanetView3D.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.nxPlanetView3D.Brightness = 1F;
            this.nxPlanetView3D.CallbackMode = true;
            this.nxPlanetView3D.Contrast = 1F;
            this.nxPlanetView3D.DisplayMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eDisplayMode.DisplayNormal;
            this.nxPlanetView3D.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nxPlanetView3D.EarthMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eEarthMode.Planet3D;
            this.nxPlanetView3D.ForceDraw = false;
            this.nxPlanetView3D.FrameCapture = null;
            this.nxPlanetView3D.GridType = Pixoneer.NXDL.NXPlanet.NXPlanetView.eGridType.GridDegrees;
            this.nxPlanetView3D.HeightFactor = 1F;
            this.nxPlanetView3D.InverseMouseButton = false;
            this.nxPlanetView3D.InverseMouseWheel = false;
            this.nxPlanetView3D.LayoutMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eLayoutMode.Windows;
            this.nxPlanetView3D.Location = new System.Drawing.Point(0, 0);
            this.nxPlanetView3D.Name = "nxPlanetView3D";
            this.nxPlanetView3D.RelativeHeight = 1D;
            this.nxPlanetView3D.RelativeLeft = 0D;
            this.nxPlanetView3D.RelativeTop = 0D;
            this.nxPlanetView3D.RelativeWidth = 1D;
            this.nxPlanetView3D.RestrictRenerArea = false;
            this.nxPlanetView3D.Rotatable = true;
            this.nxPlanetView3D.Saturation = 1F;
            this.nxPlanetView3D.ShowControlPoint = true;
            this.nxPlanetView3D.ShowGrid = true;
            this.nxPlanetView3D.ShowPBP = true;
            this.nxPlanetView3D.ShowPBV = true;
            this.nxPlanetView3D.ShowStatusInfo = true;
            this.nxPlanetView3D.SingleBaseMap = false;
            this.nxPlanetView3D.Size = new System.Drawing.Size(492, 519);
            this.nxPlanetView3D.TabIndex = 0;
            this.nxPlanetView3D.ToolboxAreaUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxAreaUnit.SquareMeter;
            this.nxPlanetView3D.ToolboxDistUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxDistUnit.Meter;
            this.nxPlanetView3D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.None;
            xAngle1.deg = 45D;
            this.nxPlanetView3D.ViewAreaFOV = xAngle1;
            this.nxPlanetView3D.ViewAreaID = -1;
            this.nxPlanetView3D.ZoomCenterMode = Pixoneer.NXDL.eViewZoomCenterMode.CenterByCursor;
            // 
            // Planet2DToolBox
            // 
            this.Planet2DToolBox.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.Planet2DToolBox.Controls.Add(this.groupBox2);
            this.Planet2DToolBox.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Planet2DToolBox.Location = new System.Drawing.Point(0, 389);
            this.Planet2DToolBox.Name = "Planet2DToolBox";
            this.Planet2DToolBox.Size = new System.Drawing.Size(493, 130);
            this.Planet2DToolBox.TabIndex = 1;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.Angle2Measurer2D);
            this.groupBox2.Controls.Add(this.AngleMeasurer2D);
            this.groupBox2.Controls.Add(this.CircleMeasurer2D);
            this.groupBox2.Controls.Add(this.AreaMeasurer2D);
            this.groupBox2.Controls.Add(this.RelationMeasurer2D);
            this.groupBox2.Controls.Add(this.PathMeasurer2D);
            this.groupBox2.Controls.Add(this.DistanceMeasurer2D);
            this.groupBox2.Controls.Add(this.None2D);
            this.groupBox2.Location = new System.Drawing.Point(2, 22);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(493, 108);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "[ 2D ToolBox Measurement ]";
            // 
            // Angle2Measurer2D
            // 
            this.Angle2Measurer2D.AutoSize = true;
            this.Angle2Measurer2D.Location = new System.Drawing.Point(169, 69);
            this.Angle2Measurer2D.Name = "Angle2Measurer2D";
            this.Angle2Measurer2D.Size = new System.Drawing.Size(115, 16);
            this.Angle2Measurer2D.TabIndex = 18;
            this.Angle2Measurer2D.TabStop = true;
            this.Angle2Measurer2D.Text = "Angle2Measurer";
            this.Angle2Measurer2D.UseVisualStyleBackColor = true;
            this.Angle2Measurer2D.CheckedChanged += new System.EventHandler(this.Angle2Measurer2D_CheckedChanged);
            // 
            // AngleMeasurer2D
            // 
            this.AngleMeasurer2D.AutoSize = true;
            this.AngleMeasurer2D.Location = new System.Drawing.Point(17, 69);
            this.AngleMeasurer2D.Name = "AngleMeasurer2D";
            this.AngleMeasurer2D.Size = new System.Drawing.Size(109, 16);
            this.AngleMeasurer2D.TabIndex = 17;
            this.AngleMeasurer2D.TabStop = true;
            this.AngleMeasurer2D.Text = "AngleMeasurer";
            this.AngleMeasurer2D.UseVisualStyleBackColor = true;
            this.AngleMeasurer2D.CheckedChanged += new System.EventHandler(this.AngleMeasurer2D_CheckedChanged);
            // 
            // CircleMeasurer2D
            // 
            this.CircleMeasurer2D.AutoSize = true;
            this.CircleMeasurer2D.Location = new System.Drawing.Point(326, 44);
            this.CircleMeasurer2D.Name = "CircleMeasurer2D";
            this.CircleMeasurer2D.Size = new System.Drawing.Size(110, 16);
            this.CircleMeasurer2D.TabIndex = 15;
            this.CircleMeasurer2D.TabStop = true;
            this.CircleMeasurer2D.Text = "CircleMeasurer";
            this.CircleMeasurer2D.UseVisualStyleBackColor = true;
            this.CircleMeasurer2D.CheckedChanged += new System.EventHandler(this.CircleMeasurer2D_CheckedChanged);
            // 
            // AreaMeasurer2D
            // 
            this.AreaMeasurer2D.AutoSize = true;
            this.AreaMeasurer2D.Location = new System.Drawing.Point(169, 43);
            this.AreaMeasurer2D.Name = "AreaMeasurer2D";
            this.AreaMeasurer2D.Size = new System.Drawing.Size(103, 16);
            this.AreaMeasurer2D.TabIndex = 13;
            this.AreaMeasurer2D.TabStop = true;
            this.AreaMeasurer2D.Text = "AreaMeasurer";
            this.AreaMeasurer2D.UseVisualStyleBackColor = true;
            this.AreaMeasurer2D.CheckedChanged += new System.EventHandler(this.AreaMeasurer2D_CheckedChanged);
            // 
            // RelationMeasurer2D
            // 
            this.RelationMeasurer2D.AutoSize = true;
            this.RelationMeasurer2D.Location = new System.Drawing.Point(17, 44);
            this.RelationMeasurer2D.Name = "RelationMeasurer2D";
            this.RelationMeasurer2D.Size = new System.Drawing.Size(122, 16);
            this.RelationMeasurer2D.TabIndex = 12;
            this.RelationMeasurer2D.TabStop = true;
            this.RelationMeasurer2D.Text = "RelationMeasurer";
            this.RelationMeasurer2D.UseVisualStyleBackColor = true;
            this.RelationMeasurer2D.CheckedChanged += new System.EventHandler(this.RelationMeasurer2D_CheckedChanged);
            // 
            // PathMeasurer2D
            // 
            this.PathMeasurer2D.AutoSize = true;
            this.PathMeasurer2D.Location = new System.Drawing.Point(326, 21);
            this.PathMeasurer2D.Name = "PathMeasurer2D";
            this.PathMeasurer2D.Size = new System.Drawing.Size(102, 16);
            this.PathMeasurer2D.TabIndex = 11;
            this.PathMeasurer2D.TabStop = true;
            this.PathMeasurer2D.Text = "PathMeasurer";
            this.PathMeasurer2D.UseVisualStyleBackColor = true;
            this.PathMeasurer2D.CheckedChanged += new System.EventHandler(this.PathMeasurer2D_CheckedChanged);
            // 
            // DistanceMeasurer2D
            // 
            this.DistanceMeasurer2D.AutoSize = true;
            this.DistanceMeasurer2D.Location = new System.Drawing.Point(169, 21);
            this.DistanceMeasurer2D.Name = "DistanceMeasurer2D";
            this.DistanceMeasurer2D.Size = new System.Drawing.Size(126, 16);
            this.DistanceMeasurer2D.TabIndex = 10;
            this.DistanceMeasurer2D.TabStop = true;
            this.DistanceMeasurer2D.Text = "DistanceMeasurer";
            this.DistanceMeasurer2D.UseVisualStyleBackColor = true;
            this.DistanceMeasurer2D.CheckedChanged += new System.EventHandler(this.DistanceMeasurer2D_CheckedChanged);
            // 
            // None2D
            // 
            this.None2D.AutoSize = true;
            this.None2D.Checked = true;
            this.None2D.Location = new System.Drawing.Point(17, 20);
            this.None2D.Name = "None2D";
            this.None2D.Size = new System.Drawing.Size(53, 16);
            this.None2D.TabIndex = 9;
            this.None2D.TabStop = true;
            this.None2D.Text = "None";
            this.None2D.UseVisualStyleBackColor = true;
            this.None2D.CheckedChanged += new System.EventHandler(this.None2D_CheckedChanged);
            // 
            // nxPlanetView2D
            // 
            this.nxPlanetView2D.AutoFocus = false;
            this.nxPlanetView2D.AutoRefreshRate = 0;
            this.nxPlanetView2D.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.nxPlanetView2D.Brightness = 1F;
            this.nxPlanetView2D.CallbackMode = true;
            this.nxPlanetView2D.Contrast = 1F;
            this.nxPlanetView2D.DisplayMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eDisplayMode.DisplayNormal;
            this.nxPlanetView2D.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nxPlanetView2D.EarthMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eEarthMode.Planet2D;
            this.nxPlanetView2D.ForceDraw = false;
            this.nxPlanetView2D.FrameCapture = null;
            this.nxPlanetView2D.GridType = Pixoneer.NXDL.NXPlanet.NXPlanetView.eGridType.GridDegrees;
            this.nxPlanetView2D.HeightFactor = 1F;
            this.nxPlanetView2D.InverseMouseButton = false;
            this.nxPlanetView2D.InverseMouseWheel = false;
            this.nxPlanetView2D.LayoutMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eLayoutMode.Windows;
            this.nxPlanetView2D.Location = new System.Drawing.Point(0, 0);
            this.nxPlanetView2D.Name = "nxPlanetView2D";
            this.nxPlanetView2D.RelativeHeight = 1D;
            this.nxPlanetView2D.RelativeLeft = 0D;
            this.nxPlanetView2D.RelativeTop = 0D;
            this.nxPlanetView2D.RelativeWidth = 1D;
            this.nxPlanetView2D.RestrictRenerArea = false;
            this.nxPlanetView2D.Rotatable = true;
            this.nxPlanetView2D.Saturation = 1F;
            this.nxPlanetView2D.ShowControlPoint = true;
            this.nxPlanetView2D.ShowGrid = true;
            this.nxPlanetView2D.ShowPBP = true;
            this.nxPlanetView2D.ShowPBV = true;
            this.nxPlanetView2D.ShowStatusInfo = true;
            this.nxPlanetView2D.SingleBaseMap = false;
            this.nxPlanetView2D.Size = new System.Drawing.Size(493, 519);
            this.nxPlanetView2D.TabIndex = 0;
            this.nxPlanetView2D.ToolboxAreaUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxAreaUnit.SquareMeter;
            this.nxPlanetView2D.ToolboxDistUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxDistUnit.Meter;
            this.nxPlanetView2D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.None;
            xAngle2.deg = 45D;
            this.nxPlanetView2D.ViewAreaFOV = xAngle2;
            this.nxPlanetView2D.ViewAreaID = -1;
            this.nxPlanetView2D.ZoomCenterMode = Pixoneer.NXDL.eViewZoomCenterMode.CenterByCursor;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(989, 519);
            this.Controls.Add(this.PlanetViewsplitContainer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Planet Measurement";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.PlanetViewsplitContainer.Panel1.ResumeLayout(false);
            this.PlanetViewsplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PlanetViewsplitContainer)).EndInit();
            this.PlanetViewsplitContainer.ResumeLayout(false);
            this.Planet3DToolBox.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.Planet2DToolBox.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        
        private System.Windows.Forms.SplitContainer PlanetViewsplitContainer;
        private Pixoneer.NXDL.NXPlanet.NXPlanetView nxPlanetView3D;
        private Pixoneer.NXDL.NXPlanet.NXPlanetView nxPlanetView2D;
        private System.Windows.Forms.Panel Planet3DToolBox;
        private System.Windows.Forms.Panel Planet2DToolBox;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RadioButton None3D;
        private System.Windows.Forms.RadioButton DistanceMeasurer3D;
        private System.Windows.Forms.RadioButton PathMeasurer3D;
        private System.Windows.Forms.RadioButton AngleMeasurer3D;
        private System.Windows.Forms.RadioButton CircleMeasurer3D;
        private System.Windows.Forms.RadioButton AreaMeasurer3D;
        private System.Windows.Forms.RadioButton RelationMeasurer3D;
        private System.Windows.Forms.RadioButton AngleMeasurer2D;
        private System.Windows.Forms.RadioButton CircleMeasurer2D;
        private System.Windows.Forms.RadioButton AreaMeasurer2D;
        private System.Windows.Forms.RadioButton RelationMeasurer2D;
        private System.Windows.Forms.RadioButton PathMeasurer2D;
        private System.Windows.Forms.RadioButton DistanceMeasurer2D;
        private System.Windows.Forms.RadioButton None2D;
        private System.Windows.Forms.RadioButton Angle2Measurer2D;
        private System.Windows.Forms.RadioButton Angle2Measurer3D;
    }
}

