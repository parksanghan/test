﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using Pixoneer.NXDL;
using Pixoneer.NXDL.NSCENE;
using Pixoneer.NXDL.NCC;
using Pixoneer.NXDL.NGR;
using Pixoneer.NXDL.NXPlanet;

using System.Diagnostics;

namespace SceneGenerator
{
    public partial class MainForm : Form
    {

        public enum _Tag_TreeKey_
        {
            [Description("POINT")]       _TREE_KEY_POINT,
            [Description("POINTEX")]      _TREE_KEY_POINTEX,
            [Description("POLYLINE")]    _TREE_KEY_POLYLINE,
            [Description("POLYGON")]     _TREE_KEY_POLYGON,
            [Description("CIRCLE")]      _TREE_KEY_CIRCLE,
            [Description("SYMBOL")]       _TREE_KEY_SYMBOL,
            [Description("MODEL")]       _TREE_KEY_MODEL,
            [Description("TEXT")]       _TREE_KEY_TEXT,
            [Description("POLYLINEEX")] _TREE_KEY_POLYLINEEX,
            [Description("PRISM")]      _TREE_KEY_PRISM,
            [Description("CYLINDER")]   _TREE_KEY_CYLINDER,
            [Description("CONE")]       _TREE_KEY_CONE,
            [Description("CUBE")]       _TREE_KEY_CUBE,
            [Description("SPHERE")]     _TREE_KEY_SPHERE,
        };

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            XSpatialReference sr = new XSpatialReference();
            sr.SetWellKnownGeogCS("WGS84");

            InitialTreeControl();
            nxPlanetLayerSceneDisplay2D.AttachTo(nxPlanetView2D);
            nxPlanetLayerSceneDisplay2D.New();
            nxPlanetLayerSceneDisplay2D.GetScene().SR = sr;

            nxPlanetLayerSceneDisplay2D.OnObjectHitTestObjs += new NXPlanetLayerSceneDisplay_Event_HitTestObjs(nxPlanetLayerSceneDisplay2D_OnObjectHitTestObjs);
            nxPlanetLayerSceneDisplay2D.HitTestableScene = true;

            nxPlanetLayerSceneDisplay3D.AttachTo(nxPlanetView3D);
            nxPlanetLayerSceneDisplay3D.New();
            nxPlanetLayerSceneDisplay3D.GetScene().SR = sr;

            XGeoPoint pos = new XGeoPoint();
            pos.latd = 37.5;
            pos.lond = 127.5;
            pos.hgt = 2000000.0;
            nxPlanetView2D.SetCameraPosition(pos, XAngle.FromDegree(0.0));
            nxPlanetView2D.Rotatable = true;
            nxPlanetView2D.ShowGrid = true;
            nxPlanetView3D.ShowGrid = true;
            nxPlanetView2D.ShowStatusInfo = true;
            nxPlanetView3D.ShowStatusInfo = true;

            pos.hgt = 1050000.0;
            nxPlanetView3D.SetCameraPosition(pos, XAngle.FromDegree(0.0), XAngle.FromDegree(-90.0), XAngle.FromDegree(0.0));
            radioButton_OrderDefault.Checked = true;

            nxPlanetView2D.AddRenderLayer(ref nxPlanetLayer2D);
            nxPlanetView3D.AddRenderLayer(ref nxPlanetLayer3D);
        }

        bool nxPlanetLayerSceneDisplay2D_OnObjectHitTestObjs(int[] objID, int size)
        {
            return true;
        }

        public static string GetEnumDescription(Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            DescriptionAttribute[] attributes =
                (DescriptionAttribute[])fi.GetCustomAttributes(
                typeof(DescriptionAttribute),
                false);

            if (attributes != null &&
                attributes.Length > 0)
                return attributes[0].Description;
            else
                return value.ToString();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Xfn.Close();
        }

        private bool nxPlanetLayerSceneEditor_OnObjectEditOver(Pixoneer.NXDL.NSCENE.XscObj pObj)
        {
            return default(bool);
        }
       

        private void LoadFile(String filePath, bool bLoad2D, bool bLoad3D)
        {
            if (bLoad2D)
            {
                bool bres = nxPlanetLayerSceneDisplay2D.Open(filePath);
            }

            if (bLoad3D)
            { 
                bool bres = nxPlanetLayerSceneDisplay3D.Open(filePath);
            }
        }


        private void Button_SaveScene_Click(object sender, EventArgs e)
        {
            XScene scene = nxPlanetLayerSceneDisplay2D.GetScene();
            if (scene == null || scene.GetNextID() == 0)
            {
                MessageBox.Show("편집중인 Scene이 없습니다.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            SaveFileDialog saveScene = new SaveFileDialog();
            saveScene.Title = "Save Scene File";
            saveScene.DefaultExt = "sml";
            saveScene.Filter = "Scene Files|*.sml";
            XSpatialReference sr = null;
            sr = new XSpatialReference();
            sr.SetWellKnownGeogCS("WGS84");

            if (saveScene.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                bool bres = XScene.SaveScene(scene, saveScene.FileName, sr);
                if (bres)
                    MessageBox.Show("Scene File Save Succeed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Scene File Save Failed", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Button_LoadScene_Click(object sender, EventArgs e)
        {
             OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Scene Files|*.sml";
            openFileDialog1.Title = "Select Scene File";

            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                LoadFile(openFileDialog1.FileName, true, true);
            }

            nxPlanetView2D.RefreshScreen();
            nxPlanetView3D.RefreshScreen();
        }

        bool nxPlanetView2D_OnKeyDown(Pixoneer.NXDL.NXPlanet.NXPlanetView sender, System.Windows.Forms.KeyEventArgs e)
        {
            return default(bool);
        }
    }

}
