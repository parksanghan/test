﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NGR;

namespace SceneGenerator
{
    public partial class ModelProperty : Form
    {
        private int m_nID = -1;
        private bool m_bShowName;
        private string m_strName;
        private string m_strModelFile;
        private Color m_TextColor;
        private eTextAlign m_TextAlign;
        private double m_dLatDegree = 0.0;
        private double m_dLonDegree = 0.0;
        private double m_dHeight = 0.0;
        private double m_dScaleX = 1.0;
        private double m_dScaleY = 1.0;
        private double m_dScaleZ = 1.0;
        private double m_dOrientRoll = 0.0;
        private double m_dOrientYaw = 0.0;
        private double m_dOrientPitch = 0.0;
        private bool m_Hide;

        public bool ObjectHide
        {
            get { return m_Hide; }
            set { m_Hide = value; }
        }
        public double HeightMeter
        {
            get { return m_dHeight; }
            set { m_dHeight = value; }
        }
        public double LonDegree
        {
            get { return m_dLonDegree; }
            set { m_dLonDegree = value; }
        }
        public double LatDegree
        {
            get { return m_dLatDegree; }
            set { m_dLatDegree = value; }
        }
        public double ScaleX
        {
            get { return m_dScaleX; }
            set { m_dScaleX = value; }
        }
        public double ScaleY
        {
            get { return m_dScaleY; }
            set { m_dScaleY = value; }
        }
        public double ScaleZ
        {
            get { return m_dScaleZ; }
            set { m_dScaleZ = value; }
        }
        public double OrientRoll
        {
            get { return m_dOrientRoll; }
            set { m_dOrientRoll = value; }
        }
        public double OrientYaw
        {
            get { return m_dOrientYaw; }
            set { m_dOrientYaw = value; }
        }
        public double OrientPitch
        {
            get { return m_dOrientPitch; }
            set { m_dOrientPitch = value; }
        }

        public string ModelFile
        {
            get { return m_strModelFile; }
            set { m_strModelFile = value; }
        }
        public Pixoneer.NXDL.NGR.eTextAlign TextAlign
        {
            get { return m_TextAlign; }
            set { m_TextAlign = value; }
        }
        public int ID
        {
            get { return m_nID; }
            set { m_nID = value; }
        }
        public string ObjectName
        {
            get { return m_strName; }
            set { m_strName = value; }
        }
        public System.Drawing.Color TextColor
        {
            get { return m_TextColor; }
            set { m_TextColor = value; }
        }
        public bool ShowName
        {
            get { return m_bShowName; }
            set { m_bShowName = value; }
        }
        public ModelProperty()
        {
            InitializeComponent();
        }

        private void ModelProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = string.Format("{0}", m_nID);
            TextBox_Name.Text = m_strName;
            TextBox_TextColor.BackColor = m_TextColor;
            comboBox_TextAlign.SelectedIndex = (int)m_TextAlign;
            checkBox_ShowName.Checked = ShowName;
            textBox_ModelFileName.Text = m_strModelFile;
            textBox_Long.Text = string.Format("{0}", m_dLonDegree);
            textBox_Lat.Text = string.Format("{0}", m_dLatDegree);
            textBox_Hgt.Text = string.Format("{0}", m_dHeight);
            textBox_ScaleX.Text = string.Format("{0}", m_dScaleX);
            textBox_ScaleY.Text = string.Format("{0}", m_dScaleY);
            textBox_ScaleZ.Text = string.Format("{0}", m_dScaleZ);
            textBox_OrientRoll.Text = string.Format("{0}", m_dOrientRoll);
            textBox_OrientPitch.Text = string.Format("{0}", m_dOrientPitch);
            textBox_OrientYaw.Text = string.Format("{0}", m_dOrientYaw);

            switch (m_Hide)
            {
                case true:
                    comboBox_Hide.SelectedIndex = 0;
                    break;
                case false:
                    comboBox_Hide.SelectedIndex = 1;
                    break;
            }
        }


        private void ButtonApply_Click(object sender, EventArgs e)
        {
            m_strName = TextBox_Name.Text;
            m_strModelFile = textBox_ModelFileName.Text;
            m_dLonDegree = double.Parse(textBox_Long.Text);
            m_dLatDegree = double.Parse(textBox_Lat.Text);
            m_dHeight = double.Parse(textBox_Hgt.Text);
            m_dScaleX = double.Parse(textBox_ScaleX.Text);
            m_dScaleY = double.Parse(textBox_ScaleY.Text);
            m_dScaleZ = double.Parse(textBox_ScaleZ.Text);
            m_dOrientRoll = double.Parse(textBox_OrientRoll.Text);
            m_dOrientPitch = double.Parse(textBox_OrientPitch.Text);
            m_dOrientYaw = double.Parse(textBox_OrientYaw.Text);
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
           
        }
        
        private void checkBox_ShowName_CheckedChanged(object sender, EventArgs e)
        {
            ShowName = checkBox_ShowName.Checked;
        }

        private void Button_TextColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_TextColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_TextColor = dlg.Color;
                TextBox_TextColor.BackColor = m_TextColor;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlign = (eTextAlign)comboBox_TextAlign.SelectedIndex;
        }

        private void button_OpenModelSymbol_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "3DS Files|*.3ds|DAE Files|*.dae";
            openFileDialog1.Title = "Select Model File";

            // Show the Dialog.
            // If the user clicked OK in the dialog and
            // a .CUR file was selected, open it.
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_strModelFile = openFileDialog1.FileName;
                textBox_ModelFileName.Text = m_strModelFile;
            }
        }

        private void comboBox_Hide_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Hide.SelectedIndex)
            {
                case 0:
                    m_Hide = true;
                    break;
                case 1:
                    m_Hide = false;
                    break;
            }
        }
    }
}
