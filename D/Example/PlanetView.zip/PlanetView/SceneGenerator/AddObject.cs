﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NSCENE;
//using Pixoneer.NXDL.NSCENE;
using Pixoneer.NXDL;

namespace SceneGenerator
{
    public partial class MainForm : Form
    {
        private void AddPointButton_Click(object sender, EventArgs e)
        {
            PointProperty dlg = new PointProperty();

            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
   
            int nID = sc2D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Point Object";
            dlg.PointSize = 1.0;
            dlg.ShowName = true;
            dlg.Color = Color.Red;
            dlg.TextColor = Color.White;
            dlg.ObjectHide = !(sc2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscPoint obj2D = new XscPoint();
                XscPoint obj3D = new XscPoint();
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.Color;
                obj2D.PointType = dlg.Type;
                obj2D.PointSize = dlg.PointSize;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;

                obj3D.Name = dlg.ObjectName;
                obj3D.LineColor = dlg.Color;
                obj3D.PointType = dlg.Type;
                obj3D.PointSize = dlg.PointSize;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ObjID = dlg.ID;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;

                if (sc2D.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POINT);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;
                sc3D.AddNode(dlg.ID, obj3D);
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
                UpdateListView();
                
            }
        }

       private void AddPointExButton_Click(object sender, EventArgs e)
        {
            PointExProperty dlg = new PointExProperty();

            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int nID = sc2D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New PointEx Object";
            dlg.PointSize = 6.0;
            dlg.ShowName = true;
            dlg.ColorFill = Color.Red;
            dlg.ColorLine = Color.Yellow;
            dlg.TextColor = Color.White;
            dlg.FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross;
            dlg.LineStyle = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid;
            dlg.LineWidth = 1.0;
            dlg.ObjectHide = !(sc2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscPointEx obj2D = new XscPointEx();
                XscPointEx obj3D = new XscPointEx();
                obj2D.Name = dlg.ObjectName;
                obj2D.BorderColor = dlg.ColorLine;
                obj2D.FillColor = dlg.ColorFill;
                obj2D.FillPattern = dlg.FillStyle;
                obj2D.LinePattern = dlg.LineStyle;
                obj2D.PointType = dlg.Type;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.PointSize = dlg.PointSize;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;
                obj2D.LineWidth = dlg.LineWidth;

                obj3D.Name = dlg.ObjectName;
                obj3D.BorderColor = dlg.ColorLine;
                obj3D.FillColor = dlg.ColorFill;
                obj3D.FillPattern = dlg.FillStyle;
                obj3D.LinePattern = dlg.LineStyle;
                obj3D.PointType = dlg.Type;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.PointSize = dlg.PointSize;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ObjID = dlg.ID;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;
                obj3D.LineWidth = dlg.LineWidth;

                if (sc2D.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POINTEX);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;
                sc3D.AddNode(dlg.ID, obj3D);
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
                UpdateListView();

            }
        }

        private void AddPolyLine_Click(object sender, EventArgs e)
        {
            PolylineProperty dlg = new PolylineProperty();

            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int nID = sc2D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New PolyLine Object";
            dlg.LineWidth = 1.0;
            dlg.ShowName = true;
            dlg.Color = Color.Red;
            dlg.TextColor = Color.White;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscPolyLine obj2D = new XscPolyLine();
                XscPolyLine obj3D = new XscPolyLine();
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.Color;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.LinePattern = dlg.Type;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;
                obj3D.Name = dlg.ObjectName;
                obj3D.LineColor = dlg.Color;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.LinePattern = dlg.Type;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ObjID = dlg.ID;

                for (int i = 0; i < dlg.PositionArray.Count; i++)
                {
                    XVertex3d  pos = (XVertex3d)dlg.PositionArray[i];
                    obj2D.AddPoint(pos.x, pos.y, pos.z);
                    obj3D.AddPoint(pos.x, pos.y, pos.z);
                }
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;
                if (sc2D.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POLYLINE);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;

                if (sc3D.AddNode(dlg.ID, obj3D) == false)
                {
                    MessageBox.Show("Add Node Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
                UpdateListView();

            }
        }

        private void AddPolygonButton_Click(object sender, EventArgs e)
        {
            PolygonProperty dlg = new PolygonProperty();

            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int nID = sc2D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Polygon Object";
            dlg.LineWidth = 1.0;
            dlg.ShowName = true;
            dlg.LineColor = Color.Red;
            dlg.FillColor = Color.White;
            dlg.TextColor = Color.White;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscPolygon obj2D = new XscPolygon();
                XscPolygon obj3D = new XscPolygon();

                XscPolygon m_obj2DTest = new XscPolygon();

                if (dlg.FillColor.A == 0 || dlg.FillColor.A == 255)
                    dlg.FillColor = Color.FromArgb(160, dlg.FillColor.R, dlg.FillColor.G, dlg.FillColor.B);

                obj2D.Name = dlg.ObjectName;
                obj2D.BorderColor = dlg.LineColor;
                obj2D.LinePattern = dlg.Type;
                obj2D.FillPattern = dlg.FillStyle;
                obj2D.BorderSize = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.FillColor = dlg.FillColor;

                obj3D.Name = dlg.ObjectName;
                obj3D.BorderColor = dlg.LineColor;
                obj3D.LinePattern = dlg.Type;
                obj3D.FillPattern = dlg.FillStyle;
                obj3D.BorderSize = dlg.LineWidth;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.FillColor = dlg.FillColor;
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;


                m_obj2DTest.Name = dlg.ObjectName;
                m_obj2DTest.BorderColor = dlg.LineColor;
                m_obj2DTest.LinePattern = dlg.Type;
                m_obj2DTest.FillPattern = dlg.FillStyle;
                m_obj2DTest.BorderSize = dlg.LineWidth;
                m_obj2DTest.ShowName = dlg.ShowName;
                m_obj2DTest.TextColor = dlg.TextColor;
                m_obj2DTest.TextAlign = dlg.TextAlign;
                m_obj2DTest.FillColor = dlg.FillColor;
                m_obj2DTest.VisibleDistMax = -1.0;
                m_obj2DTest.VisibleDistMin = -1.0;

                for (int i = 0; i < dlg.PositionArray.Count; i++)
                {
                    XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                    obj2D.AddPoint(pos.x, pos.y, pos.z);
                    obj3D.AddPoint(pos.x, pos.y, pos.z);
                    m_obj2DTest.AddPoint(pos.x, pos.y, pos.z);
                }
               
                if (sc2D.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POLYGON);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;

                if (sc3D.AddNode(dlg.ID, obj3D) == false)
                {
                    MessageBox.Show("Add Node Failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }

                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
                UpdateListView();

                System.Threading.Thread.Sleep(2000);
            }
        }

        private void AddCircleButton_Click(object sender, EventArgs e)
        {
            CircleProperty dlg = new CircleProperty();

            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int nID = sc2D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Circle Object";
            dlg.LineWidth = 1.0;
            dlg.ShowName = true;
            dlg.LineColor = Color.Red;
            dlg.FillColor = Color.White;
            dlg.TextColor = Color.White;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscCircle obj2D = new XscCircle();
                XscCircle obj3D = new XscCircle();
                if (dlg.FillColor.A == 0 || dlg.FillColor.A == 255)
                    dlg.FillColor = Color.FromArgb(160, dlg.FillColor.R, dlg.FillColor.G, dlg.FillColor.B);
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.LineColor;
                obj2D.LinePattern = dlg.Type;
                obj2D.FillPattern = dlg.FillStyle;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.FillColor = dlg.FillColor;
                obj2D.Radius = dlg.Radius;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;

                obj3D.Name = dlg.ObjectName;
                obj3D.LineColor = dlg.LineColor;
                obj3D.LinePattern = dlg.Type;
                obj3D.FillPattern = dlg.FillStyle;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.FillColor = dlg.FillColor;
                obj3D.Radius = dlg.Radius;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;

                if (sc2D.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_CIRCLE);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;
                sc3D.AddNode(dlg.ID, obj3D);

                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
                UpdateListView();
            }
        }

        private void AddSymbolButton_Click(object sender, EventArgs e)
        {
            SymbolProperty dlg = new SymbolProperty();

            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int nID = sc2D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Symbol Object";
            dlg.ShowName = true;
            dlg.TextColor = Color.White;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscSymbol obj2D = new XscSymbol();
                XscSymbol obj3D = new XscSymbol();

                obj2D.Name = dlg.ObjectName;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.RotateAngle = XAngle.FromDegree(dlg.Rotation);
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;
                if (dlg.UseDefaultSymbol)
                    obj2D.DefaultSymbolName = dlg.Symbol;
                else
                {
                    if (dlg.ImageFile != "")
                        obj2D.UserSymbolPath = dlg.ImageFile;
                }
                

                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ObjID = dlg.ID;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.RotateAngle = XAngle.FromDegree(dlg.Rotation);
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;
                if (dlg.UseDefaultSymbol)
                    obj3D.DefaultSymbolName = dlg.Symbol;
                else
                {
                    if (dlg.ImageFile != "")
                        obj3D.UserSymbolPath = dlg.ImageFile;
                }

                if (sc2D.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_SYMBOL);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;
                sc3D.AddNode(dlg.ID, obj3D);
                obj2D.CalcRange();
                obj3D.CalcRange();
                obj2D.UpdateSymbol();
                obj3D.UpdateSymbol();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();

                UpdateListView();
            }
        }

        private void AddConeButton_Click(object sender, EventArgs e)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ConeProperty dlg = new ConeProperty();
            int nID = sc3D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Cone Object";
            dlg.ShowName = true;
            dlg.TextColor = Color.White;
            dlg.ShowCilrcle = true;
            dlg.ShowSection = true;
            dlg.ShowSectionLine = true;
            dlg.LineColor = Color.Red;
            dlg.FillColor = Color.Red;
            
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscCone obj3D = new XscCone();


                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ObjID = dlg.ID;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;
                obj3D.Radius = dlg.Radius;
                obj3D.Height = dlg.Distance;
                obj3D.LineColor = dlg.LineColor;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.FillColor = Color.FromArgb(100, dlg.FillColor);
                obj3D.Yaw = dlg.Yaw;
                obj3D.Pitch = dlg.Pitch;
                obj3D.Roll = dlg.Roll;
                obj3D.ShowSectionLine = dlg.ShowSectionLine;
                obj3D.ShowSection = dlg.ShowSection;
                obj3D.ShowCircle = dlg.ShowCilrcle;
                sc2D.AddNode(dlg.ID, obj3D);

                if (sc3D.AddNode(dlg.ID, obj3D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_CONE);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;
                
                nxPlanetView3D.RefreshScreen();
                UpdateListView();
            }
        }

        private void AddCubeButton_Click(object sender, EventArgs e)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            CubeProperty dlg = new CubeProperty();
            int nID = sc3D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Cube Object";
            dlg.ShowName = true;
            dlg.TextColor = Color.White;
            dlg.ShowCilrcle = true;
            dlg.ShowSection = true;
            dlg.ShowSectionLine = true;
            dlg.LineColor = Color.Red;
            dlg.FillColor = Color.Red;

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscCube obj3D = new XscCube();


                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ObjID = dlg.ID;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;
                obj3D.Width = dlg.CubeWidth;
                obj3D.Height = dlg.Distance;
                obj3D.LineColor = dlg.LineColor;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.FillColor = Color.FromArgb(100, dlg.FillColor);
                obj3D.Yaw = dlg.Yaw;
                obj3D.Pitch = dlg.Pitch;
                obj3D.Roll = dlg.Roll;
                obj3D.ShowSectionLine = dlg.ShowSectionLine;
                obj3D.ShowSection = dlg.ShowSection;
                sc2D.AddNode(dlg.ID, obj3D);

                if (sc3D.AddNode(dlg.ID, obj3D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_CUBE);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;

                nxPlanetView3D.RefreshScreen();
                UpdateListView();
            }
        }

        private void AddSphereButton_Click(object sender, EventArgs e)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            SphereProperty dlg = new SphereProperty();
            int nID = sc3D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Sphere Object";
            dlg.ShowName = true;
            dlg.TextColor = Color.White;
            dlg.ShowSection = true;
            dlg.ShowSectionLine = true;
            dlg.LineColor = Color.Red;
            dlg.FillColor = Color.Red;

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscSphere obj3D = new XscSphere();


                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ObjID = dlg.ID;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;
                obj3D.Radius = dlg.Radius;
                obj3D.LineColor = dlg.LineColor;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.FillColor = Color.FromArgb(100, dlg.FillColor);
                obj3D.ShowSectionLine = dlg.ShowSectionLine;
                obj3D.ShowSection = dlg.ShowSection;
                sc2D.AddNode(dlg.ID, obj3D);

                if (sc3D.AddNode(dlg.ID, obj3D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_SPHERE);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;

                nxPlanetView3D.RefreshScreen();
                UpdateListView();
            }
        }

        private void AddTextButton_Click(object sender, EventArgs e)
        {

            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            TextProperty dlg = new TextProperty();
            int nID = sc2D.GetNextID();

            dlg.nID = nID;
            dlg.strText = "Test Text";
            dlg.bShowText = true;
            dlg.strFontname = "Batang";
            dlg.nFontSize = 15;
            dlg.textcolor = Color.Gray;
            dlg.outlineColor = Color.Black ;
            dlg.bShowOutline = true;
            dlg.m_TextAlign = Pixoneer.NXDL.NGR.eTextAlign.Align_Center;
            dlg.bUnderLine = false;
            dlg.bBold = false;
            dlg.bStrikeout = false;
            dlg.bItalic = false;
            dlg.BorderLineStyle = Pixoneer.NXDL.NSCENE.XscText.eTextBorderLinePatternType.Solid;
            dlg.bShowBorder = false;
            dlg.nBorderLineWidth = 1;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscText obj2D = new XscText();
                XscText obj3D = new XscText();
                obj2D.Text = dlg.strText;
                obj2D.ShowObj = dlg.bShowText;
                obj2D.FontName = dlg.strFontname;
                obj2D.FontHeight = dlg.nFontSize;
                obj2D.TextColor = dlg.textcolor;
                obj2D.TextOutLineColor = dlg.outlineColor;
                obj2D.ShowOutLine = dlg.bShowOutline;
                obj2D.TextAlign = dlg.m_TextAlign;
                obj2D.IsUnderLine = dlg.bUnderLine;
                obj2D.IsBold = dlg.bBold;
                obj2D.IsStrikeOut = dlg.bStrikeout;
                obj2D.IsItalic = dlg.bItalic;
                obj2D.TextBorderStyle = dlg.BorderLineStyle;
                obj2D.IsTextBorder = dlg.bShowBorder;
                obj2D.BorderLineWidth = dlg.nBorderLineWidth;
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;
                obj2D.DrawFlagForSpeed = true;

                obj3D.Text = dlg.strText;
                obj3D.ShowObj = dlg.bShowText;
                obj3D.FontName = dlg.strFontname;
                obj3D.FontHeight = dlg.nFontSize;
                obj3D.TextColor = dlg.textcolor;
                obj3D.TextOutLineColor = dlg.outlineColor;
                obj3D.ShowOutLine = dlg.bShowOutline;
                obj3D.TextAlign = dlg.m_TextAlign;
                obj3D.IsUnderLine = dlg.bUnderLine;
                obj3D.IsBold = dlg.bBold;
                obj3D.IsStrikeOut = dlg.bStrikeout;
                obj3D.IsItalic = dlg.bItalic;
                obj3D.TextBorderStyle = dlg.BorderLineStyle;
                obj3D.IsTextBorder = dlg.bShowBorder;
                obj3D.BorderLineWidth = dlg.nBorderLineWidth;
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;
                obj3D.DrawFlagForSpeed = false;

                obj2D.SetPoint(dlg.m_dLonDegree, dlg.m_dLatDegree, dlg.m_dHeight);
                obj3D.SetPoint(dlg.m_dLonDegree, dlg.m_dLatDegree, dlg.m_dHeight);
                if (sc2D.AddNode(nID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_TEXT);
                    string itemID = string.Format("{0}", nID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;
                sc3D.AddNode(nID, obj3D);

                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
                UpdateListView();
            }
        }

        private void AddModelButton_Click(object sender, EventArgs e)
        {
            ModelProperty dlg = new ModelProperty();

            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int nID = sc2D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Model Object";
            dlg.ShowName = true;
            dlg.TextColor = Color.White;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscModel obj2D = new XscModel();
                XscModel obj3D = new XscModel();

                obj2D.Name = dlg.ObjectName;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;

                XscCoord newPosition = new XscCoord(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.Position = newPosition;
                obj2D.Scale = new XVertex3d(dlg.ScaleX, dlg.ScaleY, dlg.ScaleZ);
                obj2D.SetRotation(XAngle.FromDegree(dlg.OrientYaw), XAngle.FromDegree(dlg.OrientPitch), XAngle.FromDegree(dlg.OrientRoll));
                obj2D.FilePath = dlg.ModelFile;
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;


                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ObjID = dlg.ID;
                obj3D.Position = newPosition;
                obj3D.Scale = new XVertex3d(dlg.ScaleX, dlg.ScaleY, dlg.ScaleZ);
                obj3D.SetRotation(XAngle.FromDegree(dlg.OrientYaw), XAngle.FromDegree(dlg.OrientPitch), XAngle.FromDegree(dlg.OrientRoll));
                obj3D.FilePath = dlg.ModelFile;
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;

                if (sc2D.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_MODEL);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;
                sc3D.AddNode(dlg.ID, obj3D);
                obj2D.CalcRange();
                obj3D.CalcRange();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
                UpdateListView();
            }
        }


        private void AddCylinderButton_Click(object sender, EventArgs e)
        {
            CylinderProperty dlg = new CylinderProperty();

            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int nID = sc2D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Cylinder Object";
            dlg.ShowName = true;
            dlg.LineWidth = 1.0;
            dlg.LineColor = Color.Red;
            dlg.FillColorSide = Color.White;
            dlg.FillColorTop = Color.FromArgb(128, Color.Green);
            dlg.FillColorBottom = Color.FromArgb(128, Color.Blue);
            dlg.TextColor = Color.White;
            dlg.StyleFillSide = XscFillPattern.eFillPatternType.Solid;
            dlg.StyleFillTop = XscFillPattern.eFillPatternType.Vertical;
            dlg.StyleFillBottom = XscFillPattern.eFillPatternType.Horizontal;
            dlg.StyleLine = XscLinePattern.eLinePatternType.Solid;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscCylinder obj2D = new XscCylinder();
                XscCylinder obj3D = new XscCylinder();

                obj2D.ObjID = dlg.ID;
                obj2D.Name = dlg.ObjectName;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.LineColor = dlg.LineColor;
                obj2D.FillColor = dlg.FillColorSide;
                obj2D.TopFillColor = dlg.FillColorTop;
                obj2D.BottomFillColor = dlg.FillColorBottom;

                obj2D.LinePattern = dlg.StyleLine;
                obj2D.FillPattern = dlg.StyleFillSide;
                obj2D.TopFillPattern = dlg.StyleFillTop;
                obj2D.BottomFillPattern = dlg.StyleFillBottom;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.LineWidth = dlg.LineWidth;
                
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMinMeter, dlg.HeightMaxMeter);
                obj2D.Radius = dlg.RadiusMeter;
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;

                /////////////////////////////////////////////////
                obj3D.ObjID = dlg.ID;
                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.LineColor = dlg.LineColor;
                obj3D.FillColor = dlg.FillColorSide;
                obj3D.TopFillColor = dlg.FillColorTop;
                obj3D.BottomFillColor = dlg.FillColorBottom;

                obj3D.LinePattern = dlg.StyleLine;
                obj3D.FillPattern = dlg.StyleFillSide;
                obj3D.TopFillPattern = dlg.StyleFillTop;
                obj3D.BottomFillPattern = dlg.StyleFillBottom;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.LineWidth = dlg.LineWidth;

                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMinMeter, dlg.HeightMaxMeter);
                obj3D.Radius = dlg.RadiusMeter;
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;

                if (sc2D.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_CYLINDER);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;

                sc3D.AddNode(dlg.ID, obj3D);
                obj2D.CalcRange();
                obj3D.CalcRange();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
                UpdateListView();
            }
        }

        private void AddPrismButton_Click(object sender, EventArgs e)
        {
            PrismProperty dlg = new PrismProperty();

            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int nID = sc2D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Prism Object";
            dlg.ShowName = true;
            dlg.LineWidth = 1.0;
            dlg.LineColor = Color.Red;
            dlg.FillColor = Color.White;
            dlg.FillColorTop = Color.White;
            dlg.FillColorBottom = Color.White;

            dlg.TextColor = Color.White;
            dlg.StyleLine = XscLinePattern.eLinePatternType.Solid;
            dlg.StyleFill = XscFillPattern.eFillPatternType.Solid;
            dlg.StyleFillTop = XscFillPattern.eFillPatternType.Solid;
            dlg.StyleFillBottom = XscFillPattern.eFillPatternType.Solid;            

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscPrism obj2D = new XscPrism();
                XscPrism obj3D = new XscPrism();

                obj2D.ObjID = dlg.ID;
                obj2D.Name = dlg.ObjectName;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.BorderColor = dlg.LineColor;
                obj2D.FillColor = dlg.FillColor;
                obj2D.TopFillColor = dlg.FillColorTop;
                obj2D.BottomFillColor = dlg.FillColorBottom;

                obj2D.LinePattern = dlg.StyleLine;
                obj2D.FillPattern = dlg.StyleFill;
                obj2D.TopFillPattern = dlg.StyleFillTop;
                obj2D.BottomFillPattern = dlg.StyleFillBottom;

                obj2D.TextAlign = dlg.TextAlign;
                obj2D.BorderSize = dlg.LineWidth;

                for (int i = 0; i < dlg.PositionArray.Count; i++)
                {
                    XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
                    obj2D.AddPoint(pos.x, pos.y, pos.z, pos.w);
                }

                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;

                /////////////////////////////////////////////////
                obj3D.ObjID = dlg.ID;
                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.BorderColor = dlg.LineColor;
                obj3D.FillColor = dlg.FillColor;
                obj3D.TopFillColor = dlg.FillColorTop;
                obj3D.BottomFillColor = dlg.FillColorBottom;

                obj3D.LinePattern = dlg.StyleLine;
                obj3D.FillPattern = dlg.StyleFill;
                obj3D.TopFillPattern = dlg.StyleFillTop;
                obj3D.BottomFillPattern = dlg.StyleFillBottom;

                obj3D.TextAlign = dlg.TextAlign;
                obj3D.BorderSize = dlg.LineWidth;

                for (int i = 0; i < dlg.PositionArray.Count; i++)
                {
                    XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
                    obj3D.AddPoint(pos.x, pos.y, pos.z, pos.w);
                }

                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;

                if (sc2D.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_PRISM);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;

                sc3D.AddNode(dlg.ID, obj3D);
                obj2D.CalcRange();
                obj3D.CalcRange();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
                UpdateListView();
            }
        }

        private void AddPolyLineExButton_Click(object sender, EventArgs e)
        {
            PolylineExProperty dlg = new PolylineExProperty();

            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null || sc3D == null)
            {
                MessageBox.Show("Not Exist Default DisplayScene ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int nID = sc2D.GetNextID();
            dlg.ID = nID;
            dlg.ObjectName = "New Prism Object";
            dlg.ShowName = true;
            dlg.LineWidth = 1.0;
            dlg.LineColor = Color.Red;
            dlg.ColorFillSide = Color.White;

            dlg.TextColor = Color.White;
            dlg.LineType = XscLinePattern.eLinePatternType.Solid;
            dlg.FillType = XscFillPattern.eFillPatternType.Solid;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                XscPolyLineEx obj2D = new XscPolyLineEx();
                XscPolyLineEx obj3D = new XscPolyLineEx();

                obj2D.ObjID = dlg.ID;
                obj2D.Name = dlg.ObjectName;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.LineColor = dlg.LineColor;
                obj2D.FillColor = dlg.ColorFillSide;

                obj2D.LinePattern = dlg.LineType;
                obj2D.FillPattern = dlg.FillType;

                obj2D.TextAlign = dlg.TextAlign;
                obj2D.LineWidth = dlg.LineWidth;

                for (int i = 0; i < dlg.PositionArray.Count; i++)
                {
                    XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
                    obj2D.AddPoint(pos.x, pos.y, pos.z, pos.w);
                }

                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;

                /////////////////////////////////////////////////
                obj3D.ObjID = dlg.ID;
                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.LineColor = dlg.LineColor;
                obj3D.FillColor = dlg.ColorFillSide;

                obj3D.LinePattern = dlg.LineType;
                obj3D.FillPattern = dlg.FillType;

                obj3D.TextAlign = dlg.TextAlign;
                obj3D.LineWidth = dlg.LineWidth;

                for (int i = 0; i < dlg.PositionArray.Count; i++)
                {
                    XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
                    obj3D.AddPoint(pos.x, pos.y, pos.z, pos.w);
                }

                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;

                if (sc2D.AddNode(dlg.ID, obj2D))
                {
                    string strError = "";
                    string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POLYLINEEX);
                    string itemID = string.Format("{0}", dlg.ID);
                    if (AddTreeNode(strKey, itemID, ref strError) == false)
                    {
                        MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else return;

                sc3D.AddNode(dlg.ID, obj3D);
                obj2D.CalcRange();
                obj3D.CalcRange();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
                UpdateListView();
            }
        }

    }
}
