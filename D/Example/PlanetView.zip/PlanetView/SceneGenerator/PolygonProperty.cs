﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NGR;
using System.Collections;
using Pixoneer.NXDL;

namespace SceneGenerator
{
    public partial class PolygonProperty : Form
    {
        private int m_nID = -1;
        private double m_dLineWidth = 0.0;
        private bool m_bShowName;
        private string m_strName;
        private Color m_LineColor;
        private Color m_FillColor;
        private Color m_TextColor;
        private Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType m_type;
        private Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType m_FillStyle;
        private eTextAlign m_TextAlign;
        private ArrayList m_PositionArray = new ArrayList();
        private bool m_Hide;

        public bool ObjectHide
        {
            get { return m_Hide; }
            set { m_Hide = value; }
        }
        public System.Collections.ArrayList PositionArray
        {
            get { return m_PositionArray; }
            set { m_PositionArray = value; }
        }


        public System.Drawing.Color FillColor
        {
            get { return m_FillColor; }
            set { m_FillColor = value; }
        }

        public Pixoneer.NXDL.NGR.eTextAlign TextAlign
        {
            get { return m_TextAlign; }
            set { m_TextAlign = value; }
        }
        public int ID
        {
            get { return m_nID; }
            set { m_nID = value; }
        }
        public string ObjectName
        {
            get { return m_strName; }
            set { m_strName = value; }
        }
        public System.Drawing.Color LineColor
        {
            get { return m_LineColor; }
            set { m_LineColor = value; }
        }
        public System.Drawing.Color TextColor
        {
            get { return m_TextColor; }
            set { m_TextColor = value; }
        }
        public Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType Type
        {
            get { return m_type; }
            set { m_type = value; }
        }
        public Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType FillStyle
        {
            get { return m_FillStyle; }
            set { m_FillStyle = value; }
        }
        public double LineWidth
        {
            get { return m_dLineWidth; }
            set { m_dLineWidth = value; }
        }
        public bool ShowName
        {
            get { return m_bShowName; }
            set { m_bShowName = value; }
        }
        public PolygonProperty()
        {
            InitializeComponent();
        }

        private void PolygonProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = string.Format("{0}", m_nID);
            TextBox_Name.Text = m_strName;
            textBox_PointSize.Text = string.Format("{0}", m_dLineWidth);
            TextBox_PointColor.BackColor = m_LineColor;
            TextBox_TextColor.BackColor = m_TextColor;
            textBox_FillColor.BackColor = Color.FromArgb(m_FillColor.R, m_FillColor.G, m_FillColor.B);
            switch(m_type)
            {
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid:
                    comboBox_Style.SelectedIndex = 0; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dash:
                    comboBox_Style.SelectedIndex = 1; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dot:
                    comboBox_Style.SelectedIndex = 2; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDot:
                    comboBox_Style.SelectedIndex = 3; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDotDot:
                    comboBox_Style.SelectedIndex = 4; break;
            }

            switch (m_FillStyle)
            {
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid:
                    comboBox_FillStyle.SelectedIndex = 0; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.BDiagonal:
                    comboBox_FillStyle.SelectedIndex = 1; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross:
                    comboBox_FillStyle.SelectedIndex = 2; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.DiagCross:
                    comboBox_FillStyle.SelectedIndex = 3; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.FDiagonal:
                    comboBox_FillStyle.SelectedIndex = 4; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Horizontal:
                    comboBox_FillStyle.SelectedIndex = 5; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Vertical:
                    comboBox_FillStyle.SelectedIndex = 6; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Hollow:
                    comboBox_FillStyle.SelectedIndex = 7; break;
            }

            comboBox_TextAlign.SelectedIndex = (int)m_TextAlign;
            checkBox_ShowName.Checked = ShowName;

            foreach (XVertex3d pos in m_PositionArray)
            {
                string[] row = { pos.x.ToString(), pos.y.ToString(), pos.z.ToString() };
                dataGridViewPosition.Rows.Add(row);
            }
            switch (m_Hide)
            {
                case true:
                    comboBox_Hide.SelectedIndex = 0;
                    break;
                case false:
                    comboBox_Hide.SelectedIndex = 1;
                    break;
            }
            m_PositionArray.Clear();
        }

        private void Button_ColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_LineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_LineColor = dlg.Color;
                TextBox_PointColor.BackColor = m_LineColor;
            }
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            if (dataGridViewPosition.RowCount < 3)
            {
                DialogResult = System.Windows.Forms.DialogResult.Cancel;
                return;
            }

            m_strName = TextBox_Name.Text;
            m_dLineWidth = double.Parse(textBox_PointSize.Text);
            m_PositionArray.Clear();
            for (int i = 0; i < dataGridViewPosition.RowCount - 1; i++)
            {
                XVertex3d pos = new XVertex3d();
                pos.x = Double.Parse(dataGridViewPosition.Rows[i].Cells[0].Value.ToString());
                pos.y = Double.Parse(dataGridViewPosition.Rows[i].Cells[1].Value.ToString());
                pos.z = Double.Parse(dataGridViewPosition.Rows[i].Cells[2].Value.ToString());
                m_PositionArray.Add(pos);
            }
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
           
        }

        private void comboBox_Style_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Style.SelectedIndex)
            {
                case 0:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid;
                    break;
                case 1:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dash;
                    break;
                case 2:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dot;
                    break;
                case 3:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDot;
                    break;
                case 4:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDotDot;
                    break;
            }
        }

        private void checkBox_ShowName_CheckedChanged(object sender, EventArgs e)
        {
            ShowName = checkBox_ShowName.Checked;
        }

        private void Button_TextColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_LineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_TextColor = dlg.Color;
                TextBox_TextColor.BackColor = m_TextColor;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlign = (eTextAlign)comboBox_TextAlign.SelectedIndex;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_LineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                byte alpha = m_FillColor.A;
                m_FillColor = dlg.Color;
                textBox_FillColor.BackColor = m_FillColor;
                m_FillColor = Color.FromArgb(alpha, dlg.Color.R, dlg.Color.G, dlg.Color.B);
            }
        }

        private void comboBox_FillStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_FillStyle.SelectedIndex)
            {
                case 0:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid;
                    break;
                case 1:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.BDiagonal;
                    break;
                case 2:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross;
                    break;
                case 3:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.DiagCross;
                    break;
                case 4:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.FDiagonal;
                    break;
                case 5:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Horizontal;
                    break;
                case 6:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Vertical;
                    break;
                case 7:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Hollow;
                    break;
                default:
                    m_FillStyle = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid;
                    break;
            }
        }

        private void comboBox_Hide_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Hide.SelectedIndex)
            {
                case 0:
                    m_Hide = true;
                    break;
                case 1:
                    m_Hide = false;
                    break;
            }
        }
    }
}
