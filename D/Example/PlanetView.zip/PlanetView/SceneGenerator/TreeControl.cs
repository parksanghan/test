﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NSCENE;
using Pixoneer.NXDL;

namespace SceneGenerator
{
    public class XscObjTreeItem
    {
        public XscObj pObj;
        public String strName;
        public int nID;

        public XscObjTreeItem()
        {
            pObj = null;
            strName = "";
            nID = 0;
        }
    }


    public partial class MainForm : Form
    {
        private void InitialTreeControl()
        {
            ObjectTree.ResetText();
            TreeNode tnCategory = null;
            AddTreeNode("XScene", "XScene", ref tnCategory);
            AddTreeNode("Point", "Point", ref tnCategory);
            AddTreeNode("PointEx", "PointEx", ref tnCategory);
            AddTreeNode("Polyline", "Polyline", ref tnCategory);
            AddTreeNode("Polygon", "Polygon", ref tnCategory);
            AddTreeNode("Circle", "Circle", ref tnCategory);
            AddTreeNode("Symbol", "Symbol", ref tnCategory);
            AddTreeNode("Text", "Text", ref tnCategory);
            AddTreeNode("Model", "Model", ref tnCategory);
            AddTreeNode("PolylineEx", "PolylineEx", ref tnCategory);
            AddTreeNode("Prism", "Prism", ref tnCategory);
            AddTreeNode("Cylinder", "Cylinder", ref tnCategory);
            AddTreeNode("Cone", "Cone", ref tnCategory);
            AddTreeNode("Cube", "Cube", ref tnCategory);
            AddTreeNode("Sphere", "Sphere", ref tnCategory);
            ObjectTree.Nodes.Add(tnCategory);
            ObjectTree.ExpandAll();
        }
        
        private void AddTreeNode(String strKey, String strNodeName, ref TreeNode Parent)
        {
            if (Parent == null)
            {
                Parent = new TreeNode(strNodeName);
                return;
            }
            Parent.Nodes.Add(strKey, strNodeName);
        }

        private bool AddTreeNode(String strObjectName, String strNodeName, ref String strError)
        {

            TreeNode[]  NodeItem = ObjectTree.Nodes.Find(strObjectName, true);

            if (NodeItem.Length == 0)
            {
                strError = String.Format("{0} Item Is Not Exist", strObjectName);
                return false;
            }
            
            ObjectTree.Nodes.Find(strObjectName, true)[0].Nodes.Add(strObjectName, strNodeName);
            ObjectTree.ExpandAll();

            return true;
        }
        private void ShowPointPropertyDlg(string strItemName)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null) return;
            if (sc3D == null) return;
            XscPoint obj2D = (XscPoint)sc2D.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            XscPoint obj3D = (XscPoint)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            PointProperty dlg = new PointProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.Color = obj2D.LineColor;
            dlg.Type = obj2D.PointType;
            dlg.PointSize = obj2D.LineWidth;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;
            double dx, dy, dz;
            dx = dy = dz = 0.0;
            obj2D.GetPoint(ref dx, ref dy, ref dz);
            dlg.LonDegree = dx;
            dlg.LatDegree = dy;
            dlg.HeightMeter = dz;
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.Color;
                obj2D.PointType = dlg.Type;
                obj2D.LineWidth = dlg.PointSize;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.CalcRange();

                obj3D.Name = dlg.ObjectName;
                obj3D.LineColor = dlg.Color;
                obj3D.PointType = dlg.Type;
                obj3D.LineWidth = dlg.PointSize;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj3D.CalcRange();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
            }
        }

        private void ShowPointExPropertyDlg(string strItemName)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null) return;
            if (sc3D == null) return;

            XscPointEx obj2D = (XscPointEx)sc2D.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;
            XscPointEx obj3D = (XscPointEx)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            PointExProperty dlg = new PointExProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.ColorFill = obj2D.FillColor;
            dlg.ColorLine = obj2D.BorderColor;
            dlg.FillStyle = obj2D.FillPattern;
            dlg.LineStyle = obj2D.LinePattern;
            dlg.Type = obj2D.PointType;
            dlg.PointSize = obj2D.PointSize;
            dlg.LineWidth = obj2D.LineWidth;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;

            double dx, dy, dz;
            dx = dy = dz = 0.0;
            obj2D.GetPoint(ref dx, ref dy, ref dz);
            dlg.LonDegree = dx;
            dlg.LatDegree = dy;
            dlg.HeightMeter = dz;
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.BorderColor = dlg.ColorLine;
                obj2D.FillColor = dlg.ColorFill;
                obj2D.LinePattern = dlg.LineStyle;
                obj2D.FillPattern = dlg.FillStyle;
                obj2D.PointType = dlg.Type;
                obj2D.PointSize = dlg.PointSize;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.CalcRange();

                obj3D.Name = dlg.ObjectName;
                obj3D.BorderColor = dlg.ColorLine;
                obj3D.FillColor = dlg.ColorFill;
                obj3D.LinePattern = dlg.LineStyle;
                obj3D.FillPattern = dlg.FillStyle;
                obj3D.PointType = dlg.Type;
                obj3D.PointSize = dlg.PointSize;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj3D.CalcRange();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
            }
        }

        private void ShowPolylinePropertyDlg(string strItemName)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null) return;
            if (sc3D == null) return;
            XscPolyLine obj2D = (XscPolyLine)sc2D.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            XscPolyLine obj3D = (XscPolyLine)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            PolylineProperty dlg = new PolylineProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.Color = obj2D.LineColor;
            dlg.Type = obj2D.LinePattern;
            dlg.LineWidth = obj2D.LineWidth;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;
            int nItemCount = obj2D.GetNumOfVertex();
            for (int i = 0; i < nItemCount; i++)
            {
                XVertex3d pos = new XVertex3d();
                obj2D.GetPoint(i, ref pos.x, ref pos.y, ref pos.z);
                dlg.PositionArray.Add(pos);
            }
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.Color;
                obj2D.LinePattern = dlg.Type;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ShowObj = !(dlg.ObjectHide);
                if (obj2D.GetNumOfVertex() > dlg.PositionArray.Count)
                {
                    int i = 0;
                    for (; i < dlg.PositionArray.Count; i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                        obj3D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                    for (int x = i ; x < obj2D.GetNumOfVertex(); x++)
                    {
                        obj2D.RemovePointAt(i);
                    }
                }
                else if (obj2D.GetNumOfVertex() < dlg.PositionArray.Count)
                {
                    int i = 0;
                    for (; i < obj2D.GetNumOfVertex(); i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                        obj3D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                    for (int x = i; x < dlg.PositionArray.Count; x++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[x];
                        obj2D.AddPoint(pos.x, pos.y, pos.z);
                        obj3D.AddPoint(pos.x, pos.y, pos.z);
                    }
                }
                else
                {
                    int i = 0;
                    for (; i < dlg.PositionArray.Count; i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                        obj3D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                }
                
        
                obj3D.Name = dlg.ObjectName;
                obj3D.LineColor = dlg.Color;
                obj3D.LinePattern = dlg.Type;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj2D.CalcRange();
                obj3D.CalcRange();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
            }
        }
        private void ShowPolygonPropertyDlg(string strItemName)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null) return;
            if (sc3D == null) return;
            XscPolygon obj2D = (XscPolygon)sc2D.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            XscPolygon obj3D = (XscPolygon)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            PolygonProperty dlg = new PolygonProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.LineColor = obj2D.BorderColor;
            dlg.Type = obj2D.LinePattern;
            dlg.FillStyle = obj2D.FillPattern;
            dlg.LineWidth = obj2D.BorderSize;
            dlg.FillColor = obj2D.FillColor;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;

            int nItemCount = obj2D.GetNumOfVertex();
            for (int i = 0; i < nItemCount; i++)
            {
                XVertex3d pos = new XVertex3d();
                obj2D.GetPoint(i, ref pos.x, ref pos.y, ref pos.z);
                dlg.PositionArray.Add(pos);
            }
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.BorderColor = dlg.LineColor;
                obj2D.LinePattern = dlg.Type;
                obj2D.FillPattern = dlg.FillStyle;                
                obj2D.BorderSize = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.FillColor = dlg.FillColor;
                obj2D.ShowObj = !(dlg.ObjectHide);

                obj3D.Name = dlg.ObjectName;
                obj3D.BorderColor = dlg.LineColor;
                obj3D.LinePattern = dlg.Type;
                obj3D.FillPattern = dlg.FillStyle;
                obj3D.BorderSize = dlg.LineWidth;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.FillColor = dlg.FillColor;
                obj3D.ShowObj = !(dlg.ObjectHide);
                if (obj2D.GetNumOfVertex() > dlg.PositionArray.Count)
                {
                    int i = 0;
                    for (; i < dlg.PositionArray.Count; i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                        obj3D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                    for (int x = i; x < obj2D.GetNumOfVertex(); x++)
                    {
                        obj2D.RemovePointAt(i);
                    }
                }
                else if (obj2D.GetNumOfVertex() < dlg.PositionArray.Count)
                {
                    int i = 0;
                    for (; i < obj2D.GetNumOfVertex(); i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                        obj3D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                    for (int x = i; x < dlg.PositionArray.Count; x++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[x];
                        obj2D.AddPoint(pos.x, pos.y, pos.z);
                        obj3D.AddPoint(pos.x, pos.y, pos.z);
                    }
                }
                else
                {
                    int i = 0;
                    for (; i < dlg.PositionArray.Count; i++)
                    {
                        XVertex3d pos = (XVertex3d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z);
                        obj3D.SetPoint(i, pos.x, pos.y, pos.z);
                    }
                }

                try
                {
                    obj2D.DoTriangulate();
                    obj3D.DoTriangulate();
                    obj2D.CalcRange();
                    obj3D.CalcRange();
                    obj2D.CalcRange();
                }
                catch(Exception ex)
                {
                    System.Diagnostics.Debug.WriteLine(ex.Message);
                }

                
                





                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();

            }
        }


        private void ShowPolylineExPropertyDlg(string strItemName)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null) return;
            if (sc3D == null) return;
            XscPolyLineEx obj2D = (XscPolyLineEx)sc2D.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            XscPolyLineEx obj3D = (XscPolyLineEx)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            PolylineExProperty dlg = new PolylineExProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.LineColor = obj2D.LineColor;
            dlg.LineType = obj2D.LinePattern;
            dlg.LineWidth = obj2D.LineWidth;
            dlg.ColorFillSide = obj2D.FillColor;
            dlg.FillType = obj2D.FillPattern;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;
            int nItemCount = obj2D.GetNumOfVertex();
            for (int i = 0; i < nItemCount; i++)
            {
                XVertex4d pos = new XVertex4d();
                obj2D.GetPoint(i, ref pos.x, ref pos.y, ref pos.z, ref pos.w);
                dlg.PositionArray.Add(pos);
            }
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.LineColor;
                obj2D.LinePattern = dlg.LineType;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.FillColor = dlg.ColorFillSide;
                obj2D.FillPattern = dlg.FillType;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ShowObj = !(dlg.ObjectHide);
                if (obj2D.GetNumOfVertex() > dlg.PositionArray.Count)
                {
                    int i = 0;
                    for (; i < dlg.PositionArray.Count; i++)
                    {
                        XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
                        obj3D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
                    }
                    for (int x = i; x < obj2D.GetNumOfVertex(); x++)
                    {
                        obj2D.RemovePointAt(i);
                    }
                }
                else if (obj2D.GetNumOfVertex() < dlg.PositionArray.Count)
                {
                    int i = 0;
                    for (; i < obj2D.GetNumOfVertex(); i++)
                    {
                        XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
                        obj3D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
                    }
                    for (int x = i; x < dlg.PositionArray.Count; x++)
                    {
                        XVertex4d pos = (XVertex4d)dlg.PositionArray[x];
                        obj2D.AddPoint(pos.x, pos.y, pos.z, pos.w);
                        obj3D.AddPoint(pos.x, pos.y, pos.z, pos.w);
                    }
                }
                else
                {
                    int i = 0;
                    for (; i < dlg.PositionArray.Count; i++)
                    {
                        XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
                        obj2D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
                        obj3D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
                    }
                }


                obj3D.Name = dlg.ObjectName;
                obj3D.LineColor = dlg.LineColor;
                obj3D.LinePattern = dlg.LineType;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.FillColor = dlg.ColorFillSide;
                obj3D.FillPattern = dlg.FillType;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj2D.CalcRange();
                obj3D.CalcRange();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
            }
        }

        private void ShowCirclePropertyDlg(string strItemName)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null) return;
            if (sc3D == null) return;
            XscCircle obj2D = (XscCircle)sc2D.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            XscCircle obj3D = (XscCircle)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            CircleProperty dlg = new CircleProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.LineColor = obj2D.LineColor;
            dlg.Type = obj2D.LinePattern;
            dlg.FillStyle = obj2D.FillPattern;
            dlg.LineWidth = obj2D.LineWidth;
            dlg.FillColor = obj2D.FillColor;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;
            dlg.Radius = obj2D.Radius;
            double dx, dy, dz;
            dx = dy = dz = 0.0;
            
            obj2D.GetPoint(ref dx, ref dy, ref dz);
            dlg.LonDegree = dx;
            dlg.LatDegree = dy;
            dlg.HeightMeter = dz;
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.LineColor = dlg.LineColor;
                obj2D.LinePattern = dlg.Type;
                obj2D.FillPattern = dlg.FillStyle;
                obj2D.LineWidth = dlg.LineWidth;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.FillColor = dlg.FillColor;
                obj2D.Radius = dlg.Radius;
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);

                obj3D.Name = dlg.ObjectName;
                obj3D.LineColor = dlg.LineColor;
                obj3D.LinePattern = dlg.Type;
                obj3D.FillPattern = dlg.FillStyle;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.FillColor = dlg.FillColor;
                obj3D.Radius = dlg.Radius;
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);

                obj2D.CalcRange();
                obj3D.CalcRange();

                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
            }
        }

        private void ShowSymbolPropertyDlg(string strItemName)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null) return;
            if (sc3D == null) return;
            XscSymbol obj2D = (XscSymbol)sc2D.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            XscSymbol obj3D = (XscSymbol)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            SymbolProperty dlg = new SymbolProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;
            double dx, dy, dz;
            dx = dy = dz = 0.0;
            obj2D.GetPoint(ref dx, ref dy, ref dz);
            dlg.LonDegree = dx;
            dlg.LatDegree = dy;
            dlg.HeightMeter = dz;
            dlg.Symbol = obj2D.DefaultSymbolName;
            dlg.ImageFile = obj2D.UserSymbolPath;
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                if (dlg.UseDefaultSymbol)
                    obj2D.DefaultSymbolName = dlg.Symbol;
                else
                {
                    if (dlg.ImageFile != "")
                        obj2D.UserSymbolPath = dlg.ImageFile;
                }


                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ObjID = dlg.ID;
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                if (dlg.UseDefaultSymbol)
                    obj3D.DefaultSymbolName = dlg.Symbol;
                else
                {
                    if (dlg.ImageFile != "")
                        obj3D.UserSymbolPath = dlg.ImageFile;
                }


                obj2D.CalcRange();
                obj3D.CalcRange();
                obj2D.UpdateSymbol();
                obj3D.UpdateSymbol();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
            }
        }

        private void ShowConePropertyDlg(string strItemName)
        {
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc3D == null) return;

            XscCone obj3D = (XscCone)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            ConeProperty dlg = new ConeProperty();
            dlg.ID = obj3D.ObjID;
            dlg.ObjectName = obj3D.Name;
            dlg.LineColor = obj3D.LineColor;
            dlg.LineWidth = obj3D.LineWidth;
            dlg.FillColor = obj3D.FillColor;
            dlg.ShowName = obj3D.ShowName;
            dlg.TextColor = obj3D.TextColor;
            dlg.TextAlign = obj3D.TextAlign;
            dlg.Radius = obj3D.Radius;
            dlg.Yaw = obj3D.Yaw;
            dlg.Pitch = obj3D.Pitch;
            dlg.Roll = obj3D.Roll;
            dlg.Distance = obj3D.Height;
            dlg.ShowCilrcle = obj3D.ShowCircle;
            dlg.ShowSection = obj3D.ShowSection;
            dlg.ShowSectionLine = obj3D.ShowSectionLine;

            double dx, dy, dz;
            dx = dy = dz = 0.0;
            obj3D.GetPoint(ref dx, ref dy, ref dz);
            dlg.LonDegree = dx;
            dlg.LatDegree = dy;
            dlg.HeightMeter = dz;

            dlg.ObjectHide = !(obj3D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj3D.Name = dlg.ObjectName;
                obj3D.LineColor = dlg.LineColor;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.FillColor = Color.FromArgb(100, dlg.FillColor);
                obj3D.Yaw = dlg.Yaw;
                obj3D.Pitch = dlg.Pitch;
                obj3D.Roll = dlg.Roll;
                obj3D.Radius = dlg.Radius;
                obj3D.Height = dlg.Distance;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.ShowSectionLine = dlg.ShowSectionLine;
                obj3D.ShowSection = dlg.ShowSection;
                obj3D.ShowCircle = dlg.ShowCilrcle;
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj3D.CalcRange();

                nxPlanetView3D.RefreshScreen();
            }
        }

        private void ShowCubePropertyDlg(string strItemName)
        {
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc3D == null) return;

            XscCube obj3D = (XscCube)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            CubeProperty dlg = new CubeProperty();
            dlg.ID = obj3D.ObjID;
            dlg.ObjectName = obj3D.Name;
            dlg.LineColor = obj3D.LineColor;
            dlg.LineWidth = obj3D.LineWidth;
            dlg.FillColor = obj3D.FillColor;
            dlg.ShowName = obj3D.ShowName;
            dlg.TextColor = obj3D.TextColor;
            dlg.TextAlign = obj3D.TextAlign;
            dlg.CubeWidth = obj3D.Width;
            dlg.Yaw = obj3D.Yaw;
            dlg.Pitch = obj3D.Pitch;
            dlg.Roll = obj3D.Roll;
            dlg.Distance = obj3D.Height;
            dlg.ShowSection = obj3D.ShowSection;
            dlg.ShowSectionLine = obj3D.ShowSectionLine;

            double dx, dy, dz;
            dx = dy = dz = 0.0;
            obj3D.GetPoint(ref dx, ref dy, ref dz);
            dlg.LonDegree = dx;
            dlg.LatDegree = dy;
            dlg.HeightMeter = dz;
            dlg.ObjectHide = !(obj3D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj3D.Name = dlg.ObjectName;
                obj3D.LineColor = dlg.LineColor;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.FillColor = Color.FromArgb(100, dlg.FillColor);
                obj3D.Yaw = dlg.Yaw;
                obj3D.Pitch = dlg.Pitch;
                obj3D.Roll = dlg.Roll;
                obj3D.Width = dlg.CubeWidth;
                obj3D.Height = dlg.Distance;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.ShowSectionLine = dlg.ShowSectionLine;
                obj3D.ShowSection = dlg.ShowSection;
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj3D.CalcRange();

                nxPlanetView3D.RefreshScreen();
            }
        }

        private void ShowSpherePropertyDlg(string strItemName)
        {
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc3D == null) return;

            XscSphere obj3D = (XscSphere)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            SphereProperty dlg = new SphereProperty();
            dlg.ID = obj3D.ObjID;
            dlg.ObjectName = obj3D.Name;
            dlg.LineColor = obj3D.LineColor;
            dlg.LineWidth = obj3D.LineWidth;
            dlg.FillColor = obj3D.FillColor;
            dlg.ShowName = obj3D.ShowName;
            dlg.TextColor = obj3D.TextColor;
            dlg.TextAlign = obj3D.TextAlign;
            dlg.Radius = obj3D.Radius;
            dlg.ShowSection = obj3D.ShowSection;
            dlg.ShowSectionLine = obj3D.ShowSectionLine;

            double dx, dy, dz;
            dx = dy = dz = 0.0;
            obj3D.GetPoint(ref dx, ref dy, ref dz);
            dlg.LonDegree = dx;
            dlg.LatDegree = dy;
            dlg.HeightMeter = dz;
            dlg.ObjectHide = !(obj3D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj3D.Name = dlg.ObjectName;
                obj3D.LineColor = dlg.LineColor;
                obj3D.LineWidth = dlg.LineWidth;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.FillColor = Color.FromArgb(100, dlg.FillColor);
                obj3D.Radius = dlg.Radius;
                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj3D.ShowSectionLine = dlg.ShowSectionLine;
                obj3D.ShowSection = dlg.ShowSection;
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj3D.CalcRange();

                nxPlanetView3D.RefreshScreen();
            }
        }

        //private void ShowPrismPropertyDlg(string strItemName)
        //{
        //    XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
        //    XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
        //    if (sc2D == null) return;
        //    if (sc3D == null) return;
        //    XscPrism obj2D = (XscPrism)sc2D.GetNode(int.Parse(strItemName));
        //    if (obj2D == null) return;

        //    XscPrism obj3D = (XscPrism)sc3D.GetNode(int.Parse(strItemName));
        //    if (obj3D == null) return;

        //    PrismProperty dlg = new PrismProperty();
        //    dlg.ID = obj2D.ObjID;
        //    dlg.ObjectName = obj2D.Name;
        //    dlg.LineColor = obj2D.BorderColor;
        //    dlg.FillColor = obj2D.FillColor;
        //    dlg.FillColor = obj2D.FillColor;
        //    dlg.FillColorTop = obj2D.TopFillColor;
        //    dlg.FillColorBottom = obj2D.BottomFillColor;

        //    dlg.StyleLine = obj2D.LinePattern;
        //    dlg.StyleFill = obj2D.FillPattern;
        //    dlg.StyleFillTop = obj2D.TopFillPattern;
        //    dlg.StyleFillBottom = obj2D.BottomFillPattern;

        //    dlg.LineWidth = obj2D.BorderSize;
           
        //    dlg.ShowName = obj2D.ShowName;
        //    dlg.TextColor = obj2D.TextColor;
        //    dlg.TextAlign = obj2D.TextAlign;

        //    int nItemCount = obj2D.GetNumofVertex();
        //    for (int i = 0; i < nItemCount; i++)
        //    {
        //        XVertex4d pos = new XVertex4d();
        //        obj2D.GetPoint(i, ref pos.x, ref pos.y, ref pos.z, ref pos.w);
        //        dlg.PositionArray.Add(pos);
        //    }
        //    dlg.ObjectHide = !(obj2D.ShowObj);
        //    if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        //    {
        //        obj2D.Name = dlg.ObjectName;
        //        obj2D.BorderColor = dlg.LineColor;
        //        obj2D.LinePattern = dlg.StyleLine;
        //        obj2D.FillPattern = dlg.StyleFill;
        //        obj2D.BorderSize = dlg.LineWidth;
        //        obj2D.ShowName = dlg.ShowName;
        //        obj2D.TextColor = dlg.TextColor;
        //        obj2D.TextAlign = dlg.TextAlign;
        //        obj2D.FillColor = dlg.FillColor;
        //        obj2D.TopFillColor = dlg.FillColorTop;
        //        obj2D.BottomFillColor = dlg.FillColorBottom;
        //        obj2D.TopFillPattern = dlg.StyleFillTop;
        //        obj2D.BottomFillPattern = dlg.StyleFillBottom;
        //        obj2D.ShowObj = !(dlg.ObjectHide);

        //        obj3D.Name = dlg.ObjectName;
        //        obj3D.BorderColor = dlg.LineColor;
        //        obj3D.LinePattern = dlg.StyleLine;
        //        obj3D.FillPattern = dlg.StyleFill;
        //        obj3D.BorderSize = dlg.LineWidth;
        //        obj3D.ShowName = dlg.ShowName;
        //        obj3D.TextColor = dlg.TextColor;
        //        obj3D.TextAlign = dlg.TextAlign;
        //        obj3D.FillColor = dlg.FillColor;
        //        obj3D.TopFillColor = dlg.FillColorTop;
        //        obj3D.BottomFillColor = dlg.FillColorBottom;
        //        obj3D.TopFillPattern = dlg.StyleFillTop;
        //        obj3D.BottomFillPattern = dlg.StyleFillBottom;
        //        obj3D.ShowObj = !(dlg.ObjectHide);

        //        if (obj2D.GetNumofVertex() > dlg.PositionArray.Count)
        //        {
        //            int i = 0;
        //            for (; i < dlg.PositionArray.Count; i++)
        //            {
        //                XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
        //                obj2D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
        //                obj3D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
        //            }
        //            for (int x = i; x < obj2D.GetNumofVertex(); x++)
        //            {
        //                obj2D.RemovePointAt(i);
        //            }
        //        }
        //        else if (obj2D.GetNumofVertex() < dlg.PositionArray.Count)
        //        {
        //            int i = 0;
        //            for (; i < obj2D.GetNumofVertex(); i++)
        //            {
        //                XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
        //                obj2D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
        //                obj3D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
        //            }
        //            for (int x = i; x < dlg.PositionArray.Count; x++)
        //            {
        //                XVertex4d pos = (XVertex4d)dlg.PositionArray[x];
        //                obj2D.AddPoint(pos.x, pos.y, pos.z, pos.w);
        //                obj3D.AddPoint(pos.x, pos.y, pos.z, pos.w);
        //            }
        //        }
        //        else
        //        {
        //            int i = 0;
        //            for (; i < dlg.PositionArray.Count; i++)
        //            {
        //                XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
        //                obj2D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
        //                obj3D.SetPoint(i, pos.x, pos.y, pos.z, pos.w);
        //            }
        //        }
        //        obj2D.DoTriangulate();
        //        obj3D.DoTriangulate();
        //        obj2D.CalcRange();
        //        obj3D.CalcRange();

        //        nxPlanetView2D.RefreshScreen();
        //        nxPlanetView3D.RefreshScreen();

        //    }
        //}

        private void ShowTextPropertyDlg(string strItemName)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null) return;
            if (sc3D == null) return;
            XscText obj2D = (XscText)sc2D.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            XscText obj3D = (XscText)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            TextProperty dlg = new TextProperty();
            dlg.nID = obj2D.ObjID;
            dlg.strText = obj2D.Text;
            dlg.bShowText = obj2D.ShowObj;
            dlg.strFontname = obj2D.FontName;
            dlg.nFontSize = obj2D.FontHeight;
            dlg.textcolor = obj2D.TextColor;
            dlg.outlineColor = obj2D.TextOutLineColor;
            dlg.bShowOutline = obj2D.ShowOutLine;
            dlg.m_TextAlign = obj2D.TextAlign;
            dlg.bUnderLine = obj2D.IsUnderLine;
            dlg.bBold = obj2D.IsBold;
            dlg.bStrikeout = obj2D.IsStrikeOut;
            dlg.bItalic = obj2D.IsItalic;
            dlg.BorderLineStyle = obj2D.TextBorderStyle;
            dlg.bShowBorder = obj2D.IsTextBorder;
            dlg.nBorderLineWidth = obj2D.BorderLineWidth;
            double dx, dy, dz;
            dx = dy = dz = 0.0;
            obj3D.GetPoint(ref dx, ref dy, ref dz);
            dlg.m_dLonDegree = dx;
            dlg.m_dLatDegree = dy;
            dlg.m_dHeight = dz;
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Text = dlg.strText;
                obj2D.ShowObj = dlg.bShowText;
                obj2D.FontName = dlg.strFontname;
                obj2D.FontHeight = dlg.nFontSize;
                obj2D.TextColor = dlg.textcolor;
                obj2D.TextOutLineColor = dlg.outlineColor;
                obj2D.ShowOutLine = dlg.bShowOutline;
                obj2D.TextAlign = dlg.m_TextAlign;
                obj2D.IsUnderLine = dlg.bUnderLine;
                obj2D.IsBold = dlg.bBold;
                obj2D.IsStrikeOut = dlg.bStrikeout;
                obj2D.IsItalic = dlg.bItalic;
                obj2D.TextBorderStyle = dlg.BorderLineStyle;
                obj2D.IsTextBorder = dlg.bShowBorder;
                obj2D.BorderLineWidth = dlg.nBorderLineWidth;
                obj2D.ShowObj = !(dlg.ObjectHide);
                obj2D.SetPoint(dlg.m_dLonDegree, dlg.m_dLatDegree, dlg.m_dHeight);
                
                obj3D.Text = dlg.strText;
                obj3D.ShowObj = dlg.bShowText;
                obj3D.FontName = dlg.strFontname;
                obj3D.FontHeight = dlg.nFontSize;
                obj3D.TextColor = dlg.textcolor;
                obj3D.TextOutLineColor = dlg.outlineColor;
                obj3D.ShowOutLine = dlg.bShowOutline;
                obj3D.TextAlign = dlg.m_TextAlign;
                obj3D.IsUnderLine = dlg.bUnderLine;
                obj3D.IsBold = dlg.bBold;
                obj3D.IsStrikeOut = dlg.bStrikeout;
                obj3D.IsItalic = dlg.bItalic;
                obj3D.TextBorderStyle = dlg.BorderLineStyle;
                obj3D.IsTextBorder = dlg.bShowBorder;
                obj3D.BorderLineWidth = dlg.nBorderLineWidth;
                obj3D.ShowObj = !(dlg.ObjectHide);
                obj3D.SetPoint(dlg.m_dLonDegree, dlg.m_dLatDegree, dlg.m_dHeight);
                obj2D.CalcRange();
                obj3D.CalcRange();
            }
        }

        private void ShowPropertyDlg(string strItemName, string objType)
        {
            if ("Point" == objType)
                ShowPointPropertyDlg(strItemName);
            if ("PointEx" == objType)
                ShowPointExPropertyDlg(strItemName);
            else if ("Polyline" == objType)
                ShowPolylinePropertyDlg(strItemName);
            else if ("Polygon" == objType)
                ShowPolygonPropertyDlg(strItemName);
            else if ("Circle" == objType)
                ShowCirclePropertyDlg(strItemName);
            else if ("Symbol" == objType)
                ShowSymbolPropertyDlg(strItemName);
            else if ("Cone" == objType)
                ShowConePropertyDlg(strItemName);
            else if ("Cube" == objType)
                ShowCubePropertyDlg(strItemName);
            else if ("Sphere" == objType)
                ShowSpherePropertyDlg(strItemName);
            else if ("Text" == objType)
                ShowTextPropertyDlg(strItemName);
            else if ("Model" == objType)
                ShowModelPropertyDlg(strItemName);
            else if ("Cylinder" == objType)
                ShowCylinderPropertyDlg(strItemName);
            else if ("PolylineEx" == objType)
                ShowPolylineExPropertyDlg(strItemName);
            else if ("Prism" == objType)
                ShowPrismPropertyDlg(strItemName);

        }
       
        private void ObjectTree_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                TreeNode nodeitem = ObjectTree.GetNodeAt(e.X, e.Y);
                if (nodeitem == null) return;
                string selectedNickname = nodeitem.Text;

                if( "XScene"   != selectedNickname &&
                    "Point"    != selectedNickname &&
                    "Polyline" != selectedNickname &&
                    "Polygon"  != selectedNickname &&
                    "Circle"   != selectedNickname &&
                    "Symbol"    != selectedNickname &&
                    "Text" != selectedNickname &&
                    "Cube" != selectedNickname &&
                    "Cone" != selectedNickname &&
                    "Sphere" != selectedNickname &&
                    "Model"    != selectedNickname)
                {

                    ContextMenu m = new ContextMenu();

                    MenuItem property = new MenuItem();
                    property.Text = "속성";
                    property.Click += (senders, es) =>
                    {
                        ShowPropertyDlg(selectedNickname,nodeitem.Parent.Text);
                    };

                    m.MenuItems.Add(property);
                    m.Show(ObjectTree, new Point(e.X, e.Y));

                }
            }
        }

        private void ShowModelPropertyDlg(string strItemName)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null) return;
            if (sc3D == null) return;

            XscModel obj2D = (XscModel)sc2D.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            XscModel obj3D = (XscModel)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            ModelProperty dlg = new ModelProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.ShowName = obj2D.ShowName;
            //            dlg.TextColor = obj2D.TextColor;
            dlg.TextAlign = obj2D.TextAlign;

            dlg.LonDegree = obj2D.Position.x;
            dlg.LatDegree = obj2D.Position.y;
            dlg.HeightMeter = obj2D.Position.z;
            dlg.ScaleX = obj2D.Scale.x;
            dlg.ScaleY = obj2D.Scale.y;
            dlg.ScaleZ = obj2D.Scale.z;

            XAngle yaw = new XAngle(), pitch = new XAngle(), roll = new XAngle();
            obj2D.GetRotation(ref yaw, ref pitch, ref roll);
            dlg.OrientRoll = roll.deg;
            dlg.OrientPitch = pitch.deg;
            dlg.OrientYaw = yaw.deg;
            dlg.ModelFile = obj2D.FilePath;
            dlg.ObjectHide = !(obj2D.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.Name = dlg.ObjectName;
                obj2D.ShowName = dlg.ShowName;
                //                obj2D.TextColor = dlg.TextColor;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.ObjID = dlg.ID;

                XscCoord newPosition = new XscCoord(dlg.LonDegree, dlg.LatDegree, dlg.HeightMeter);
                obj2D.Position = newPosition;
                obj2D.Scale = new XVertex3d(dlg.ScaleX, dlg.ScaleY, dlg.ScaleZ);
                obj2D.SetRotation(XAngle.FromDegree(dlg.OrientYaw), XAngle.FromDegree(dlg.OrientPitch), XAngle.FromDegree(dlg.OrientRoll));
                obj2D.FilePath = dlg.ModelFile;
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;


                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                //                obj3D.TextColor = dlg.TextColor;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.ObjID = dlg.ID;
                obj3D.Position = newPosition;
                obj3D.Scale = new XVertex3d(dlg.ScaleX, dlg.ScaleY, dlg.ScaleZ);
                obj3D.SetRotation(XAngle.FromDegree(dlg.OrientYaw), XAngle.FromDegree(dlg.OrientPitch), XAngle.FromDegree(dlg.OrientRoll));
                obj3D.FilePath = dlg.ModelFile;
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;


                obj2D.CalcRange();
                obj3D.CalcRange();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
            }
        }

        private void ShowCylinderPropertyDlg(string strItemName)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null) return;
            if (sc3D == null) return;

            XscCylinder obj2D = (XscCylinder)sc2D.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            XscCylinder obj3D = (XscCylinder)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            CylinderProperty dlg = new CylinderProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.LineColor = obj2D.LineColor;
            dlg.FillColorSide = obj2D.FillColor;
            dlg.FillColorTop = obj2D.TopFillColor;
            dlg.FillColorBottom = obj2D.BottomFillColor;

            dlg.StyleLine = obj2D.LinePattern;
            dlg.StyleFillSide = obj2D.FillPattern;
            dlg.StyleFillTop = obj2D.TopFillPattern;
            dlg.StyleFillBottom = obj2D.BottomFillPattern;
            dlg.TextAlign = obj2D.TextAlign;
            dlg.LineWidth = obj2D.LineWidth;

            double lonDegree=0.0, latDegree=0.0, hgtMin=0.0, hgtMax = 0.0;
            obj2D.GetPoint(ref lonDegree, ref latDegree, ref hgtMin, ref hgtMax);
            dlg.LonDegree = lonDegree;
            dlg.LatDegree = latDegree;
            dlg.HeightMinMeter = hgtMin;
            dlg.HeightMaxMeter = hgtMax;
            dlg.RadiusMeter = obj2D.Radius;

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.ObjID = dlg.ID;
                obj2D.Name = dlg.ObjectName;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.LineColor = dlg.LineColor;
                obj2D.FillColor = dlg.FillColorSide;
                obj2D.TopFillColor = dlg.FillColorTop;
                obj2D.BottomFillColor = dlg.FillColorBottom;

                obj2D.LinePattern = dlg.StyleLine;
                obj2D.FillPattern = dlg.StyleFillSide;
                obj2D.TopFillPattern = dlg.StyleFillTop;
                obj2D.BottomFillPattern = dlg.StyleFillBottom;
                obj2D.TextAlign = dlg.TextAlign;
                obj2D.LineWidth = dlg.LineWidth;
                
                obj2D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMinMeter, dlg.HeightMaxMeter);
                obj2D.Radius = dlg.RadiusMeter;
                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;

                /////////////////////////////////////////////////
                obj3D.ObjID = dlg.ID;
                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.LineColor = dlg.LineColor;
                obj3D.FillColor = dlg.FillColorSide;
                obj3D.TopFillColor = dlg.FillColorTop;
                obj3D.BottomFillColor = dlg.FillColorBottom;
                obj3D.LinePattern = dlg.StyleLine;
                obj3D.FillPattern = dlg.StyleFillSide;
                obj3D.TopFillPattern = dlg.StyleFillTop;
                obj3D.BottomFillPattern = dlg.StyleFillBottom;
                obj3D.TextAlign = dlg.TextAlign;
                obj3D.LineWidth = dlg.LineWidth;

                obj3D.SetPoint(dlg.LonDegree, dlg.LatDegree, dlg.HeightMinMeter, dlg.HeightMaxMeter);
                obj3D.Radius = dlg.RadiusMeter;
                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;


                obj2D.CalcRange();
                obj3D.CalcRange();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
            }
        }

        private void ShowPrismPropertyDlg(string strItemName)
        {
            XScene sc2D = nxPlanetLayerSceneDisplay2D.GetScene();
            XScene sc3D = nxPlanetLayerSceneDisplay3D.GetScene();
            if (sc2D == null) return;
            if (sc3D == null) return;

            XscPrism obj2D = (XscPrism)sc2D.GetNode(int.Parse(strItemName));
            if (obj2D == null) return;

            XscPrism obj3D = (XscPrism)sc3D.GetNode(int.Parse(strItemName));
            if (obj3D == null) return;

            PrismProperty dlg = new PrismProperty();
            dlg.ID = obj2D.ObjID;
            dlg.ObjectName = obj2D.Name;
            dlg.ShowName = obj2D.ShowName;
            dlg.TextColor = obj2D.TextColor;
            dlg.LineColor = obj2D.BorderColor;
            dlg.FillColor = obj2D.FillColor;
            dlg.FillColorBottom = obj2D.BottomFillColor;
            dlg.FillColorTop = obj2D.TopFillColor;

            dlg.StyleLine = obj2D.LinePattern;
            dlg.StyleFill = obj2D.FillPattern;
            dlg.StyleFillTop = obj2D.TopFillPattern;
            dlg.StyleFillBottom = obj2D.BottomFillPattern;

            dlg.TextAlign = obj2D.TextAlign;
            dlg.LineWidth = obj2D.BorderSize;

            double x = 0.0, y = 0.0, hgtMin = 0.0, hgtMax = 0.0;
            int numVertex = obj2D.GetNumOfVertex();
            for (int i = 0; i < numVertex; i++)
            {
                obj2D.GetPoint(i, ref x, ref y, ref hgtMin, ref hgtMax);
                XVertex4d pos = new XVertex4d(x, y, hgtMin, hgtMax);
                dlg.PositionArray.Add(pos);
            }

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj2D.ObjID = dlg.ID;
                obj2D.Name = dlg.ObjectName;
                obj2D.ShowName = dlg.ShowName;
                obj2D.TextColor = dlg.TextColor;
                obj2D.BorderColor = dlg.LineColor;
                obj2D.FillColor = dlg.FillColor;
                obj2D.BottomFillColor = dlg.FillColorBottom;
                obj2D.TopFillColor = dlg.FillColorTop;

                obj2D.LinePattern = dlg.StyleLine;

                obj2D.FillPattern = dlg.StyleFill;
                obj2D.BottomFillPattern = dlg.StyleFillBottom;
                obj2D.TopFillPattern = dlg.StyleFillTop;

                obj2D.TextAlign = dlg.TextAlign;
                obj2D.BorderSize = dlg.LineWidth;

                obj2D.VisibleDistMax = -1.0;
                obj2D.VisibleDistMin = -1.0;

                obj2D.RemoveAll();
                for (int i = 0; i < dlg.PositionArray.Count; i++)
                {
                    XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
                    obj2D.AddPoint(pos.x, pos.y, pos.z, pos.w);
                }


                /////////////////////////////////////////////////
                obj3D.ObjID = dlg.ID;
                obj3D.Name = dlg.ObjectName;
                obj3D.ShowName = dlg.ShowName;
                obj3D.TextColor = dlg.TextColor;
                obj3D.BorderColor = dlg.LineColor;
                obj3D.FillColor = dlg.FillColor;
                obj3D.BottomFillColor = dlg.FillColorBottom;
                obj3D.TopFillColor = dlg.FillColorTop;

                obj3D.LinePattern = dlg.StyleLine;

                obj3D.FillPattern = dlg.StyleFill;
                obj3D.BottomFillPattern = dlg.StyleFillBottom;
                obj3D.TopFillPattern = dlg.StyleFillTop;

                obj3D.TextAlign = dlg.TextAlign;
                obj3D.BorderSize = dlg.LineWidth;

                obj3D.VisibleDistMax = -1.0;
                obj3D.VisibleDistMin = -1.0;

                obj3D.RemoveAll();
                for (int i = 0; i < dlg.PositionArray.Count; i++)
                {
                    XVertex4d pos = (XVertex4d)dlg.PositionArray[i];
                    obj3D.AddPoint(pos.x, pos.y, pos.z, pos.w);
                }

                obj2D.CalcRange();
                obj3D.CalcRange();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
            }
        }



    }
}
