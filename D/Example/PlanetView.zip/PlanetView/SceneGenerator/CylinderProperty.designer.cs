﻿namespace SceneGenerator
{
    partial class CylinderProperty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CylinderProperty));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.TextBox_ID = new System.Windows.Forms.TextBox();
            this.TextBox_Name = new System.Windows.Forms.TextBox();
            this.TextBox_LineColor = new System.Windows.Forms.TextBox();
            this.Button_ColorDlg = new System.Windows.Forms.Button();
            this.ButtonApply = new System.Windows.Forms.Button();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.textBox_LineWidth = new System.Windows.Forms.TextBox();
            this.checkBox_ShowName = new System.Windows.Forms.CheckBox();
            this.Button_TextColorDlg = new System.Windows.Forms.Button();
            this.TextBox_TextColor = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox_TextAlign = new System.Windows.Forms.ComboBox();
            this.Button_ColorDlgFill = new System.Windows.Forms.Button();
            this.textBox_FillColor = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox_HgtMax = new System.Windows.Forms.TextBox();
            this.groupBox_Position = new System.Windows.Forms.GroupBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox_Radius = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox_HgtMin = new System.Windows.Forms.TextBox();
            this.textBox_Lat = new System.Windows.Forms.TextBox();
            this.textBox_Long = new System.Windows.Forms.TextBox();
            this.comboBox_Hide = new System.Windows.Forms.ComboBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox_Style = new System.Windows.Forms.ComboBox();
            this.label13 = new System.Windows.Forms.Label();
            this.comboBox_FillStyle = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.comboBox_FillStyleBottom = new System.Windows.Forms.ComboBox();
            this.label18 = new System.Windows.Forms.Label();
            this.comboBox_FillStyleTop = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox_FillColorBottom = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.Button_ColorDlgFillBottom = new System.Windows.Forms.Button();
            this.textBox_FillColorTop = new System.Windows.Forms.TextBox();
            this.Button_ColorDlgFillTop = new System.Windows.Forms.Button();
            this.groupBox_Position.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "▶ ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(248, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "▶ Name :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(87, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "▶ Line Width :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(14, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(83, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "▶ LineColor :";
            // 
            // TextBox_ID
            // 
            this.TextBox_ID.Location = new System.Drawing.Point(95, 17);
            this.TextBox_ID.Name = "TextBox_ID";
            this.TextBox_ID.ReadOnly = true;
            this.TextBox_ID.Size = new System.Drawing.Size(131, 21);
            this.TextBox_ID.TabIndex = 5;
            // 
            // TextBox_Name
            // 
            this.TextBox_Name.Location = new System.Drawing.Point(331, 20);
            this.TextBox_Name.Name = "TextBox_Name";
            this.TextBox_Name.Size = new System.Drawing.Size(131, 21);
            this.TextBox_Name.TabIndex = 5;
            // 
            // TextBox_LineColor
            // 
            this.TextBox_LineColor.Location = new System.Drawing.Point(103, 85);
            this.TextBox_LineColor.Name = "TextBox_LineColor";
            this.TextBox_LineColor.ReadOnly = true;
            this.TextBox_LineColor.Size = new System.Drawing.Size(94, 21);
            this.TextBox_LineColor.TabIndex = 5;
            // 
            // Button_ColorDlg
            // 
            this.Button_ColorDlg.Location = new System.Drawing.Point(199, 86);
            this.Button_ColorDlg.Name = "Button_ColorDlg";
            this.Button_ColorDlg.Size = new System.Drawing.Size(27, 19);
            this.Button_ColorDlg.TabIndex = 7;
            this.Button_ColorDlg.Text = "...";
            this.Button_ColorDlg.UseVisualStyleBackColor = true;
            this.Button_ColorDlg.Click += new System.EventHandler(this.Button_ColorDlg_Click);
            // 
            // ButtonApply
            // 
            this.ButtonApply.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.ButtonApply.Location = new System.Drawing.Point(350, 401);
            this.ButtonApply.Name = "ButtonApply";
            this.ButtonApply.Size = new System.Drawing.Size(59, 25);
            this.ButtonApply.TabIndex = 8;
            this.ButtonApply.Text = "Apply";
            this.ButtonApply.UseVisualStyleBackColor = true;
            this.ButtonApply.Click += new System.EventHandler(this.ButtonApply_Click);
            // 
            // button_Cancel
            // 
            this.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Cancel.Location = new System.Drawing.Point(420, 401);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(59, 25);
            this.button_Cancel.TabIndex = 9;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // textBox_LineWidth
            // 
            this.textBox_LineWidth.Location = new System.Drawing.Point(103, 143);
            this.textBox_LineWidth.Name = "textBox_LineWidth";
            this.textBox_LineWidth.Size = new System.Drawing.Size(121, 21);
            this.textBox_LineWidth.TabIndex = 10;
            // 
            // checkBox_ShowName
            // 
            this.checkBox_ShowName.AutoSize = true;
            this.checkBox_ShowName.Location = new System.Drawing.Point(368, 47);
            this.checkBox_ShowName.Name = "checkBox_ShowName";
            this.checkBox_ShowName.Size = new System.Drawing.Size(94, 16);
            this.checkBox_ShowName.TabIndex = 11;
            this.checkBox_ShowName.Text = "Show Name";
            this.checkBox_ShowName.UseVisualStyleBackColor = true;
            this.checkBox_ShowName.CheckedChanged += new System.EventHandler(this.checkBox_ShowName_CheckedChanged);
            // 
            // Button_TextColorDlg
            // 
            this.Button_TextColorDlg.Location = new System.Drawing.Point(199, 177);
            this.Button_TextColorDlg.Name = "Button_TextColorDlg";
            this.Button_TextColorDlg.Size = new System.Drawing.Size(27, 19);
            this.Button_TextColorDlg.TabIndex = 14;
            this.Button_TextColorDlg.Text = "...";
            this.Button_TextColorDlg.UseVisualStyleBackColor = true;
            this.Button_TextColorDlg.Click += new System.EventHandler(this.Button_TextColorDlg_Click);
            // 
            // TextBox_TextColor
            // 
            this.TextBox_TextColor.Location = new System.Drawing.Point(103, 176);
            this.TextBox_TextColor.Name = "TextBox_TextColor";
            this.TextBox_TextColor.ReadOnly = true;
            this.TextBox_TextColor.Size = new System.Drawing.Size(94, 21);
            this.TextBox_TextColor.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 180);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 12);
            this.label6.TabIndex = 12;
            this.label6.Text = "▶ Text Color :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(14, 209);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 12);
            this.label7.TabIndex = 15;
            this.label7.Text = "▶ Text Align :";
            // 
            // comboBox_TextAlign
            // 
            this.comboBox_TextAlign.FormattingEnabled = true;
            this.comboBox_TextAlign.Items.AddRange(new object[] {
            "Center",
            "Left",
            "Right"});
            this.comboBox_TextAlign.Location = new System.Drawing.Point(103, 205);
            this.comboBox_TextAlign.Name = "comboBox_TextAlign";
            this.comboBox_TextAlign.Size = new System.Drawing.Size(121, 20);
            this.comboBox_TextAlign.TabIndex = 16;
            this.comboBox_TextAlign.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Button_ColorDlgFill
            // 
            this.Button_ColorDlgFill.Location = new System.Drawing.Point(193, 20);
            this.Button_ColorDlgFill.Name = "Button_ColorDlgFill";
            this.Button_ColorDlgFill.Size = new System.Drawing.Size(27, 19);
            this.Button_ColorDlgFill.TabIndex = 19;
            this.Button_ColorDlgFill.Text = "...";
            this.Button_ColorDlgFill.UseVisualStyleBackColor = true;
            this.Button_ColorDlgFill.Click += new System.EventHandler(this.button_FillColorDlg_Click);
            // 
            // textBox_FillColor
            // 
            this.textBox_FillColor.Location = new System.Drawing.Point(128, 19);
            this.textBox_FillColor.Name = "textBox_FillColor";
            this.textBox_FillColor.ReadOnly = true;
            this.textBox_FillColor.Size = new System.Drawing.Size(63, 21);
            this.textBox_FillColor.TabIndex = 18;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(8, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(75, 12);
            this.label8.TabIndex = 17;
            this.label8.Text = "▶ FillColor :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(318, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 12);
            this.label9.TabIndex = 20;
            this.label9.Text = "Max :";
            // 
            // textBox_HgtMax
            // 
            this.textBox_HgtMax.Location = new System.Drawing.Point(362, 56);
            this.textBox_HgtMax.Name = "textBox_HgtMax";
            this.textBox_HgtMax.Size = new System.Drawing.Size(67, 21);
            this.textBox_HgtMax.TabIndex = 21;
            // 
            // groupBox_Position
            // 
            this.groupBox_Position.Controls.Add(this.label21);
            this.groupBox_Position.Controls.Add(this.label20);
            this.groupBox_Position.Controls.Add(this.textBox_Radius);
            this.groupBox_Position.Controls.Add(this.label5);
            this.groupBox_Position.Controls.Add(this.label10);
            this.groupBox_Position.Controls.Add(this.textBox_HgtMax);
            this.groupBox_Position.Controls.Add(this.label11);
            this.groupBox_Position.Controls.Add(this.label9);
            this.groupBox_Position.Controls.Add(this.label12);
            this.groupBox_Position.Controls.Add(this.textBox_HgtMin);
            this.groupBox_Position.Controls.Add(this.textBox_Lat);
            this.groupBox_Position.Controls.Add(this.textBox_Long);
            this.groupBox_Position.Location = new System.Drawing.Point(14, 275);
            this.groupBox_Position.Name = "groupBox_Position";
            this.groupBox_Position.Size = new System.Drawing.Size(465, 120);
            this.groupBox_Position.TabIndex = 22;
            this.groupBox_Position.TabStop = false;
            this.groupBox_Position.Text = "World Position";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(139, 30);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(68, 12);
            this.label21.TabIndex = 25;
            this.label21.Text = "Longitude :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(173, 61);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(34, 12);
            this.label20.TabIndex = 24;
            this.label20.Text = "Min :";
            // 
            // textBox_Radius
            // 
            this.textBox_Radius.Location = new System.Drawing.Point(128, 85);
            this.textBox_Radius.Name = "textBox_Radius";
            this.textBox_Radius.Size = new System.Drawing.Size(67, 21);
            this.textBox_Radius.TabIndex = 23;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(10, 88);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 12);
            this.label5.TabIndex = 22;
            this.label5.Text = "▶ Radius (Meter)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 61);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(102, 12);
            this.label10.TabIndex = 15;
            this.label10.Text = "▶ Height (Meter)";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(299, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 12);
            this.label11.TabIndex = 15;
            this.label11.Text = "Latitude :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(10, 30);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 12);
            this.label12.TabIndex = 15;
            this.label12.Text = "▶ Center (degree)";
            // 
            // textBox_HgtMin
            // 
            this.textBox_HgtMin.Location = new System.Drawing.Point(213, 56);
            this.textBox_HgtMin.Name = "textBox_HgtMin";
            this.textBox_HgtMin.Size = new System.Drawing.Size(68, 21);
            this.textBox_HgtMin.TabIndex = 10;
            // 
            // textBox_Lat
            // 
            this.textBox_Lat.Location = new System.Drawing.Point(362, 23);
            this.textBox_Lat.Name = "textBox_Lat";
            this.textBox_Lat.Size = new System.Drawing.Size(68, 21);
            this.textBox_Lat.TabIndex = 9;
            // 
            // textBox_Long
            // 
            this.textBox_Long.Location = new System.Drawing.Point(213, 23);
            this.textBox_Long.Name = "textBox_Long";
            this.textBox_Long.Size = new System.Drawing.Size(68, 21);
            this.textBox_Long.TabIndex = 8;
            // 
            // comboBox_Hide
            // 
            this.comboBox_Hide.FormattingEnabled = true;
            this.comboBox_Hide.Items.AddRange(new object[] {
            "True",
            "False"});
            this.comboBox_Hide.Location = new System.Drawing.Point(103, 234);
            this.comboBox_Hide.Name = "comboBox_Hide";
            this.comboBox_Hide.Size = new System.Drawing.Size(121, 20);
            this.comboBox_Hide.TabIndex = 37;
            this.comboBox_Hide.SelectedIndexChanged += new System.EventHandler(this.comboBox_Hide_SelectedIndexChanged);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(14, 238);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(54, 12);
            this.label16.TabIndex = 36;
            this.label16.Text = "▶ Hide :";
            // 
            // comboBox_Style
            // 
            this.comboBox_Style.FormattingEnabled = true;
            this.comboBox_Style.Items.AddRange(new object[] {
            "Solid",
            "Dash",
            "Dot",
            "Dash-Dot",
            "Dash-Dot-Dot"});
            this.comboBox_Style.Location = new System.Drawing.Point(103, 114);
            this.comboBox_Style.Name = "comboBox_Style";
            this.comboBox_Style.Size = new System.Drawing.Size(121, 20);
            this.comboBox_Style.TabIndex = 39;
            this.comboBox_Style.SelectedIndexChanged += new System.EventHandler(this.comboBox_Style_SelectedIndexChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 118);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(85, 12);
            this.label13.TabIndex = 38;
            this.label13.Text = "▶ Line Style :";
            // 
            // comboBox_FillStyle
            // 
            this.comboBox_FillStyle.FormattingEnabled = true;
            this.comboBox_FillStyle.Items.AddRange(new object[] {
            "Solid",
            "Bdiagonal",
            "Cross",
            "Diag Cross",
            "FDiagonal",
            "Horizontal",
            "Vertical",
            "Hollow"});
            this.comboBox_FillStyle.Location = new System.Drawing.Point(126, 44);
            this.comboBox_FillStyle.Name = "comboBox_FillStyle";
            this.comboBox_FillStyle.Size = new System.Drawing.Size(92, 20);
            this.comboBox_FillStyle.TabIndex = 41;
            this.comboBox_FillStyle.SelectedIndexChanged += new System.EventHandler(this.comboBox_FillStyle_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(8, 48);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(77, 12);
            this.label14.TabIndex = 40;
            this.label14.Text = "▶ Fill Style :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.comboBox_FillStyleBottom);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.comboBox_FillStyleTop);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.textBox_FillColorBottom);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.Button_ColorDlgFillBottom);
            this.groupBox1.Controls.Add(this.textBox_FillColorTop);
            this.groupBox1.Controls.Add(this.Button_ColorDlgFillTop);
            this.groupBox1.Controls.Add(this.comboBox_FillStyle);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.textBox_FillColor);
            this.groupBox1.Controls.Add(this.Button_ColorDlgFill);
            this.groupBox1.Location = new System.Drawing.Point(252, 76);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(227, 184);
            this.groupBox1.TabIndex = 42;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " Fill ";
            // 
            // comboBox_FillStyleBottom
            // 
            this.comboBox_FillStyleBottom.FormattingEnabled = true;
            this.comboBox_FillStyleBottom.Items.AddRange(new object[] {
            "Solid",
            "Bdiagonal",
            "Cross",
            "Diag Cross",
            "FDiagonal",
            "Horizontal",
            "Vertical",
            "Hollow"});
            this.comboBox_FillStyleBottom.Location = new System.Drawing.Point(126, 150);
            this.comboBox_FillStyleBottom.Name = "comboBox_FillStyleBottom";
            this.comboBox_FillStyleBottom.Size = new System.Drawing.Size(92, 20);
            this.comboBox_FillStyleBottom.TabIndex = 47;
            this.comboBox_FillStyleBottom.SelectedIndexChanged += new System.EventHandler(this.comboBox_FillStyleBottom_SelectedIndexChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(8, 129);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(114, 12);
            this.label18.TabIndex = 43;
            this.label18.Text = "▶ BottomFillColor :";
            // 
            // comboBox_FillStyleTop
            // 
            this.comboBox_FillStyleTop.FormattingEnabled = true;
            this.comboBox_FillStyleTop.Items.AddRange(new object[] {
            "Solid",
            "Bdiagonal",
            "Cross",
            "Diag Cross",
            "FDiagonal",
            "Horizontal",
            "Vertical",
            "Hollow"});
            this.comboBox_FillStyleTop.Location = new System.Drawing.Point(126, 96);
            this.comboBox_FillStyleTop.Name = "comboBox_FillStyleTop";
            this.comboBox_FillStyleTop.Size = new System.Drawing.Size(92, 20);
            this.comboBox_FillStyleTop.TabIndex = 46;
            this.comboBox_FillStyleTop.SelectedIndexChanged += new System.EventHandler(this.comboBox_FillStyleTop_SelectedIndexChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(8, 154);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(112, 12);
            this.label19.TabIndex = 46;
            this.label19.Text = "▶ BottomFillStyle :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(8, 75);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(97, 12);
            this.label15.TabIndex = 42;
            this.label15.Text = "▶ TopFillColor :";
            // 
            // textBox_FillColorBottom
            // 
            this.textBox_FillColorBottom.Location = new System.Drawing.Point(128, 125);
            this.textBox_FillColorBottom.Name = "textBox_FillColorBottom";
            this.textBox_FillColorBottom.ReadOnly = true;
            this.textBox_FillColorBottom.Size = new System.Drawing.Size(63, 21);
            this.textBox_FillColorBottom.TabIndex = 44;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 100);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(95, 12);
            this.label17.TabIndex = 45;
            this.label17.Text = "▶ TopFillStyle :";
            // 
            // Button_ColorDlgFillBottom
            // 
            this.Button_ColorDlgFillBottom.Location = new System.Drawing.Point(193, 126);
            this.Button_ColorDlgFillBottom.Name = "Button_ColorDlgFillBottom";
            this.Button_ColorDlgFillBottom.Size = new System.Drawing.Size(27, 19);
            this.Button_ColorDlgFillBottom.TabIndex = 45;
            this.Button_ColorDlgFillBottom.Text = "...";
            this.Button_ColorDlgFillBottom.UseVisualStyleBackColor = true;
            this.Button_ColorDlgFillBottom.Click += new System.EventHandler(this.button_FillColorDlgBottom_Click);
            // 
            // textBox_FillColorTop
            // 
            this.textBox_FillColorTop.Location = new System.Drawing.Point(128, 71);
            this.textBox_FillColorTop.Name = "textBox_FillColorTop";
            this.textBox_FillColorTop.ReadOnly = true;
            this.textBox_FillColorTop.Size = new System.Drawing.Size(63, 21);
            this.textBox_FillColorTop.TabIndex = 43;
            // 
            // Button_ColorDlgFillTop
            // 
            this.Button_ColorDlgFillTop.Location = new System.Drawing.Point(193, 72);
            this.Button_ColorDlgFillTop.Name = "Button_ColorDlgFillTop";
            this.Button_ColorDlgFillTop.Size = new System.Drawing.Size(27, 19);
            this.Button_ColorDlgFillTop.TabIndex = 44;
            this.Button_ColorDlgFillTop.Text = "...";
            this.Button_ColorDlgFillTop.UseVisualStyleBackColor = true;
            this.Button_ColorDlgFillTop.Click += new System.EventHandler(this.button_FillColorDlgTop_Click);
            // 
            // CylinderProperty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(500, 443);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.comboBox_Style);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.comboBox_Hide);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.groupBox_Position);
            this.Controls.Add(this.comboBox_TextAlign);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Button_TextColorDlg);
            this.Controls.Add(this.TextBox_TextColor);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.checkBox_ShowName);
            this.Controls.Add(this.textBox_LineWidth);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.ButtonApply);
            this.Controls.Add(this.Button_ColorDlg);
            this.Controls.Add(this.TextBox_LineColor);
            this.Controls.Add(this.TextBox_Name);
            this.Controls.Add(this.TextBox_ID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CylinderProperty";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Cylinder Property";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.CylinderProperty_Load);
            this.groupBox_Position.ResumeLayout(false);
            this.groupBox_Position.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TextBox_ID;
        private System.Windows.Forms.TextBox TextBox_Name;
        private System.Windows.Forms.TextBox TextBox_LineColor;
        private System.Windows.Forms.Button Button_ColorDlg;
        private System.Windows.Forms.Button ButtonApply;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.TextBox textBox_LineWidth;
        private System.Windows.Forms.CheckBox checkBox_ShowName;
        private System.Windows.Forms.Button Button_TextColorDlg;
        private System.Windows.Forms.TextBox TextBox_TextColor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox_TextAlign;
        private System.Windows.Forms.Button Button_ColorDlgFill;
        private System.Windows.Forms.TextBox textBox_FillColor;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox_HgtMax;
        private System.Windows.Forms.GroupBox groupBox_Position;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox_HgtMin;
        private System.Windows.Forms.TextBox textBox_Lat;
        private System.Windows.Forms.TextBox textBox_Long;
        private System.Windows.Forms.ComboBox comboBox_Hide;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox_Radius;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox_Style;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox_FillStyle;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox comboBox_FillStyleBottom;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.ComboBox comboBox_FillStyleTop;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox_FillColorBottom;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button Button_ColorDlgFillBottom;
        private System.Windows.Forms.TextBox textBox_FillColorTop;
        private System.Windows.Forms.Button Button_ColorDlgFillTop;
    }
}