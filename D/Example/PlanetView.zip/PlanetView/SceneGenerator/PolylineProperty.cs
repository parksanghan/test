﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NGR;
using System.Collections;
using Pixoneer.NXDL;

namespace SceneGenerator
{
    public partial class PolylineProperty : Form
    {
        private int m_nID = -1;
        private double m_dLineWidth = 0.0;
        private bool m_bShowName;
        private string m_strName;
        private Color m_Color;
        private Color m_TextColor;
        private Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType m_type;
        private ArrayList m_PositionArray = new ArrayList();
      
        private eTextAlign m_TextAlign;
        private bool m_Hide;

        public bool ObjectHide
        {
            get { return m_Hide; }
            set { m_Hide = value; }
        }
        public System.Collections.ArrayList PositionArray
        {
            get { return m_PositionArray; }
            set { m_PositionArray = value; }
        }

        public Pixoneer.NXDL.NGR.eTextAlign TextAlign
        {
            get { return m_TextAlign; }
            set { m_TextAlign = value; }
        }
        public int ID
        {
            get { return m_nID; }
            set { m_nID = value; }
        }
        public string ObjectName
        {
            get { return m_strName; }
            set { m_strName = value; }
        }
        public System.Drawing.Color Color
        {
            get { return m_Color; }
            set { m_Color = value; }
        }
        public System.Drawing.Color TextColor
        {
            get { return m_TextColor; }
            set { m_TextColor = value; }
        }
        public Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType Type
        {
            get { return m_type; }
            set { m_type = value; }
        }
        public double LineWidth
        {
            get { return m_dLineWidth; }
            set { m_dLineWidth = value; }
        }
        public bool ShowName
        {
            get { return m_bShowName; }
            set { m_bShowName = value; }
        }
        public PolylineProperty()
        {
            InitializeComponent();
        }

        private void PolylineProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = string.Format("{0}", m_nID);
            TextBox_Name.Text = m_strName;
            textBox_PointSize.Text = string.Format("{0}", m_dLineWidth);
            TextBox_PointColor.BackColor = m_Color;
            TextBox_TextColor.BackColor = m_TextColor;
            switch(m_type)
            {
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid:
                    comboBox_Style.SelectedIndex = 0; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dash:
                    comboBox_Style.SelectedIndex = 1; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dot:
                    comboBox_Style.SelectedIndex = 2; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDot:
                    comboBox_Style.SelectedIndex = 3; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDotDot:
                    comboBox_Style.SelectedIndex = 4; break;
            }
            comboBox_TextAlign.SelectedIndex = (int)m_TextAlign;
            checkBox_ShowName.Checked = ShowName;
            switch (m_Hide)
            {
                case true:
                    comboBox_Hide.SelectedIndex = 0;
                    break;
                case false:
                    comboBox_Hide.SelectedIndex = 1;
                    break;
            }
            foreach (XVertex3d pos in m_PositionArray)
            {
                string[] row = { pos.x.ToString(), pos.y.ToString(), pos.z.ToString() };
                dataGridViewPosition.Rows.Add(row);
            }
            m_PositionArray.Clear();
        }

        private void Button_ColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_Color;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_Color = dlg.Color;
                TextBox_PointColor.BackColor = m_Color;
            }
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            if (dataGridViewPosition.RowCount < 3)
            {
                DialogResult = System.Windows.Forms.DialogResult.Cancel;
                return;
            }
            m_strName = TextBox_Name.Text;
            m_dLineWidth = double.Parse(textBox_PointSize.Text);
            m_PositionArray.Clear();
            for (int i = 0; i < dataGridViewPosition.RowCount-1; i++  )
            {
                XVertex3d pos = new XVertex3d();
                pos.x = Double.Parse(dataGridViewPosition.Rows[i].Cells[0].Value.ToString());
                pos.y = Double.Parse(dataGridViewPosition.Rows[i].Cells[1].Value.ToString());
                pos.z = Double.Parse(dataGridViewPosition.Rows[i].Cells[2].Value.ToString());
                m_PositionArray.Add(pos);
            }
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
           
        }

        private void comboBox_Style_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Style.SelectedIndex)
            {
                case 0:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid;
                    break;
                case 1:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dash;
                    break;
                case 2:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dot;
                    break;
                case 3:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDot;
                    break;
                case 4:
                    m_type = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDotDot;
                    break;
            }
        }

        private void checkBox_ShowName_CheckedChanged(object sender, EventArgs e)
        {
            ShowName = checkBox_ShowName.Checked;
        }

        private void Button_TextColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_Color;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_TextColor = dlg.Color;
                TextBox_TextColor.BackColor = m_TextColor;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlign = (eTextAlign)comboBox_TextAlign.SelectedIndex;
        }

        private void comboBox_Hide_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Hide.SelectedIndex)
            {
                case 0:
                    m_Hide = true;
                    break;
                case 1:
                    m_Hide = false;
                    break;
            }
        }
    }
}
