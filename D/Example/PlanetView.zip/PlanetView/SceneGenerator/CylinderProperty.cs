﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NGR;
using Pixoneer.NXDL.NSCENE;

namespace SceneGenerator
{
    public partial class CylinderProperty : Form
    {
        private int m_nID = -1;
        private double m_dLineWidth = 0.0;
        private double m_dWidth;
        private bool m_bShowName;
        private bool m_Hide;

        public bool ObjectHide
        {
            get { return m_Hide; }
            set { m_Hide = value; }
        }
 
        private string m_strName;
        private Color m_LineColor;
        private Color m_FillColorSide, m_FillColorTop, m_FillColorBottom;
        private Color m_TextColor;
        private XscLinePattern.eLinePatternType m_styleLine;
        private XscFillPattern.eFillPatternType m_styleFill, m_styleFillTop, m_styleFillBottom;
        private eTextAlign m_TextAlign;

        public eTextAlign TextAlign
        {
            get { return m_TextAlign; }
            set { m_TextAlign = value; }
        }
        private double m_dLatDegree = 0.0;
        private double m_dLonDegree = 0.0;
        private double m_dHeightMin = 0.0;
        private double m_dHeightMax = 0.0;
        private double m_dRadius = 0.0;

        public double HeightMinMeter
        {
            get { return m_dHeightMin; }
            set { m_dHeightMin = value; }
        }
        public double HeightMaxMeter
        {
            get { return m_dHeightMax; }
            set { m_dHeightMax = value; }
        }
        public double RadiusMeter
        {
            get { return m_dRadius; }
            set { m_dRadius = value; }
        }
        public double LonDegree
        {
            get { return m_dLonDegree; }
            set { m_dLonDegree = value; }
        }
        public double LatDegree
        {
            get { return m_dLatDegree; }
            set { m_dLatDegree = value; }
        }

        public int ID
        {
            get { return m_nID; }
            set { m_nID = value; }
        }
        public string ObjectName
        {
            get { return m_strName; }
            set { m_strName = value; }
        }
        public System.Drawing.Color FillColorSide
        {
            get { return m_FillColorSide; }
            set { m_FillColorSide = value; }
        }
        public System.Drawing.Color FillColorTop
        {
            get { return m_FillColorTop; }
            set { m_FillColorTop = value; }
        }
        public System.Drawing.Color FillColorBottom
        {
            get { return m_FillColorBottom; }
            set { m_FillColorBottom = value; }
        }
        public System.Drawing.Color LineColor
        {
            get { return m_LineColor; }
            set { m_LineColor = value; }
        }
        public System.Drawing.Color TextColor
        {
            get { return m_TextColor; }
            set { m_TextColor = value; }
        }
        public XscLinePattern.eLinePatternType StyleLine
        {
            get { return m_styleLine; }
            set { m_styleLine = value; }
        }
        public XscFillPattern.eFillPatternType StyleFillSide
        {
            get { return m_styleFill; }
            set { m_styleFill= value; }
        }
        public XscFillPattern.eFillPatternType StyleFillTop
        {
            get { return m_styleFillTop; }
            set { m_styleFillTop = value; }
        }
        public XscFillPattern.eFillPatternType StyleFillBottom
        {
            get { return m_styleFillBottom; }
            set { m_styleFillBottom = value; }
        }
        public double LineWidth
        {
            get { return m_dLineWidth; }
            set { m_dLineWidth = value; }
        }
        public bool ShowName
        {
            get { return m_bShowName; }
            set { m_bShowName = value; }
        }
        public CylinderProperty()
        {
            InitializeComponent();
        }

        private void CylinderProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = string.Format("{0}", m_nID);
            TextBox_Name.Text = m_strName;
            textBox_LineWidth.Text = string.Format("{0}", m_dLineWidth);
            TextBox_LineColor.BackColor = Color.FromArgb(m_LineColor.R, m_LineColor.G, m_LineColor.B);
            textBox_FillColor.BackColor = Color.FromArgb(m_FillColorSide.R, m_FillColorSide.G, m_FillColorSide.B);
            TextBox_TextColor.BackColor = Color.FromArgb(m_TextColor.R, m_TextColor.G, m_TextColor.B);
            textBox_FillColorTop.BackColor = Color.FromArgb(m_FillColorTop.R, m_FillColorTop.G, m_FillColorTop.B);
            textBox_FillColorBottom.BackColor = Color.FromArgb(m_FillColorBottom.R, m_FillColorBottom.G, m_FillColorBottom.B);
            textBox_HgtMax.Text = string.Format("{0}", m_dWidth);
           
            comboBox_TextAlign.SelectedIndex = (int)m_TextAlign;
            checkBox_ShowName.Checked = ShowName;
            textBox_Long.Text = string.Format("{0}", m_dLonDegree);
            textBox_Lat.Text = string.Format("{0}", m_dLatDegree);
            textBox_HgtMin.Text = string.Format("{0}", m_dHeightMin);
            textBox_HgtMax.Text = string.Format("{0}", m_dHeightMax);
            textBox_Radius.Text = string.Format("{0}", m_dRadius);

            switch (m_styleLine)
            {
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid:
                    comboBox_Style.SelectedIndex = 0; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dash:
                    comboBox_Style.SelectedIndex = 1; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dot:
                    comboBox_Style.SelectedIndex = 2; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDot:
                    comboBox_Style.SelectedIndex = 3; break;
                case Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDotDot:
                    comboBox_Style.SelectedIndex = 4; break;
            }

            switch (m_styleFill)
            {
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid:
                    comboBox_FillStyle.SelectedIndex = 0; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.BDiagonal:
                    comboBox_FillStyle.SelectedIndex = 1; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross:
                    comboBox_FillStyle.SelectedIndex = 2; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.DiagCross:
                    comboBox_FillStyle.SelectedIndex = 3; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.FDiagonal:
                    comboBox_FillStyle.SelectedIndex = 4; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Horizontal:
                    comboBox_FillStyle.SelectedIndex = 5; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Vertical:
                    comboBox_FillStyle.SelectedIndex = 6; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Hollow:
                    comboBox_FillStyle.SelectedIndex = 7; break;
            }

            switch (m_styleFillTop)
            {
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid:
                    comboBox_FillStyleTop.SelectedIndex = 0; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.BDiagonal:
                    comboBox_FillStyleTop.SelectedIndex = 1; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross:
                    comboBox_FillStyleTop.SelectedIndex = 2; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.DiagCross:
                    comboBox_FillStyleTop.SelectedIndex = 3; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.FDiagonal:
                    comboBox_FillStyleTop.SelectedIndex = 4; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Horizontal:
                    comboBox_FillStyleTop.SelectedIndex = 5; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Vertical:
                    comboBox_FillStyleTop.SelectedIndex = 6; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Hollow:
                    comboBox_FillStyleTop.SelectedIndex = 7; break;
            }

            switch (m_styleFillBottom)
            {
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid:
                    comboBox_FillStyleBottom.SelectedIndex = 0; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.BDiagonal:
                    comboBox_FillStyleBottom.SelectedIndex = 1; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross:
                    comboBox_FillStyleBottom.SelectedIndex = 2; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.DiagCross:
                    comboBox_FillStyleBottom.SelectedIndex = 3; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.FDiagonal:
                    comboBox_FillStyleBottom.SelectedIndex = 4; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Horizontal:
                    comboBox_FillStyleBottom.SelectedIndex = 5; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Vertical:
                    comboBox_FillStyleBottom.SelectedIndex = 6; break;
                case Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Hollow:
                    comboBox_FillStyleBottom.SelectedIndex = 7; break;
            }

            switch (m_Hide)
            {
                case true:
                    comboBox_Hide.SelectedIndex = 0;
                    break;
                case false:
                    comboBox_Hide.SelectedIndex = 1;
                    break;
            }
        }

        private void Button_ColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_LineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_LineColor = Color.FromArgb(m_LineColor.A, dlg.Color);
                TextBox_LineColor.BackColor = dlg.Color;
            }
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            m_strName = TextBox_Name.Text;
            m_dLineWidth = double.Parse(textBox_LineWidth.Text);
            m_dWidth = double.Parse(textBox_HgtMax.Text);
            m_dLonDegree = double.Parse(textBox_Long.Text);
            m_dLatDegree = double.Parse(textBox_Lat.Text);
            m_dHeightMin = double.Parse(textBox_HgtMin.Text);
            m_dHeightMax = double.Parse(textBox_HgtMax.Text);
            m_dRadius = double.Parse(textBox_Radius.Text);
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
           
        }

        private void checkBox_ShowName_CheckedChanged(object sender, EventArgs e)
        {
            ShowName = checkBox_ShowName.Checked;
        }

        private void Button_TextColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_LineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_TextColor = Color.FromArgb(m_TextColor.A, dlg.Color);
                TextBox_TextColor.BackColor = dlg.Color;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlign = (eTextAlign)comboBox_TextAlign.SelectedIndex;
        }

        private void button_FillColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_FillColorSide;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                byte alpha = m_FillColorSide.A;
                m_FillColorSide = dlg.Color;
                textBox_FillColor.BackColor = m_FillColorSide;
                m_FillColorSide = Color.FromArgb(alpha, dlg.Color.R, dlg.Color.G, dlg.Color.B);
            }
        }

        private void button_FillColorDlgTop_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_FillColorTop;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                byte alpha = m_FillColorTop.A;
                m_FillColorTop = dlg.Color;
                textBox_FillColorTop.BackColor = m_FillColorTop;
                m_FillColorTop = Color.FromArgb(alpha, dlg.Color.R, dlg.Color.G, dlg.Color.B);
            }
        }

        private void button_FillColorDlgBottom_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_FillColorBottom;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                byte alpha = m_FillColorBottom.A;
                m_FillColorBottom = dlg.Color;
                textBox_FillColorBottom.BackColor = m_FillColorBottom;
                m_FillColorBottom = Color.FromArgb(alpha, dlg.Color.R, dlg.Color.G, dlg.Color.B);
            }
        }

        private void comboBox_Hide_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Hide.SelectedIndex)
            {
                case 0:
                    m_Hide = true;
                    break;
                case 1:
                    m_Hide = false;
                    break;
            }
        }

        private void comboBox_FillStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_FillStyle.SelectedIndex)
            {
                case 0:
                    m_styleFill = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid;
                    break;
                case 1:
                    m_styleFill = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.BDiagonal;
                    break;
                case 2:
                    m_styleFill = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross;
                    break;
                case 3:
                    m_styleFill = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.DiagCross;
                    break;
                case 4:
                    m_styleFill = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.FDiagonal;
                    break;
                case 5:
                    m_styleFill = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Horizontal;
                    break;
                case 6:
                    m_styleFill = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Vertical;
                    break;
                case 7:
                    m_styleFill = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Hollow;
                    break;
                default:
                    m_styleFill = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid;
                    break;
            }
        }

        private void comboBox_FillStyleTop_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_FillStyleTop.SelectedIndex)
            {
                case 0:
                    m_styleFillTop = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid;
                    break;
                case 1:
                    m_styleFillTop = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.BDiagonal;
                    break;
                case 2:
                    m_styleFillTop = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross;
                    break;
                case 3:
                    m_styleFillTop = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.DiagCross;
                    break;
                case 4:
                    m_styleFillTop = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.FDiagonal;
                    break;
                case 5:
                    m_styleFillTop = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Horizontal;
                    break;
                case 6:
                    m_styleFillTop = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Vertical;
                    break;
                case 7:
                    m_styleFillTop = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Hollow;
                    break;
                default:
                    m_styleFillTop = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid;
                    break;
            }
        }

        private void comboBox_FillStyleBottom_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_FillStyleBottom.SelectedIndex)
            {
                case 0:
                    m_styleFillBottom = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid;
                    break;
                case 1:
                    m_styleFillBottom = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.BDiagonal;
                    break;
                case 2:
                    m_styleFillBottom = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Cross;
                    break;
                case 3:
                    m_styleFillBottom = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.DiagCross;
                    break;
                case 4:
                    m_styleFillBottom = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.FDiagonal;
                    break;
                case 5:
                    m_styleFillBottom = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Horizontal;
                    break;
                case 6:
                    m_styleFillBottom = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Vertical;
                    break;
                case 7:
                    m_styleFillBottom = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Hollow;
                    break;
                default:
                    m_styleFillBottom = Pixoneer.NXDL.NSCENE.XscFillPattern.eFillPatternType.Solid;
                    break;
            }
        }
        private void comboBox_Style_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Style.SelectedIndex)
            {
                case 0:
                    m_styleLine = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid;
                    break;
                case 1:
                    m_styleLine = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dash;
                    break;
                case 2:
                    m_styleLine = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Dot;
                    break;
                case 3:
                    m_styleLine = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDot;
                    break;
                case 4:
                    m_styleLine = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.DashDotDot;
                    break;
                default:
                    m_styleLine = Pixoneer.NXDL.NSCENE.XscLinePattern.eLinePatternType.Solid;
                    break;
            }
        }


    }
}
