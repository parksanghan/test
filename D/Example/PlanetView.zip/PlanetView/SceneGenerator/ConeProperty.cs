﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NGR;

namespace SceneGenerator
{
    public partial class ConeProperty : Form
    {
        private int m_nID = -1;
        private double m_dLineWidth = 0.0;
        private double m_dRadius;
        private bool m_bShowName;
        private bool m_bShowSection;
        private double m_dYaw = 0.0;
        private double m_dDistance = 0.0;
        private bool m_Hide;

        public bool ObjectHide
        {
            get { return m_Hide; }
            set { m_Hide = value; }
        }
        public double Distance
        {
            get { return m_dDistance; }
            set { m_dDistance = value; }
        }
        public double Yaw
        {
            get { return m_dYaw; }
            set { m_dYaw = value; }
        }
        private double m_dPitch = 0.0;

        public double Pitch
        {
            get { return m_dPitch; }
            set { m_dPitch = value; }
        }
        private double m_dRoll = 0.0;

        public double Roll
        {
            get { return m_dRoll; }
            set { m_dRoll = value; }
        }

        public bool ShowSection
        {
            get { return m_bShowSection; }
            set { m_bShowSection = value; }
        }
        private bool m_bShowSectionLine;

        public bool ShowSectionLine
        {
            get { return m_bShowSectionLine; }
            set { m_bShowSectionLine = value; }
        }
        private bool m_bShowCilrcle;

        public bool ShowCilrcle
        {
            get { return m_bShowCilrcle; }
            set { m_bShowCilrcle = value; }
        }
        private string m_strName;
        private Color m_LineColor;
        private Color m_FillColor;
        private Color m_TextColor;
        private eTextAlign m_TextAlign;

        public eTextAlign TextAlign
        {
            get { return m_TextAlign; }
            set { m_TextAlign = value; }
        }
        private double m_dLatDegree = 0.0;
        private double m_dLonDegree = 0.0;
        private double m_dHeight = 0.0;

        public double HeightMeter
        {
            get { return m_dHeight; }
            set { m_dHeight = value; }
        }
        public double LonDegree
        {
            get { return m_dLonDegree; }
            set { m_dLonDegree = value; }
        }
        public double LatDegree
        {
            get { return m_dLatDegree; }
            set { m_dLatDegree = value; }
        }

        public double Radius
        {
            get { return m_dRadius; }
            set { m_dRadius = value; }
        }
        public System.Drawing.Color FillColor
        {
            get { return m_FillColor; }
            set { m_FillColor = value; }
        }
      
        public int ID
        {
            get { return m_nID; }
            set { m_nID = value; }
        }
        public string ObjectName
        {
            get { return m_strName; }
            set { m_strName = value; }
        }
        public System.Drawing.Color LineColor
        {
            get { return m_LineColor; }
            set { m_LineColor = value; }
        }
        public System.Drawing.Color TextColor
        {
            get { return m_TextColor; }
            set { m_TextColor = value; }
        }
       
        public double LineWidth
        {
            get { return m_dLineWidth; }
            set { m_dLineWidth = value; }
        }
        public bool ShowName
        {
            get { return m_bShowName; }
            set { m_bShowName = value; }
        }
        public ConeProperty()
        {
            InitializeComponent();
        }

        private void ConeProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = string.Format("{0}", m_nID);
            TextBox_Name.Text = m_strName;
            textBox_PointSize.Text = string.Format("{0}", m_dLineWidth);
            TextBox_PointColor.BackColor = m_LineColor;
            TextBox_TextColor.BackColor = m_TextColor;
            textBox_Radius.Text = string.Format("{0}", m_dRadius);
            textBox_FillColor.BackColor = Color.FromArgb(m_FillColor.R, m_FillColor.G, m_FillColor.B);
           
            comboBox_TextAlign.SelectedIndex = (int)m_TextAlign;
            checkBox_ShowName.Checked = ShowName;
            checkBox_ShowCircle.Checked = ShowCilrcle;
            checkBox_ShowSection.Checked = ShowSection;
            checkBox_ShowSectionLine.Checked = ShowSectionLine;
            textBox_Long.Text = string.Format("{0}", m_dLonDegree);
            textBox_Lat.Text = string.Format("{0}", m_dLatDegree);
            textBox_Hgt.Text = string.Format("{0}", m_dHeight);

            textBox_Yaw.Text = string.Format("{0}", m_dYaw);
            textBox_Pitch.Text = string.Format("{0}", m_dPitch);
            textBox_Roll.Text = string.Format("{0}", m_dRoll);
            textBox_Height.Text = string.Format("{0}", m_dDistance);
            switch (m_Hide)
            {
                case true:
                    comboBox_Hide.SelectedIndex = 0;
                    break;
                case false:
                    comboBox_Hide.SelectedIndex = 1;
                    break;
            }
        }

        private void Button_ColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_LineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_LineColor = dlg.Color;
                TextBox_PointColor.BackColor = m_LineColor;
            }
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            m_strName = TextBox_Name.Text;
            m_dLineWidth = double.Parse(textBox_PointSize.Text);
            m_dRadius = double.Parse(textBox_Radius.Text);
            m_dLonDegree = double.Parse(textBox_Long.Text);
            m_dLatDegree = double.Parse(textBox_Lat.Text);
            m_dHeight = double.Parse(textBox_Hgt.Text);

            m_dDistance = double.Parse(textBox_Height.Text);
            m_dYaw = double.Parse(textBox_Yaw.Text);
            m_dPitch = double.Parse(textBox_Pitch.Text);
            m_dRoll = double.Parse(textBox_Roll.Text);
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
           
        }

        private void checkBox_ShowName_CheckedChanged(object sender, EventArgs e)
        {
            ShowName = checkBox_ShowName.Checked;
        }

        private void Button_TextColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_LineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_TextColor = dlg.Color;
                TextBox_TextColor.BackColor = m_TextColor;
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlign = (eTextAlign)comboBox_TextAlign.SelectedIndex;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = m_LineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                byte alpha = m_FillColor.A;
                m_FillColor = dlg.Color;
                textBox_FillColor.BackColor = m_FillColor;
                m_FillColor = Color.FromArgb(alpha, dlg.Color.R, dlg.Color.G, dlg.Color.B);
            }
        }

        private void checkBox_ShowSection_CheckedChanged(object sender, EventArgs e)
        {
            ShowSection = checkBox_ShowSection.Checked;
        }

        private void checkBox_ShowCircle_CheckedChanged(object sender, EventArgs e)
        {
            ShowCilrcle = checkBox_ShowCircle.Checked;
        }

        private void checkBox_ShowSectionLine_CheckedChanged(object sender, EventArgs e)
        {
            ShowSectionLine = checkBox_ShowSectionLine.Checked;
        }

        private void comboBox_Hide_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Hide.SelectedIndex)
            {
                case 0:
                    m_Hide = true;
                    break;
                case 1:
                    m_Hide = false;
                    break;
            }
        }
    }
}
