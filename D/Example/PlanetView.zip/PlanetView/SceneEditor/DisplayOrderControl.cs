﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NSCENE;
using System.Collections;

namespace SceneEditor
{
    public partial class MainForm : Form
    {
        private void UpdateListView()
        {
            
            XScene  sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            listView_DisplayOrder.Items.Clear();
            ArrayList arr_default = new ArrayList();
            ArrayList arr_Sequence = new ArrayList();
            ArrayList arr_User = new ArrayList();

            sc.GetDefaultDisplayOrder(ref arr_default);
            sc.GetSequenceDisplayOrder(ref arr_Sequence);
            sc.GetUserDisplayOrder(ref arr_User);
            listView_DisplayOrder.BeginUpdate();
            int nID = -1;
            for (int i = 0; i < arr_default.Count; i++)
            {
                nID = (int)arr_default[i];
                listView_DisplayOrder.Items.Add(nID.ToString());
            }
            for (int i = 0; i < arr_Sequence.Count; i++)
            {
                nID = (int)arr_Sequence[i];
                listView_DisplayOrder.Items[i].SubItems.Add(nID.ToString());
            }
            for (int i = 0; i < arr_User.Count; i++)
            {
                nID = (int)arr_User[i];
                listView_DisplayOrder.Items[i].SubItems.Add(nID.ToString());
            }
            listView_DisplayOrder.EndUpdate();

        }

        private void listView_DisplayOrder_orderfront(string selectedID)    // 맨 앞으로
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            ArrayList arr_User = new ArrayList();
            sc.GetUserDisplayOrder(ref arr_User);
            if (arr_User.Count <= 1 ) return;
            ArrayList arr_Modify = new ArrayList();

            int nID = -1;
            arr_Modify.Add(int.Parse(selectedID));
            for (int i = 0; i < arr_User.Count; i++)
            {
                nID = (int)arr_User[i];
                if (nID == int.Parse(selectedID))
                {
                    continue;
                }
                arr_Modify.Add(nID);
            }
            sc.SetUserDisplayOrder(arr_Modify);
            UpdateListView();
            nxPlanetView2D.RefreshScreen();
            
        }
        private void listView_DisplayOrder_orderFoward(string selectedID)   // 한단계 앞으로
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            ArrayList arr_User = new ArrayList();
            sc.GetUserDisplayOrder(ref arr_User);
            if (arr_User.Count <= 1) return;
            ArrayList arr_Modify = new ArrayList();

            int nID = -1;
            for (int i = 0; i < arr_User.Count; i++)
            {
                nID = (int)arr_User[i];
                if (nID == int.Parse(selectedID))
                {
                    if( i == 0 )
                        arr_Modify.Add(nID);
                    else
                        arr_Modify.Insert(i - 1, nID);
                    continue;
                }
                arr_Modify.Add(nID);
            }
            sc.SetUserDisplayOrder(arr_Modify);
            UpdateListView();
            nxPlanetView2D.RefreshScreen();
        }
        private void listView_DisplayOrder_orderback(string selectedID)     // 한단계 뒤로
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            ArrayList arr_User = new ArrayList();
            sc.GetUserDisplayOrder(ref arr_User);
            if (arr_User.Count <= 1) return;
            ArrayList arr_Modify = new ArrayList();
            bool bFind = false;
            int nID = -1;
            for (int i = 0; i < arr_User.Count; i++)
            {
                nID = (int)arr_User[i];
                if (nID == int.Parse(selectedID))
                {
                    bFind = true;
                    if (i == arr_User.Count - 1)
                    {
                        arr_Modify.Add(nID);
                        break;
                    }
                    continue;
                }
                arr_Modify.Add(nID);
                if (bFind == true)
                {
                    arr_Modify.Add(int.Parse(selectedID));
                    bFind = false;
                }
            }
            sc.SetUserDisplayOrder(arr_Modify);
            UpdateListView();
            nxPlanetView2D.RefreshScreen();
        }
        private void listView_DisplayOrder_orderbackward(string selectedID) // 맨 뒤로
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            ArrayList arr_User = new ArrayList();
            sc.GetUserDisplayOrder(ref arr_User);
            if (arr_User.Count <= 1) return;
            ArrayList arr_Modify = new ArrayList();
            int nID = -1;
            for (int i = 0; i < arr_User.Count; i++)
            {
                nID = (int)arr_User[i];
                if (nID == int.Parse(selectedID))
                {
                    continue;
                }
                arr_Modify.Add(nID);
            }
            arr_Modify.Add(int.Parse(selectedID));
            sc.SetUserDisplayOrder(arr_Modify);
            UpdateListView();
            nxPlanetView2D.RefreshScreen();
        }

        private void listView_DisplayOrder_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                ListViewItem nodeitem = listView_DisplayOrder.GetItemAt(e.X, e.Y);
                if (nodeitem == null) return;
                string selectedNickname = nodeitem.SubItems[2].Text;

                if (selectedNickname == "") return;

                ContextMenu m = new ContextMenu();

                MenuItem orderfront = new MenuItem();
                orderfront.Text = "맨 앞으로";
                orderfront.Click += (senders, es) =>
                {
                    listView_DisplayOrder_orderfront(selectedNickname);
                };

                MenuItem orderForward = new MenuItem();
                orderForward.Text = "한단계 앞으로";
                orderForward.Click += (senders, es) =>
                {
                    listView_DisplayOrder_orderFoward(selectedNickname);
                };

                MenuItem orderBack = new MenuItem();
                orderBack.Text = "한단계 뒤로";
                orderBack.Click += (senders, es) =>
                {
                    listView_DisplayOrder_orderback(selectedNickname);
                };

                MenuItem orderbackward = new MenuItem();
                orderbackward.Text = "맨 뒤로";
                orderbackward.Click += (senders, es) =>
                {
                    listView_DisplayOrder_orderbackward(selectedNickname);
                };

                m.MenuItems.Add(orderfront);
                m.MenuItems.Add(orderForward);
                m.MenuItems.Add(orderBack);
                m.MenuItems.Add(orderbackward);
                m.Show(listView_DisplayOrder, new Point(e.X, e.Y));
            }

        }

        
        private void radioButton_OrderDefault_CheckedChanged(object sender, EventArgs e)
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            sc.DisplayOrder = XScene.eDisplayOrder.OrderNone;
            nxPlanetView2D.RefreshScreen();
        }

        private void radioButton_OrderSequence_CheckedChanged(object sender, EventArgs e)
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            sc.DisplayOrder = XScene.eDisplayOrder.OrderByAddSequence;
            nxPlanetView2D.RefreshScreen();
        }

        private void radioButton_OrderUser_CheckedChanged(object sender, EventArgs e)
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            sc.DisplayOrder = XScene.eDisplayOrder.OrderByUserSequence;
            nxPlanetView2D.RefreshScreen();
        }

        

       
    }
}
