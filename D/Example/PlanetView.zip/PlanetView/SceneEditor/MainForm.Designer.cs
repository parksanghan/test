﻿using Pixoneer;
using Pixoneer.NXDL;


namespace SceneEditor
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            Pixoneer.NXDL.XAngle xAngle1 = new Pixoneer.NXDL.XAngle();
            Pixoneer.NXDL.XAngle xAngle2 = new Pixoneer.NXDL.XAngle();
            this.MainToolbar = new System.Windows.Forms.ToolStrip();
            this.AddLabel = new System.Windows.Forms.ToolStripLabel();
            this.AddPointButton = new System.Windows.Forms.ToolStripButton();
            this.AddPolyLine = new System.Windows.Forms.ToolStripButton();
            this.AddPolygonButton = new System.Windows.Forms.ToolStripButton();
            this.AddCircleButton = new System.Windows.Forms.ToolStripButton();
            this.AddImageButton = new System.Windows.Forms.ToolStripButton();
            this.AddTextButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.Button_SaveScene = new System.Windows.Forms.ToolStripButton();
            this.Button_LoadScene = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonLeft = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonRight = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonDown = new System.Windows.Forms.ToolStripButton();
            this.ControlPanel = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.ObjectTree = new System.Windows.Forms.TreeView();
            this.listView_DisplayOrder = new System.Windows.Forms.ListView();
            this.columnHeader_DisplayDefault = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_DisplaySequence = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_DisplayUser = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox_DisplayOrder = new System.Windows.Forms.GroupBox();
            this.radioButton_OrderUser = new System.Windows.Forms.RadioButton();
            this.radioButton_OrderSequence = new System.Windows.Forms.RadioButton();
            this.radioButton_OrderDefault = new System.Windows.Forms.RadioButton();
            this.ViewSplitContainer = new System.Windows.Forms.SplitContainer();
            this.nxPlanetView2D = new Pixoneer.NXDL.NXPlanet.NXPlanetView();
            this.nxPlanetView3D = new Pixoneer.NXDL.NXPlanet.NXPlanetView();
            this.nxPlanetLayer2D = new Pixoneer.NXDL.NXPlanet.NXPlanetLayer();
            this.nxPlanetLayerSceneEditor = new Pixoneer.NXDL.NSCENE.NXPlanetLayerSceneEditor();
            this.itemContextMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.MenuProperty = new System.Windows.Forms.ToolStripMenuItem();
            this.nxPlanetLayerSceneDisplay3D = new Pixoneer.NXDL.NSCENE.NXPlanetLayerSceneDisplay();
            this.MainToolbar.SuspendLayout();
            this.ControlPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.groupBox_DisplayOrder.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ViewSplitContainer)).BeginInit();
            this.ViewSplitContainer.Panel1.SuspendLayout();
            this.ViewSplitContainer.Panel2.SuspendLayout();
            this.ViewSplitContainer.SuspendLayout();
            this.itemContextMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainToolbar
            // 
            this.MainToolbar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.AddLabel,
            this.AddPointButton,
            this.AddPolyLine,
            this.AddPolygonButton,
            this.AddCircleButton,
            this.AddImageButton,
            this.AddTextButton,
            this.toolStripSeparator1,
            this.toolStripLabel1,
            this.Button_SaveScene,
            this.Button_LoadScene,
            this.toolStripSeparator2,
            this.toolStripButtonLeft,
            this.toolStripButtonRight,
            this.toolStripSeparator3,
            this.toolStripButton1,
            this.toolStripButtonDown});
            this.MainToolbar.Location = new System.Drawing.Point(0, 0);
            this.MainToolbar.Name = "MainToolbar";
            this.MainToolbar.Size = new System.Drawing.Size(1177, 25);
            this.MainToolbar.TabIndex = 0;
            this.MainToolbar.Text = "MainToolbar";
            // 
            // AddLabel
            // 
            this.AddLabel.Name = "AddLabel";
            this.AddLabel.Size = new System.Drawing.Size(79, 22);
            this.AddLabel.Text = "Add Object : ";
            // 
            // AddPointButton
            // 
            this.AddPointButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddPointButton.Image = ((System.Drawing.Image)(resources.GetObject("AddPointButton.Image")));
            this.AddPointButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddPointButton.Name = "AddPointButton";
            this.AddPointButton.Size = new System.Drawing.Size(39, 22);
            this.AddPointButton.Text = "Point";
            this.AddPointButton.Click += new System.EventHandler(this.AddPointButton_Click);
            // 
            // AddPolyLine
            // 
            this.AddPolyLine.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddPolyLine.Image = ((System.Drawing.Image)(resources.GetObject("AddPolyLine.Image")));
            this.AddPolyLine.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddPolyLine.Name = "AddPolyLine";
            this.AddPolyLine.Size = new System.Drawing.Size(56, 22);
            this.AddPolyLine.Text = "PolyLine";
            this.AddPolyLine.Click += new System.EventHandler(this.AddPolyLine_Click);
            // 
            // AddPolygonButton
            // 
            this.AddPolygonButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddPolygonButton.Image = ((System.Drawing.Image)(resources.GetObject("AddPolygonButton.Image")));
            this.AddPolygonButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddPolygonButton.Name = "AddPolygonButton";
            this.AddPolygonButton.Size = new System.Drawing.Size(55, 22);
            this.AddPolygonButton.Text = "Polygon";
            this.AddPolygonButton.Click += new System.EventHandler(this.AddPolygonButton_Click);
            // 
            // AddCircleButton
            // 
            this.AddCircleButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddCircleButton.Image = ((System.Drawing.Image)(resources.GetObject("AddCircleButton.Image")));
            this.AddCircleButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddCircleButton.Name = "AddCircleButton";
            this.AddCircleButton.Size = new System.Drawing.Size(41, 22);
            this.AddCircleButton.Text = "Circle";
            this.AddCircleButton.Click += new System.EventHandler(this.AddCircleButton_Click);
            // 
            // AddImageButton
            // 
            this.AddImageButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddImageButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddImageButton.Name = "AddImageButton";
            this.AddImageButton.Size = new System.Drawing.Size(52, 22);
            this.AddImageButton.Text = "Symbol";
            this.AddImageButton.Click += new System.EventHandler(this.AddImageButton_Click);
            // 
            // AddTextButton
            // 
            this.AddTextButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.AddTextButton.Image = ((System.Drawing.Image)(resources.GetObject("AddTextButton.Image")));
            this.AddTextButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.AddTextButton.Name = "AddTextButton";
            this.AddTextButton.Size = new System.Drawing.Size(31, 22);
            this.AddTextButton.Text = "text";
            this.AddTextButton.Click += new System.EventHandler(this.AddTextButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(26, 22);
            this.toolStripLabel1.Text = "IO :";
            // 
            // Button_SaveScene
            // 
            this.Button_SaveScene.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Button_SaveScene.Image = ((System.Drawing.Image)(resources.GetObject("Button_SaveScene.Image")));
            this.Button_SaveScene.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Button_SaveScene.Name = "Button_SaveScene";
            this.Button_SaveScene.Size = new System.Drawing.Size(68, 22);
            this.Button_SaveScene.Text = "SaveScene";
            this.Button_SaveScene.Click += new System.EventHandler(this.Button_SaveScene_Click);
            // 
            // Button_LoadScene
            // 
            this.Button_LoadScene.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Button_LoadScene.Image = ((System.Drawing.Image)(resources.GetObject("Button_LoadScene.Image")));
            this.Button_LoadScene.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Button_LoadScene.Name = "Button_LoadScene";
            this.Button_LoadScene.Size = new System.Drawing.Size(69, 22);
            this.Button_LoadScene.Text = "LoadScene";
            this.Button_LoadScene.Click += new System.EventHandler(this.Button_LoadScene_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButtonLeft
            // 
            this.toolStripButtonLeft.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonLeft.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLeft.Image")));
            this.toolStripButtonLeft.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLeft.Name = "toolStripButtonLeft";
            this.toolStripButtonLeft.Size = new System.Drawing.Size(31, 22);
            this.toolStripButtonLeft.Text = "Left";
            this.toolStripButtonLeft.Click += new System.EventHandler(this.toolStripButtonLeft_Click);
            // 
            // toolStripButtonRight
            // 
            this.toolStripButtonRight.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonRight.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonRight.Image")));
            this.toolStripButtonRight.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonRight.Name = "toolStripButtonRight";
            this.toolStripButtonRight.Size = new System.Drawing.Size(39, 22);
            this.toolStripButtonRight.Text = "Right";
            this.toolStripButtonRight.Click += new System.EventHandler(this.toolStripButtonRight_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(26, 22);
            this.toolStripButton1.Text = "Up";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // toolStripButtonDown
            // 
            this.toolStripButtonDown.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButtonDown.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonDown.Image")));
            this.toolStripButtonDown.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonDown.Name = "toolStripButtonDown";
            this.toolStripButtonDown.Size = new System.Drawing.Size(43, 22);
            this.toolStripButtonDown.Text = "Down";
            this.toolStripButtonDown.Click += new System.EventHandler(this.toolStripButtonDown_Click);
            // 
            // ControlPanel
            // 
            this.ControlPanel.Controls.Add(this.splitContainer1);
            this.ControlPanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.ControlPanel.Location = new System.Drawing.Point(0, 25);
            this.ControlPanel.Name = "ControlPanel";
            this.ControlPanel.Size = new System.Drawing.Size(343, 551);
            this.ControlPanel.TabIndex = 1;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.ObjectTree);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.listView_DisplayOrder);
            this.splitContainer1.Panel2.Controls.Add(this.groupBox_DisplayOrder);
            this.splitContainer1.Size = new System.Drawing.Size(343, 551);
            this.splitContainer1.SplitterDistance = 339;
            this.splitContainer1.TabIndex = 1;
            // 
            // ObjectTree
            // 
            this.ObjectTree.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ObjectTree.Location = new System.Drawing.Point(0, 0);
            this.ObjectTree.Name = "ObjectTree";
            this.ObjectTree.Size = new System.Drawing.Size(343, 339);
            this.ObjectTree.TabIndex = 0;
            this.ObjectTree.MouseDown += new System.Windows.Forms.MouseEventHandler(this.ObjectTree_MouseDown);
            // 
            // listView_DisplayOrder
            // 
            this.listView_DisplayOrder.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader_DisplayDefault,
            this.columnHeader_DisplaySequence,
            this.columnHeader_DisplayUser});
            this.listView_DisplayOrder.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView_DisplayOrder.FullRowSelect = true;
            this.listView_DisplayOrder.GridLines = true;
            this.listView_DisplayOrder.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.listView_DisplayOrder.HideSelection = false;
            this.listView_DisplayOrder.HoverSelection = true;
            this.listView_DisplayOrder.Location = new System.Drawing.Point(0, 48);
            this.listView_DisplayOrder.MultiSelect = false;
            this.listView_DisplayOrder.Name = "listView_DisplayOrder";
            this.listView_DisplayOrder.Size = new System.Drawing.Size(343, 160);
            this.listView_DisplayOrder.TabIndex = 6;
            this.listView_DisplayOrder.UseCompatibleStateImageBehavior = false;
            this.listView_DisplayOrder.View = System.Windows.Forms.View.Details;
            this.listView_DisplayOrder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listView_DisplayOrder_MouseDown);
            // 
            // columnHeader_DisplayDefault
            // 
            this.columnHeader_DisplayDefault.Text = "Default Order";
            this.columnHeader_DisplayDefault.Width = 100;
            // 
            // columnHeader_DisplaySequence
            // 
            this.columnHeader_DisplaySequence.Text = "Order By Seq.";
            this.columnHeader_DisplaySequence.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader_DisplaySequence.Width = 100;
            // 
            // columnHeader_DisplayUser
            // 
            this.columnHeader_DisplayUser.Text = "Order By User";
            this.columnHeader_DisplayUser.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.columnHeader_DisplayUser.Width = 100;
            // 
            // groupBox_DisplayOrder
            // 
            this.groupBox_DisplayOrder.Controls.Add(this.radioButton_OrderUser);
            this.groupBox_DisplayOrder.Controls.Add(this.radioButton_OrderSequence);
            this.groupBox_DisplayOrder.Controls.Add(this.radioButton_OrderDefault);
            this.groupBox_DisplayOrder.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox_DisplayOrder.Location = new System.Drawing.Point(0, 0);
            this.groupBox_DisplayOrder.Name = "groupBox_DisplayOrder";
            this.groupBox_DisplayOrder.Size = new System.Drawing.Size(343, 48);
            this.groupBox_DisplayOrder.TabIndex = 5;
            this.groupBox_DisplayOrder.TabStop = false;
            this.groupBox_DisplayOrder.Text = "DisplayOrder";
            // 
            // radioButton_OrderUser
            // 
            this.radioButton_OrderUser.AutoSize = true;
            this.radioButton_OrderUser.Location = new System.Drawing.Point(235, 20);
            this.radioButton_OrderUser.Name = "radioButton_OrderUser";
            this.radioButton_OrderUser.Size = new System.Drawing.Size(103, 16);
            this.radioButton_OrderUser.TabIndex = 3;
            this.radioButton_OrderUser.TabStop = true;
            this.radioButton_OrderUser.Text = "Order By User";
            this.radioButton_OrderUser.UseVisualStyleBackColor = true;
            this.radioButton_OrderUser.CheckedChanged += new System.EventHandler(this.radioButton_OrderUser_CheckedChanged);
            // 
            // radioButton_OrderSequence
            // 
            this.radioButton_OrderSequence.AutoSize = true;
            this.radioButton_OrderSequence.Location = new System.Drawing.Point(96, 20);
            this.radioButton_OrderSequence.Name = "radioButton_OrderSequence";
            this.radioButton_OrderSequence.Size = new System.Drawing.Size(134, 16);
            this.radioButton_OrderSequence.TabIndex = 2;
            this.radioButton_OrderSequence.TabStop = true;
            this.radioButton_OrderSequence.Text = "Order By Sequence";
            this.radioButton_OrderSequence.UseVisualStyleBackColor = true;
            this.radioButton_OrderSequence.CheckedChanged += new System.EventHandler(this.radioButton_OrderSequence_CheckedChanged);
            // 
            // radioButton_OrderDefault
            // 
            this.radioButton_OrderDefault.AutoSize = true;
            this.radioButton_OrderDefault.Location = new System.Drawing.Point(11, 20);
            this.radioButton_OrderDefault.Name = "radioButton_OrderDefault";
            this.radioButton_OrderDefault.Size = new System.Drawing.Size(61, 16);
            this.radioButton_OrderDefault.TabIndex = 1;
            this.radioButton_OrderDefault.TabStop = true;
            this.radioButton_OrderDefault.Text = "Default";
            this.radioButton_OrderDefault.UseVisualStyleBackColor = true;
            this.radioButton_OrderDefault.CheckedChanged += new System.EventHandler(this.radioButton_OrderDefault_CheckedChanged);
            // 
            // ViewSplitContainer
            // 
            this.ViewSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ViewSplitContainer.Location = new System.Drawing.Point(343, 25);
            this.ViewSplitContainer.Name = "ViewSplitContainer";
            // 
            // ViewSplitContainer.Panel1
            // 
            this.ViewSplitContainer.Panel1.Controls.Add(this.nxPlanetView2D);
            // 
            // ViewSplitContainer.Panel2
            // 
            this.ViewSplitContainer.Panel2.Controls.Add(this.nxPlanetView3D);
            this.ViewSplitContainer.Size = new System.Drawing.Size(834, 551);
            this.ViewSplitContainer.SplitterDistance = 424;
            this.ViewSplitContainer.TabIndex = 2;
            // 
            // nxPlanetView2D
            // 
            this.nxPlanetView2D.AutoFocus = false;
            this.nxPlanetView2D.AutoRefreshRate = 0;
            this.nxPlanetView2D.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.nxPlanetView2D.Brightness = 1F;
            this.nxPlanetView2D.CallbackMode = true;
            this.nxPlanetView2D.Contrast = 1F;
            this.nxPlanetView2D.DisplayMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eDisplayMode.DisplayNormal;
            this.nxPlanetView2D.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nxPlanetView2D.EarthMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eEarthMode.Planet2D;
            this.nxPlanetView2D.ForceDraw = false;
            this.nxPlanetView2D.FrameCapture = null;
            this.nxPlanetView2D.GridType = Pixoneer.NXDL.NXPlanet.NXPlanetView.eGridType.GridDegrees;
            this.nxPlanetView2D.HeightFactor = 1F;
            this.nxPlanetView2D.InverseMouseButton = false;
            this.nxPlanetView2D.InverseMouseWheel = false;
            this.nxPlanetView2D.LayoutMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eLayoutMode.Windows;
            this.nxPlanetView2D.Location = new System.Drawing.Point(0, 0);
            this.nxPlanetView2D.Name = "nxPlanetView2D";
            this.nxPlanetView2D.RelativeHeight = 1D;
            this.nxPlanetView2D.RelativeLeft = 0D;
            this.nxPlanetView2D.RelativeTop = 0D;
            this.nxPlanetView2D.RelativeWidth = 1D;
            this.nxPlanetView2D.RestrictRenerArea = false;
            this.nxPlanetView2D.Rotatable = true;
            this.nxPlanetView2D.Saturation = 1F;
            this.nxPlanetView2D.ShowControlPoint = true;
            this.nxPlanetView2D.ShowGrid = true;
            this.nxPlanetView2D.ShowPBP = true;
            this.nxPlanetView2D.ShowPBV = true;
            this.nxPlanetView2D.ShowStatusInfo = false;
            this.nxPlanetView2D.SingleBaseMap = false;
            this.nxPlanetView2D.Size = new System.Drawing.Size(424, 551);
            this.nxPlanetView2D.TabIndex = 0;
            this.nxPlanetView2D.ToolboxAreaUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxAreaUnit.SquareMeter;
            this.nxPlanetView2D.ToolboxDistUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxDistUnit.Meter;
            this.nxPlanetView2D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.None;
            xAngle1.deg = 45D;
            this.nxPlanetView2D.ViewAreaFOV = xAngle1;
            this.nxPlanetView2D.ViewAreaID = -1;
            this.nxPlanetView2D.ZoomCenterMode = Pixoneer.NXDL.eViewZoomCenterMode.CenterByCursor;
            // 
            // nxPlanetView3D
            // 
            this.nxPlanetView3D.AutoFocus = false;
            this.nxPlanetView3D.AutoRefreshRate = 0;
            this.nxPlanetView3D.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.nxPlanetView3D.Brightness = 1F;
            this.nxPlanetView3D.CallbackMode = true;
            this.nxPlanetView3D.Contrast = 1F;
            this.nxPlanetView3D.DisplayMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eDisplayMode.DisplayNormal;
            this.nxPlanetView3D.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nxPlanetView3D.EarthMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eEarthMode.Planet3D;
            this.nxPlanetView3D.ForceDraw = false;
            this.nxPlanetView3D.FrameCapture = null;
            this.nxPlanetView3D.GridType = Pixoneer.NXDL.NXPlanet.NXPlanetView.eGridType.GridDegrees;
            this.nxPlanetView3D.HeightFactor = 1F;
            this.nxPlanetView3D.InverseMouseButton = false;
            this.nxPlanetView3D.InverseMouseWheel = false;
            this.nxPlanetView3D.LayoutMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eLayoutMode.Windows;
            this.nxPlanetView3D.Location = new System.Drawing.Point(0, 0);
            this.nxPlanetView3D.Name = "nxPlanetView3D";
            this.nxPlanetView3D.RelativeHeight = 1D;
            this.nxPlanetView3D.RelativeLeft = 0D;
            this.nxPlanetView3D.RelativeTop = 0D;
            this.nxPlanetView3D.RelativeWidth = 1D;
            this.nxPlanetView3D.RestrictRenerArea = false;
            this.nxPlanetView3D.Rotatable = true;
            this.nxPlanetView3D.Saturation = 1F;
            this.nxPlanetView3D.ShowControlPoint = true;
            this.nxPlanetView3D.ShowGrid = true;
            this.nxPlanetView3D.ShowPBP = true;
            this.nxPlanetView3D.ShowPBV = true;
            this.nxPlanetView3D.ShowStatusInfo = false;
            this.nxPlanetView3D.SingleBaseMap = false;
            this.nxPlanetView3D.Size = new System.Drawing.Size(406, 551);
            this.nxPlanetView3D.TabIndex = 0;
            this.nxPlanetView3D.ToolboxAreaUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxAreaUnit.SquareMeter;
            this.nxPlanetView3D.ToolboxDistUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxDistUnit.Meter;
            this.nxPlanetView3D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.None;
            xAngle2.deg = 45D;
            this.nxPlanetView3D.ViewAreaFOV = xAngle2;
            this.nxPlanetView3D.ViewAreaID = -1;
            this.nxPlanetView3D.ZoomCenterMode = Pixoneer.NXDL.eViewZoomCenterMode.CenterByCursor;
            // 
            // nxPlanetLayer2D
            // 
            this.nxPlanetLayer2D.AutoDelete = true;
            this.nxPlanetLayer2D.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nxPlanetLayer2D.LayerCapture = false;
            this.nxPlanetLayer2D.LayerVisible = true;
            this.nxPlanetLayer2D.Location = new System.Drawing.Point(0, 0);
            this.nxPlanetLayer2D.Name = "nxPlanetLayer2D";
            this.nxPlanetLayer2D.Size = new System.Drawing.Size(145, 30);
            this.nxPlanetLayer2D.TabIndex = 0;
            this.nxPlanetLayer2D.UseDisplayList = true;
            this.nxPlanetLayer2D.Visible = false;
            this.nxPlanetLayer2D.ZFar = 1.7E+308D;
            this.nxPlanetLayer2D.ZNear = 1.7E+308D;
            this.nxPlanetLayer2D.OnRender += new Pixoneer.NXDL.NXPlanet.NXPlanetLayerRenderEvent(this.nxPlanetLayer2D_OnRender);
            // 
            // nxPlanetLayerSceneEditor
            // 
            this.nxPlanetLayerSceneEditor.AutoDelete = false;
            this.nxPlanetLayerSceneEditor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nxPlanetLayerSceneEditor.EditableScene = false;
            this.nxPlanetLayerSceneEditor.HitTestableScene = false;
            this.nxPlanetLayerSceneEditor.LayerCapture = true;
            this.nxPlanetLayerSceneEditor.LayerVisible = true;
            this.nxPlanetLayerSceneEditor.Location = new System.Drawing.Point(0, 0);
            this.nxPlanetLayerSceneEditor.Name = "nxPlanetLayerSceneEditor";
            this.nxPlanetLayerSceneEditor.Size = new System.Drawing.Size(145, 30);
            this.nxPlanetLayerSceneEditor.TabIndex = 0;
            this.nxPlanetLayerSceneEditor.UsableKeyboard = false;
            this.nxPlanetLayerSceneEditor.UseDisplayList = true;
            this.nxPlanetLayerSceneEditor.Visible = false;
            this.nxPlanetLayerSceneEditor.ZFar = 1.7E+308D;
            this.nxPlanetLayerSceneEditor.ZNear = 1.7E+308D;
            this.nxPlanetLayerSceneEditor.OnObjectCreated += new Pixoneer.NXDL.NSCENE.NXSCEditEvent(this.nxPlanetLayerSceneEditor_OnObjectCreated);
            this.nxPlanetLayerSceneEditor.OnObjectEditOver += new Pixoneer.NXDL.NSCENE.NXSCEditEvent(this.nxPlanetLayerSceneEditor_OnObjectEditOver);
            // 
            // itemContextMenu
            // 
            this.itemContextMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MenuProperty});
            this.itemContextMenu.Name = "itemContextMenu";
            this.itemContextMenu.Size = new System.Drawing.Size(99, 26);
            // 
            // MenuProperty
            // 
            this.MenuProperty.Name = "MenuProperty";
            this.MenuProperty.Size = new System.Drawing.Size(98, 22);
            this.MenuProperty.Text = "속성";
            // 
            // nxPlanetLayerSceneDisplay3D
            // 
            this.nxPlanetLayerSceneDisplay3D.AutoDelete = false;
            this.nxPlanetLayerSceneDisplay3D.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.nxPlanetLayerSceneDisplay3D.HitTestableScene = false;
            this.nxPlanetLayerSceneDisplay3D.LayerCapture = true;
            this.nxPlanetLayerSceneDisplay3D.LayerVisible = true;
            this.nxPlanetLayerSceneDisplay3D.Location = new System.Drawing.Point(0, 0);
            this.nxPlanetLayerSceneDisplay3D.Name = "nxPlanetLayerSceneDisplay3D";
            this.nxPlanetLayerSceneDisplay3D.RenderListMode = false;
            this.nxPlanetLayerSceneDisplay3D.Size = new System.Drawing.Size(145, 30);
            this.nxPlanetLayerSceneDisplay3D.TabIndex = 0;
            this.nxPlanetLayerSceneDisplay3D.UseDisplayList = true;
            this.nxPlanetLayerSceneDisplay3D.Visible = false;
            this.nxPlanetLayerSceneDisplay3D.ZFar = 1.7E+308D;
            this.nxPlanetLayerSceneDisplay3D.ZNear = 1.7E+308D;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1177, 576);
            this.Controls.Add(this.ViewSplitContainer);
            this.Controls.Add(this.ControlPanel);
            this.Controls.Add(this.MainToolbar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "SceneEditor";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.MainToolbar.ResumeLayout(false);
            this.MainToolbar.PerformLayout();
            this.ControlPanel.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.groupBox_DisplayOrder.ResumeLayout(false);
            this.groupBox_DisplayOrder.PerformLayout();
            this.ViewSplitContainer.Panel1.ResumeLayout(false);
            this.ViewSplitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ViewSplitContainer)).EndInit();
            this.ViewSplitContainer.ResumeLayout(false);
            this.itemContextMenu.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip MainToolbar;
        private System.Windows.Forms.Panel ControlPanel;
        private System.Windows.Forms.SplitContainer ViewSplitContainer;
        private System.Windows.Forms.TreeView ObjectTree;
        private Pixoneer.NXDL.NXPlanet.NXPlanetView nxPlanetView2D;
        private Pixoneer.NXDL.NXPlanet.NXPlanetView nxPlanetView3D;
        private System.Windows.Forms.ToolStripLabel AddLabel;
        private System.Windows.Forms.ToolStripButton AddPointButton;
        private System.Windows.Forms.ToolStripButton AddPolyLine;
        private System.Windows.Forms.ToolStripButton AddPolygonButton;
        private System.Windows.Forms.ToolStripButton AddImageButton;
        private System.Windows.Forms.ToolStripButton AddCircleButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private Pixoneer.NXDL.NSCENE.NXPlanetLayerSceneEditor nxPlanetLayerSceneEditor;
        private Pixoneer.NXDL.NXPlanet.NXPlanetLayer nxPlanetLayer2D;
        private System.Windows.Forms.ContextMenuStrip itemContextMenu;
        private System.Windows.Forms.ToolStripMenuItem MenuProperty;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton Button_SaveScene;
        private System.Windows.Forms.ToolStripButton Button_LoadScene;
        private Pixoneer.NXDL.NSCENE.NXPlanetLayerSceneDisplay nxPlanetLayerSceneDisplay3D;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListView listView_DisplayOrder;
        private System.Windows.Forms.ColumnHeader columnHeader_DisplayDefault;
        private System.Windows.Forms.ColumnHeader columnHeader_DisplaySequence;
        private System.Windows.Forms.ColumnHeader columnHeader_DisplayUser;
        private System.Windows.Forms.GroupBox groupBox_DisplayOrder;
        private System.Windows.Forms.RadioButton radioButton_OrderUser;
        private System.Windows.Forms.RadioButton radioButton_OrderSequence;
        private System.Windows.Forms.RadioButton radioButton_OrderDefault;
        private System.Windows.Forms.ToolStripButton AddTextButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButtonLeft;
        private System.Windows.Forms.ToolStripButton toolStripButtonRight;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStripButton toolStripButtonDown;
    }
}

