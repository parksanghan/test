﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NGR;

namespace SceneEditor
{
    public partial class TextProperty : Form
    {
        public int nID;
        public string strText;
        public bool bShowText;
        public string strFontname;
        public int nFontSize;
        public Color textcolor;
        public Color outlineColor;
        public bool bShowOutline;
        public eTextAlign m_TextAlign;
        public eTextAlignV m_TextAlignV;
        public bool bUnderLine;
        public bool bBold;
        public bool bStrikeout;
        public bool bItalic;
        public Pixoneer.NXDL.NSCENE.XscText.eTextBorderLinePatternType BorderLineStyle;
        public bool bShowBorder;
        public int nBorderLineWidth;
        public Color borderColor;
        private bool m_Hide;

        public bool ObjectHide
        {
            get { return m_Hide; }
            set { m_Hide = value; }
        }

        public TextProperty()
        {
            InitializeComponent();
        }

        private void TextProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = string.Format("{0}", nID);
            TextBox_Text.Text = strText;
            checkBox_ShowText.Checked = bShowText;
            TextBox_FontName.Text = strFontname;
            textBox_FontSize.Text = string.Format("{0}", nFontSize);
            TextBox_TextColor.BackColor = textcolor;
            TextBox_OutlineColor.BackColor = outlineColor;
            checkBox_ShowOutline.Checked = bShowOutline;
            comboBox_TextAlign.SelectedIndex = (int)m_TextAlign;
            comboBox_TextAlignV.SelectedIndex = (int)m_TextAlignV;
            checkBox_Underline.Checked = bUnderLine;
            checkBox_Bold.Checked = bBold;
            checkBox_Strikeout.Checked = bStrikeout;
            checkBox_Italic.Checked = bItalic;
            comboBox_BorderlineStyle.SelectedIndex = (int)BorderLineStyle;
            checkBox_ShowBorder.Checked = bShowBorder;
            textBox_BorderLineWidth.Text = string.Format("{0}", nBorderLineWidth);
            switch (ObjectHide)
            {
                case true:
                    comboBox_Hide.SelectedIndex = 0;
                    break;
                case false:
                    comboBox_Hide.SelectedIndex = 1;
                    break;
            }
        }

        private void checkBox_ShowText_CheckedChanged(object sender, EventArgs e)
        {
            bShowText = checkBox_ShowText.Checked;
        }

        private void button_FontDialog_Click(object sender, EventArgs e)
        {
            FontDialog fontdlg = new FontDialog();
            fontdlg.ShowColor = false;

            if (fontdlg.ShowDialog() != DialogResult.Cancel)
            {
                TextBox_FontName.Text = fontdlg.Font.Name;
                textBox_FontSize.Text = (Convert.ToInt32(fontdlg.Font.Size)).ToString();
            }
        }

        private void Button_TextColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = textcolor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                textcolor = dlg.Color;
                TextBox_TextColor.BackColor = textcolor;
            }
        }

        private void Button_ColorDlg_Click(object sender, EventArgs e)
        {
            ColorDialog dlg = new ColorDialog();
            dlg.Color = outlineColor;
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                outlineColor = dlg.Color;
                TextBox_OutlineColor.BackColor = outlineColor;
            }
        }

        private void checkBox_ShowOutline_CheckedChanged(object sender, EventArgs e)
        {
            bShowOutline = checkBox_ShowOutline.Checked;
        }

        private void checkBox_Underline_CheckedChanged(object sender, EventArgs e)
        {
            bUnderLine = checkBox_Underline.Checked;
        }

        private void checkBox_Strikeout_CheckedChanged(object sender, EventArgs e)
        {
            bStrikeout = checkBox_Strikeout.Checked;
        }

        private void checkBox_Bold_CheckedChanged(object sender, EventArgs e)
        {
            bBold = checkBox_Bold.Checked;
        }

        private void checkBox_Italic_CheckedChanged(object sender, EventArgs e)
        {
            bItalic = checkBox_Italic.Checked;
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            strText = TextBox_Text.Text;
            strFontname = TextBox_FontName.Text;
            nFontSize = int.Parse(textBox_FontSize.Text);
            nBorderLineWidth = int.Parse(textBox_BorderLineWidth.Text);
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {

        }

        private void comboBox_TextAlign_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlign = (eTextAlign)comboBox_TextAlign.SelectedIndex;
        }

        private void comboBox_BorderlineStyle_SelectedIndexChanged(object sender, EventArgs e)
        {
            BorderLineStyle = (Pixoneer.NXDL.NSCENE.XscText.eTextBorderLinePatternType)comboBox_BorderlineStyle.SelectedIndex;
        }

        private void checkBox_ShowBorder_CheckedChanged(object sender, EventArgs e)
        {
            bShowBorder = checkBox_ShowBorder.Checked;
        }

        private void comboBox_Hide_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (comboBox_Hide.SelectedIndex)
            {
                case 0:
                    ObjectHide = true;
                    break;
                case 1:
                    ObjectHide = false;
                    break;
            }
        }

        private void comboBox_TextAlignV_SelectedIndexChanged(object sender, EventArgs e)
        {
            m_TextAlignV = (eTextAlignV)comboBox_TextAlignV.SelectedIndex;
        }
    }
}
