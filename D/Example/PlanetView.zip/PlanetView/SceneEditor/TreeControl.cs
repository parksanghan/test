﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL.NSCENE;

namespace SceneEditor
{
    public class XscObjTreeItem
    {
        public XscObj pObj;
        public String strName;
        public int nID;

        public XscObjTreeItem()
        {
            pObj = null;
            strName = "";
            nID = 0;
        }
    }


    public partial class MainForm : Form
    {
        private void InitialTreeControl()
        {
            ObjectTree.ResetText();
            TreeNode tnCategory = null;
            AddTreeNode("XScene", "XScene", ref tnCategory);
            AddTreeNode("Point", "Point", ref tnCategory);
            AddTreeNode("Polyline", "Polyline", ref tnCategory);
            AddTreeNode("Polygon", "Polygon", ref tnCategory);
            AddTreeNode("Circle", "Circle", ref tnCategory);
            AddTreeNode("Symbol", "Symbol", ref tnCategory);
            AddTreeNode("Text", "Text", ref tnCategory);
            ObjectTree.Nodes.Add(tnCategory);
            ObjectTree.ExpandAll();
        }
        
        private void AddTreeNode(String strKey, String strNodeName, ref TreeNode Parent)
        {
            if (Parent == null)
            {
                Parent = new TreeNode(strNodeName);
                return;
            }
            Parent.Nodes.Add(strKey, strNodeName);
        }

        private bool AddTreeNode(String strObjectName, String strNodeName, ref String strError)
        {

            TreeNode[]  NodeItem = ObjectTree.Nodes.Find(strObjectName, true);

            if (NodeItem.Length == 0)
            {
                strError = String.Format("{0} Item Is Not Exist", strObjectName);
                return false;
            }
            
            ObjectTree.Nodes.Find(strObjectName, true)[0].Nodes.Add(strObjectName, strNodeName);
            ObjectTree.ExpandAll();

            return true;
        }
        private void ShowPointPropertyDlg(string strItemName)
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            XscPoint obj = (XscPoint)sc.GetNode(int.Parse(strItemName));
            if (obj == null) return;

            PointProperty dlg = new PointProperty();
            dlg.ID = obj.ObjID;
            dlg.ObjectName = obj.Name;
            dlg.Color = obj.LineColor;
            dlg.Type = obj.PointType;
            dlg.PointSize = obj.LineWidth;
            dlg.ShowName = obj.ShowName;
            dlg.TextColor = obj.TextColor;
            dlg.TextAlign = obj.TextAlign;
            dlg.ObjectHide = !(obj.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj.Name = dlg.ObjectName;
                obj.LineColor = dlg.Color;
                obj.PointType = dlg.Type;
                obj.LineWidth = dlg.PointSize;
                obj.ShowName = dlg.ShowName;
                obj.TextColor = dlg.TextColor;
                obj.TextAlign = dlg.TextAlign;
                obj.ShowObj = !(dlg.ObjectHide);
            }
            this.nxPlanetLayerSceneEditor.EditObjectEnd();
            nxPlanetView2D.RefreshScreen();
        }
        private void ShowPolylinePropertyDlg(string strItemName)
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            XscPolyLine obj = (XscPolyLine)sc.GetNode(int.Parse(strItemName));
            if (obj == null) return;

            PolylinetProperty dlg = new PolylinetProperty();
            dlg.ID = obj.ObjID;
            dlg.ObjectName = obj.Name;
            dlg.Color = obj.LineColor;
            dlg.Type = obj.LinePattern;
            dlg.LineWidth= obj.LineWidth;
            dlg.ShowName = obj.ShowName;
            dlg.TextColor = obj.TextColor;
            dlg.TextAlign = obj.TextAlign;
            dlg.ObjectHide = !(obj.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj.Name = dlg.ObjectName;
                obj.LineColor = dlg.Color;
                obj.LinePattern = dlg.Type;
                obj.LineWidth = dlg.LineWidth;
                obj.ShowName = dlg.ShowName;
                obj.TextColor = dlg.TextColor;
                obj.TextAlign = dlg.TextAlign;
                obj.ShowObj = !(dlg.ObjectHide);
            }
            this.nxPlanetLayerSceneEditor.EditObjectEnd();
            nxPlanetView2D.RefreshScreen();
        }
        private void ShowPolygonPropertyDlg(string strItemName)
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            XscPolygon obj = (XscPolygon)sc.GetNode(int.Parse(strItemName));
            if (obj == null) return;

            PolygonProperty dlg = new PolygonProperty();
            dlg.ID = obj.ObjID;
            dlg.ObjectName = obj.Name;
            dlg.LineColor = obj.BorderColor;
            dlg.Type = obj.LinePattern;
            dlg.FillStyle = obj.FillPattern;
            dlg.LineWidth = obj.BorderSize;
            dlg.FillColor = obj.FillColor;
            dlg.ShowName = obj.ShowName;
            dlg.TextColor = obj.TextColor;
            dlg.TextAlign = obj.TextAlign;
            dlg.ObjectHide = !(obj.ShowObj);
            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj.Name = dlg.ObjectName;
                obj.BorderColor = dlg.LineColor;
                obj.LinePattern = dlg.Type;
                obj.FillPattern = dlg.FillStyle;
                obj.BorderSize = dlg.LineWidth;
                obj.ShowName = dlg.ShowName;
                obj.TextColor = dlg.TextColor;
                obj.TextAlign = dlg.TextAlign;
                obj.FillColor = dlg.FillColor;
                obj.ShowObj = !(dlg.ObjectHide);
            }

            this.nxPlanetLayerSceneEditor.EditObjectEnd();
            nxPlanetView2D.RefreshScreen();
        }

        private void ShowCirclePropertyDlg(string strItemName)
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            XscCircle obj = (XscCircle)sc.GetNode(int.Parse(strItemName));
            if (obj == null) return;

            CircleProperty dlg = new CircleProperty();
            dlg.ID = obj.ObjID;
            dlg.ObjectName = obj.Name;
            dlg.LineColor = obj.LineColor;
            dlg.Type = obj.LinePattern;
            dlg.FillStyle = obj.FillPattern;
            dlg.LineWidth = obj.LineWidth;
            dlg.FillColor = obj.FillColor;
            dlg.ShowName = obj.ShowName;
            dlg.TextColor = obj.TextColor;
            dlg.TextAlign = obj.TextAlign;
            dlg.Radius = obj.Radius;
            dlg.ObjectHide = !(obj.ShowObj);

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj.Name = dlg.ObjectName;
                obj.LineColor = dlg.LineColor;
                obj.LinePattern = dlg.Type;
                obj.FillPattern = dlg.FillStyle;
                obj.LineWidth = dlg.LineWidth;
                obj.ShowName = dlg.ShowName;
                obj.TextColor = dlg.TextColor;
                obj.TextAlign = dlg.TextAlign;
                obj.FillColor = dlg.FillColor;
                obj.Radius = dlg.Radius;
                obj.ShowObj = !(dlg.ObjectHide);
            }
            this.nxPlanetLayerSceneEditor.EditObjectEnd();
            nxPlanetView2D.RefreshScreen();
        }

        private void ShowSymbolPropertyDlg(string strItemName)
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            XscSymbol obj = (XscSymbol)sc.GetNode(int.Parse(strItemName));
            if (obj == null) return;

            SymbolProperty dlg = new SymbolProperty();
            dlg.ID = obj.ObjID;
            dlg.ObjectName = obj.Name;
            dlg.ShowName = obj.ShowName;
            dlg.ImageFile = obj.UserSymbolPath;
            dlg.TextColor = obj.TextColor;
            dlg.Symbol = obj.DefaultSymbolName;
            dlg.TextAlign = obj.TextAlign;
            dlg.ObjectHide = !(obj.ShowObj);

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj.Name = dlg.ObjectName;
                obj.ShowName = dlg.ShowName;
                
                obj.TextColor = dlg.TextColor;
                obj.TextAlign = dlg.TextAlign;
                if (dlg.UseDefaultSymbol)
                    obj.DefaultSymbolName = dlg.Symbol;
                else
                {
                    if (dlg.ImageFile != "")
                        obj.UserSymbolPath = dlg.ImageFile;
                }
                obj.ShowObj = !(dlg.ObjectHide);

                obj.UpdateSymbol();

            }
            this.nxPlanetLayerSceneEditor.EditObjectEnd();
            nxPlanetView2D.RefreshScreen();
        }

        private void ShowTextPropertyDlg(string strItemName)
        {
            XScene sc = nxPlanetLayerSceneEditor.GetScene();
            if (sc == null) return;
            XscText obj = (XscText)sc.GetNode(int.Parse(strItemName));
            if (obj == null) return;
            TextProperty dlg = new TextProperty();
            dlg.nID = obj.ObjID;
            dlg.strText = obj.Text;
            dlg.bShowText = obj.ShowObj;
            dlg.strFontname = obj.FontName;
            dlg.nFontSize = obj.FontHeight;
            dlg.textcolor = obj.TextColor;
            dlg.outlineColor = obj.TextOutLineColor;
            dlg.bShowOutline = obj.ShowOutLine;
            dlg.m_TextAlign = obj.TextAlign;
            dlg.m_TextAlignV = obj.TextAlignV;
            dlg.bUnderLine = obj.IsUnderLine;
            dlg.bBold = obj.IsBold;
            dlg.bStrikeout = obj.IsStrikeOut;
            dlg.bItalic = obj.IsItalic;
            dlg.BorderLineStyle = obj.TextBorderStyle;
            dlg.bShowBorder = obj.IsTextBorder;
            dlg.nBorderLineWidth = obj.BorderLineWidth;
            dlg.ObjectHide = !(obj.ShowObj);

            if (dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                obj.Text = dlg.strText;
                obj.ShowObj = dlg.bShowText;
                obj.FontName = dlg.strFontname;
                obj.FontHeight = dlg.nFontSize;
                obj.TextColor = dlg.textcolor;
                obj.TextOutLineColor = dlg.outlineColor;
                obj.ShowOutLine = dlg.bShowOutline;
                obj.TextAlign = dlg.m_TextAlign;
                obj.TextAlignV = dlg.m_TextAlignV;
                obj.IsUnderLine = dlg.bUnderLine;
                obj.IsBold = dlg.bBold;
                obj.IsStrikeOut = dlg.bStrikeout;
                obj.IsItalic = dlg.bItalic;
                obj.TextBorderStyle = dlg.BorderLineStyle;
                obj.IsTextBorder = dlg.bShowBorder;
                obj.BorderLineWidth = dlg.nBorderLineWidth;
                obj.ShowObj = !(dlg.ObjectHide);
            }
            this.nxPlanetLayerSceneEditor.EditObjectEnd();
            nxPlanetView2D.RefreshScreen();
        }

        private void ShowPropertyDlg(string strItemName, string objType)
        {

            if ("Point" == objType)
                ShowPointPropertyDlg(strItemName);
            else if ("Polyline" == objType)
                ShowPolylinePropertyDlg(strItemName);
            else if ("Polygon" == objType)
                ShowPolygonPropertyDlg(strItemName);
            else if ("Circle" == objType)
                ShowCirclePropertyDlg(strItemName);
            else if ("Symbol" == objType)
                ShowSymbolPropertyDlg(strItemName);
            else if ("Text" == objType)
                ShowTextPropertyDlg(strItemName);
        }

        private void ObjectTree_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                TreeNode nodeitem = ObjectTree.GetNodeAt(e.X, e.Y);
                if (nodeitem == null) return;
                string selectedNickname = nodeitem.Text;

                if( "XScene"   != selectedNickname &&
                    "Point"    != selectedNickname &&
                    "Polyline" != selectedNickname &&
                    "Polygon"  != selectedNickname &&
                    "Circle"   != selectedNickname &&
                    "Symbol"    != selectedNickname &&
                    "Text" != selectedNickname)
                {

                    ContextMenu m = new ContextMenu();

                    MenuItem property = new MenuItem();
                    property.Text = "속성";
                    property.Click += (senders, es) =>
                    {
                        ShowPropertyDlg(selectedNickname,nodeitem.Parent.Text);
                    };

                    m.MenuItems.Add(property);
                    m.Show(ObjectTree, new Point(e.X, e.Y));

                }
            }
        }
    }
}
