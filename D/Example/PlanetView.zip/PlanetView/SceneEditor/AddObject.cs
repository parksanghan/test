﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace SceneEditor
{
    public partial class MainForm : Form
    {
        private void AddPointButton_Click(object sender, EventArgs e)
        {
           nxPlanetLayerSceneEditor.CreateNewOBJ("XscPoint");
        }

        private void AddPolyLine_Click(object sender, EventArgs e)
        {
            nxPlanetLayerSceneEditor.CreateNewOBJ("XscPolyLine");
        }

        private void AddPolygonButton_Click(object sender, EventArgs e)
        {
            nxPlanetLayerSceneEditor.CreateNewOBJ("XscPolygon");
        }

        private void AddCircleButton_Click(object sender, EventArgs e)
        {
            nxPlanetLayerSceneEditor.CreateNewOBJ("XscCircle");
        }

        private void AddImageButton_Click(object sender, EventArgs e)
        {
            nxPlanetLayerSceneEditor.CreateNewOBJ("XscSymbol");
        }

        private void AddTextButton_Click(object sender, EventArgs e)
        {
            nxPlanetLayerSceneEditor.CreateNewOBJ("XscText");
        }
    }
}
