﻿namespace SceneEditor
{
    partial class PointProperty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PointProperty));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TextBox_ID = new System.Windows.Forms.TextBox();
            this.TextBox_Name = new System.Windows.Forms.TextBox();
            this.TextBox_PointColor = new System.Windows.Forms.TextBox();
            this.Button_ColorDlg = new System.Windows.Forms.Button();
            this.comboBox_Style = new System.Windows.Forms.ComboBox();
            this.ButtonApply = new System.Windows.Forms.Button();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.textBox_PointSize = new System.Windows.Forms.TextBox();
            this.checkBox_ShowName = new System.Windows.Forms.CheckBox();
            this.Button_TextColorDlg = new System.Windows.Forms.Button();
            this.TextBox_TextColor = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox_TextAlign = new System.Windows.Forms.ComboBox();
            this.comboBox_Hide = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "▶ ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = "▶ Name :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "▶ Size :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 140);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(59, 12);
            this.label4.TabIndex = 3;
            this.label4.Text = "▶ Color :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "▶ Style :";
            // 
            // TextBox_ID
            // 
            this.TextBox_ID.Location = new System.Drawing.Point(95, 17);
            this.TextBox_ID.Name = "TextBox_ID";
            this.TextBox_ID.ReadOnly = true;
            this.TextBox_ID.Size = new System.Drawing.Size(131, 21);
            this.TextBox_ID.TabIndex = 5;
            // 
            // TextBox_Name
            // 
            this.TextBox_Name.Location = new System.Drawing.Point(95, 50);
            this.TextBox_Name.Name = "TextBox_Name";
            this.TextBox_Name.Size = new System.Drawing.Size(131, 21);
            this.TextBox_Name.TabIndex = 5;
            // 
            // TextBox_PointColor
            // 
            this.TextBox_PointColor.Location = new System.Drawing.Point(96, 137);
            this.TextBox_PointColor.Name = "TextBox_PointColor";
            this.TextBox_PointColor.ReadOnly = true;
            this.TextBox_PointColor.Size = new System.Drawing.Size(94, 21);
            this.TextBox_PointColor.TabIndex = 5;
            // 
            // Button_ColorDlg
            // 
            this.Button_ColorDlg.Location = new System.Drawing.Point(196, 138);
            this.Button_ColorDlg.Name = "Button_ColorDlg";
            this.Button_ColorDlg.Size = new System.Drawing.Size(27, 19);
            this.Button_ColorDlg.TabIndex = 7;
            this.Button_ColorDlg.Text = "...";
            this.Button_ColorDlg.UseVisualStyleBackColor = true;
            this.Button_ColorDlg.Click += new System.EventHandler(this.Button_ColorDlg_Click);
            // 
            // comboBox_Style
            // 
            this.comboBox_Style.FormattingEnabled = true;
            this.comboBox_Style.Items.AddRange(new object[] {
            "dot",
            "rect",
            "triangle",
            "+",
            "X"});
            this.comboBox_Style.Location = new System.Drawing.Point(97, 195);
            this.comboBox_Style.Name = "comboBox_Style";
            this.comboBox_Style.Size = new System.Drawing.Size(127, 20);
            this.comboBox_Style.TabIndex = 6;
            this.comboBox_Style.SelectedIndexChanged += new System.EventHandler(this.comboBox_Style_SelectedIndexChanged);
            // 
            // ButtonApply
            // 
            this.ButtonApply.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.ButtonApply.Location = new System.Drawing.Point(95, 282);
            this.ButtonApply.Name = "ButtonApply";
            this.ButtonApply.Size = new System.Drawing.Size(59, 25);
            this.ButtonApply.TabIndex = 8;
            this.ButtonApply.Text = "Apply";
            this.ButtonApply.UseVisualStyleBackColor = true;
            this.ButtonApply.Click += new System.EventHandler(this.ButtonApply_Click);
            // 
            // button_Cancel
            // 
            this.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Cancel.Location = new System.Drawing.Point(166, 282);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(59, 25);
            this.button_Cancel.TabIndex = 9;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // textBox_PointSize
            // 
            this.textBox_PointSize.Location = new System.Drawing.Point(96, 108);
            this.textBox_PointSize.Name = "textBox_PointSize";
            this.textBox_PointSize.Size = new System.Drawing.Size(131, 21);
            this.textBox_PointSize.TabIndex = 10;
            // 
            // checkBox_ShowName
            // 
            this.checkBox_ShowName.AutoSize = true;
            this.checkBox_ShowName.Location = new System.Drawing.Point(96, 80);
            this.checkBox_ShowName.Name = "checkBox_ShowName";
            this.checkBox_ShowName.Size = new System.Drawing.Size(94, 16);
            this.checkBox_ShowName.TabIndex = 11;
            this.checkBox_ShowName.Text = "Show Name";
            this.checkBox_ShowName.UseVisualStyleBackColor = true;
            this.checkBox_ShowName.CheckedChanged += new System.EventHandler(this.checkBox_ShowName_CheckedChanged);
            // 
            // Button_TextColorDlg
            // 
            this.Button_TextColorDlg.Location = new System.Drawing.Point(198, 165);
            this.Button_TextColorDlg.Name = "Button_TextColorDlg";
            this.Button_TextColorDlg.Size = new System.Drawing.Size(27, 19);
            this.Button_TextColorDlg.TabIndex = 14;
            this.Button_TextColorDlg.Text = "...";
            this.Button_TextColorDlg.UseVisualStyleBackColor = true;
            this.Button_TextColorDlg.Click += new System.EventHandler(this.Button_TextColorDlg_Click);
            // 
            // TextBox_TextColor
            // 
            this.TextBox_TextColor.Location = new System.Drawing.Point(97, 164);
            this.TextBox_TextColor.Name = "TextBox_TextColor";
            this.TextBox_TextColor.ReadOnly = true;
            this.TextBox_TextColor.Size = new System.Drawing.Size(94, 21);
            this.TextBox_TextColor.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 167);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 12);
            this.label6.TabIndex = 12;
            this.label6.Text = "▶ Text Color :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 228);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 12);
            this.label7.TabIndex = 15;
            this.label7.Text = "▶ Text Align :";
            // 
            // comboBox_TextAlign
            // 
            this.comboBox_TextAlign.FormattingEnabled = true;
            this.comboBox_TextAlign.Items.AddRange(new object[] {
            "Center",
            "Left",
            "Right"});
            this.comboBox_TextAlign.Location = new System.Drawing.Point(97, 225);
            this.comboBox_TextAlign.Name = "comboBox_TextAlign";
            this.comboBox_TextAlign.Size = new System.Drawing.Size(127, 20);
            this.comboBox_TextAlign.TabIndex = 16;
            this.comboBox_TextAlign.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // comboBox_Hide
            // 
            this.comboBox_Hide.FormattingEnabled = true;
            this.comboBox_Hide.Items.AddRange(new object[] {
            "True",
            "False"});
            this.comboBox_Hide.Location = new System.Drawing.Point(96, 256);
            this.comboBox_Hide.Name = "comboBox_Hide";
            this.comboBox_Hide.Size = new System.Drawing.Size(127, 20);
            this.comboBox_Hide.TabIndex = 27;
            this.comboBox_Hide.SelectedIndexChanged += new System.EventHandler(this.comboBox_Hide_SelectedIndexChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(12, 259);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(54, 12);
            this.label11.TabIndex = 26;
            this.label11.Text = "▶ Hide :";
            // 
            // PointProperty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(245, 320);
            this.Controls.Add(this.comboBox_Hide);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.comboBox_TextAlign);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.Button_TextColorDlg);
            this.Controls.Add(this.TextBox_TextColor);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.checkBox_ShowName);
            this.Controls.Add(this.textBox_PointSize);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.ButtonApply);
            this.Controls.Add(this.Button_ColorDlg);
            this.Controls.Add(this.comboBox_Style);
            this.Controls.Add(this.TextBox_PointColor);
            this.Controls.Add(this.TextBox_Name);
            this.Controls.Add(this.TextBox_ID);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PointProperty";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Point Property";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.PointProperty_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox TextBox_ID;
        private System.Windows.Forms.TextBox TextBox_Name;
        private System.Windows.Forms.TextBox TextBox_PointColor;
        private System.Windows.Forms.Button Button_ColorDlg;
        private System.Windows.Forms.ComboBox comboBox_Style;
        private System.Windows.Forms.Button ButtonApply;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.TextBox textBox_PointSize;
        private System.Windows.Forms.CheckBox checkBox_ShowName;
        private System.Windows.Forms.Button Button_TextColorDlg;
        private System.Windows.Forms.TextBox TextBox_TextColor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox_TextAlign;
        private System.Windows.Forms.ComboBox comboBox_Hide;
        private System.Windows.Forms.Label label11;
    }
}