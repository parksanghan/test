﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using Pixoneer.NXDL;
using Pixoneer.NXDL.NSCENE;
using Pixoneer.NXDL.NCC;
using Pixoneer.NXDL.NXPlanet;

namespace SceneEditor
{
    public partial class MainForm : Form
    {

        public enum _Tag_TreeKey_
        {
            [Description("POINT")]       _TREE_KEY_POINT,
            [Description("POLYLINE")]    _TREE_KEY_POLYLINE,
            [Description("POLYGON")]     _TREE_KEY_POLYGON,
            [Description("CIRCLE")]      _TREE_KEY_CIRCLE,
            [Description("SYMBOL")]       _TREE_KEY_SYMBOL,
            [Description("TEXT")]      _TREE_KEY_TEXT,
        };

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            InitialTreeControl();

            nxPlanetView2D.AddRenderLayer(ref nxPlanetLayer2D);
            nxPlanetLayerSceneEditor.AttachTo(nxPlanetView2D);

            nxPlanetLayerSceneEditor.OnObjectHitTestObjs += new NXPlanetLayerSceneEditor_Event_HitTestObjs(nxPlanetLayerSceneEditor_OnObjectHitTestObjs);
            nxPlanetLayerSceneDisplay3D.AttachTo(nxPlanetView3D);

            nxPlanetView2D.GridType = NXPlanetView.eGridType.GridDegrees;
            nxPlanetView2D.ShowGrid = true;
            nxPlanetView2D.ShowStatusInfo = true;

            XGeoPoint pos = new XGeoPoint();
            pos.latd = 37.5;
            pos.lond = 127.5;
            pos.hgt = 2000000.0;
            nxPlanetView2D.SetCameraPosition(pos, XAngle.FromDegree(0.0));
            nxPlanetView2D.Rotatable = false;
            pos.hgt = 1050000.0;
            nxPlanetView3D.SetCameraPosition(pos, XAngle.FromDegree(0.0), XAngle.FromDegree(-90.0), XAngle.FromDegree(0.0));
            radioButton_OrderDefault.Checked = true;

            nxPlanetView2D.AutoFocus = false;

            nxPlanetLayerSceneEditor.HitTestableScene = true;

            nxPlanetView3D.ShowStatusInfo = true;
        }

        bool nxPlanetLayerSceneEditor_OnObjectHitTestObjs(int[] objID, int size)
        {
            for (int i = 0; i < size; i++)
            {
                System.Diagnostics.Debug.WriteLine("ObjID : " + objID[i].ToString());
            }

            return default(bool);
        }

        public static string GetEnumDescription(Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            DescriptionAttribute[] attributes =
                (DescriptionAttribute[])fi.GetCustomAttributes(
                typeof(DescriptionAttribute),
                false);

            if (attributes != null &&
                attributes.Length > 0)
                return attributes[0].Description;
            else
                return value.ToString();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Xfn.Close();
        }

        private bool nxPlanetLayer2D_OnRender(object sender, Pixoneer.NXDL.NXPlanet.NXPlanetDrawArgs e)
        {
            return default(bool);
        }

        private bool nxPlanetLayerSceneEditor_OnObjectEditOver(Pixoneer.NXDL.NSCENE.XscObj pObj)
        {
            return default(bool);
        }

        private bool nxPlanetLayerSceneEditor_OnObjectCreated(Pixoneer.NXDL.NSCENE.XscObj pObj)
        {
            if (pObj == null) return false;
            if (pObj.GetTypeName() == "XscPoint")
            {
                XscPoint ob = (XscPoint)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POINT);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscPolyLine")
            {
                XscPolyLine ob = (XscPolyLine)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POLYLINE);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscPolygon")
            {
                XscPolygon ob = (XscPolygon)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_POLYGON);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscCircle")
            {
                XscCircle ob = (XscCircle)pObj;
                
                
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_CIRCLE);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscSymbol")
            {
                XscSymbol ob = (XscSymbol)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_SYMBOL);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else if (pObj.GetTypeName() == "XscText")
            {
                XscText ob = (XscText)pObj;
                ob.VisibleDistMax = -1.0;
                ob.VisibleDistMin = -1.0;
                string strError = "";
                string strKey = GetEnumDescription(_Tag_TreeKey_._TREE_KEY_TEXT);
                string itemID = string.Format("{0}", pObj.ObjID);
                if (AddTreeNode(strKey, itemID, ref strError) == false)
                {
                    MessageBox.Show(strError, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            UpdateListView();
            return default(bool);
        }

        private void Button_SaveScene_Click(object sender, EventArgs e)
        {
            XScene scene = nxPlanetLayerSceneEditor.GetScene();
            if (scene == null || scene.GetNextID() == 0)
            {
                MessageBox.Show("편집중인 Scene이 없습니다.", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            SaveFileDialog saveScene = new SaveFileDialog();
            saveScene.Title = "Save Scene File";
            saveScene.DefaultExt = "sml";
            saveScene.Filter = "Scene Files|*.sml";
            XSpatialReference sr = null;
            sr = new XSpatialReference();
            sr.SetWellKnownGeogCS("WGS84");
            
            if (saveScene.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                bool bres = XScene.SaveScene(scene, saveScene.FileName, sr);
                if( bres )
                    MessageBox.Show("Scene File Save Succeed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Scene File Save Failed", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);   
            }
        }

        private void Button_LoadScene_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Scene Files|*.sml";
            openFileDialog1.Title = "Select Scene File";

            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                bool bres = nxPlanetLayerSceneDisplay3D.Open(openFileDialog1.FileName);
                if (bres == true)
                    MessageBox.Show("Scene File Load Succeed", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Scene File Load Failed", "오류", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
            }
        }

        private int GetCameraString(double value)
        {
            double five = 1006.66891525667;
            double ten = 2013.33783051335;
            double two = 5033.34457628336;
            if (value < five)
                return 5000;
            else if (value < ten)
                return 10000;
            else if (value < two)
                return 25000;

            else if (value < five * 10)
                return 50000;
            else if (value < ten * 10)
                return 100000;
            else if (value < two * 10)
                return 250000;

            else if (value < five * 100)
                return 500000;
            else if (value < ten * 100)
                return 1000000;
            else if (value < two * 100)
                return 2500000;

            else if (value < five * 1000)
                return 5000000;
            else if (value < ten * 1000)
                return 10000000;
            else if (value < two * 1000)
                return 25000000;

            else if (value < five * 10000)
                return 50000000;
            else if (value < ten * 10000)
                return 100000000;
            else if (value < two * 10000)
                return 250000000;
            else
                return 0;
        }


        private double GetMoveTable()
        {
            NXCameraState statue = nxPlanetView2D.GetCameraState();
            return GetCameraString(statue.hgtEye) / 5000000.0;
        }

        private void toolStripButtonLeft_Click(object sender, EventArgs e)
        {
            NXCameraState state = nxPlanetView2D.GetCameraState();
            nxPlanetView2D.SetCameraPosition(XGeoPoint.FromDegree(state.lonEye.deg - GetMoveTable(), state.latEye.deg, state.hgtEye), XAngle.FromDegree(0)); 
        }

        private void toolStripButtonRight_Click(object sender, EventArgs e)
        {
            NXCameraState state = nxPlanetView2D.GetCameraState();
            nxPlanetView2D.SetCameraPosition(XGeoPoint.FromDegree(state.lonEye.deg + GetMoveTable(), state.latEye.deg, state.hgtEye), XAngle.FromDegree(0)); 
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            NXCameraState state = nxPlanetView2D.GetCameraState();
            nxPlanetView2D.SetCameraPosition(XGeoPoint.FromDegree(state.lonEye.deg, state.latEye.deg + GetMoveTable(), state.hgtEye), XAngle.FromDegree(0)); 
        }

        private void toolStripButtonDown_Click(object sender, EventArgs e)
        {
            NXCameraState state = nxPlanetView2D.GetCameraState();
            nxPlanetView2D.SetCameraPosition(XGeoPoint.FromDegree(state.lonEye.deg, state.latEye.deg - GetMoveTable(), state.hgtEye), XAngle.FromDegree(0)); 
        }
    }
}
