﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Pixoneer.NXDL.NEQUIP;
using System.Collections;
using Pixoneer.NXDL;
using Pixoneer.NXDL.NXPlanet;
using Pixoneer.NXDL.NGR;
using Pixoneer.NXDL.NNCW;
using System.IO;
using System.Threading;

namespace PlanetNCW
{
    public class MyModel : XAircraft
    {
        public ArrayList m_Positions;
        private Object thisLock = new Object();
        public String m_strDataFile = String.Empty;
        public String m_strModelFile = String.Empty;
        public String m_strName = String.Empty;
        public UInt32 m_nID = 0;
        public Boolean m_showBoundingBox = false;
        public XncwObserver.eViewMode m_CamMode = XncwObserver.eViewMode.Unusable;
        private FileStream m_DatafileStream = null;
        private BufferedStream m_BufferStream = null;
        private Thread m_thread = null;
        private bool m_bRunThread = false;

        public MyModel()
        {
            m_Positions = new ArrayList();
        }
        public bool Initialize(String modelFileName, String name, UInt32 id, String dataFileName)
        {
            bool bRes = false;
            bRes = LoadModel(modelFileName);
            if (bRes == false)
                return false;

            m_strName = name;
            m_nID = id;
            m_strDataFile = dataFileName;

            FileInfo _finfo = null;
            if (String.Compare(dataFileName, "") != 0)
            {
                _finfo = new FileInfo(dataFileName);
            }

            if (_finfo == null)
            {
                return false;
            }

            m_DatafileStream = new System.IO.FileStream(m_strDataFile, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            m_BufferStream = new System.IO.BufferedStream(m_DatafileStream);
            return true;
        }

        public bool UnInitialize()
        {
            if (m_thread != null)
            {
                m_bRunThread = false;
                if (m_thread.IsAlive == true)
                    m_thread.Join();
                m_thread = null;
            }

            clearPosition();
            if (m_BufferStream != null) m_BufferStream.Close();
            if (m_DatafileStream != null) m_DatafileStream.Close();
            return true;
        }

        public void Start()
        {
            if (m_thread != null) return;
            m_thread = new Thread(SimulationThread);
            m_thread.Start();
        }

        public void Restart()
        {
            UnInitialize();

            m_DatafileStream = new System.IO.FileStream(m_strDataFile, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            m_BufferStream = new System.IO.BufferedStream(m_DatafileStream);
            Start();
        }

        public void clearPosition()
        {
            lock (thisLock)
            {
                m_Positions.Clear();
            }
        }

        public override bool SetPosition(XGeoPoint pos)
        {
            if (pos == null) return false;

            lock (thisLock)
            {
                m_Positions.Add(pos);
                if (m_Positions.Count > 200)
                    m_Positions.RemoveAt(0);
            }

            return base.SetPosition(pos);
        }

        public override bool DrawOver(NXPlanetDrawArgs DrawArgs, XGeoPoint gpPos)
        {
            XGraphics g = DrawArgs.Graphics;
            g.glDisable(XGraphics.GL_TEXTURE_2D);
            g.glEnable(XGraphics.GL_LINE_SMOOTH);
            g.glEnable(XGraphics.GL_BLEND);
            g.glBlendFunc(XGraphics.GL_SRC_ALPHA, XGraphics.GL_ONE_MINUS_SRC_ALPHA);

            g.glDisable(XGraphics.GL_DEPTH_TEST);
            g.glLineWidth(3.0);
            g.glColor4d(1.0, 1.0, 0.0, 0.8);
            g.glBegin(XGraphics.GL_LINE_STRIP);

            lock (thisLock)
            {
                XVertex3d mp = new XVertex3d();
                for (int i = 0; i < m_Positions.Count; i++)
                {
                    XGeoPoint gp = (XGeoPoint)m_Positions[i];
                    if (gp == null) continue;
                    if (DrawArgs.ViewArea.EarthMode == NXPlanetView.eEarthMode.Planet2D)
                    {
                        mp = gp.eec;
                        mp.z = 0.0;
                        g.xglVertex3d(mp);
                    }
                    else if (DrawArgs.ViewArea.EarthMode == NXPlanetView.eEarthMode.Planet3D)
                    {
                        g.xglVertex3d(gp.ecr);
                    }

                }
            }
            g.glEnd();
            g.glLineWidth(1.0);
            g.glDisable(XGraphics.GL_BLEND);
            g.glDisable(XGraphics.GL_LINE_SMOOTH);
            g.glEnable(XGraphics.GL_DEPTH_TEST);

            return true;
        }

        public void SimulationThread()
        {
            if (m_DatafileStream == null)
                return;

            if (m_BufferStream == null)
                return;

            m_bRunThread = true;

            int frameDataSize = 14 * 4;
            long dataSize = m_DatafileStream.Length / frameDataSize;
            byte[] buff = new byte[frameDataSize];

            while (m_bRunThread)
            {
                int nIndex = 0;
                int count = 0;
                m_BufferStream.Seek(0, System.IO.SeekOrigin.Begin);

                do
                {

                    if (!m_bRunThread) break;

                    count = m_BufferStream.Read(buff, 0, 14 * 4);

                    double speed = BitConverter.ToSingle(buff, 0);

                    double lon = BitConverter.ToSingle(buff, 8);     // lon
                    double lat = BitConverter.ToSingle(buff, 4);     // lat
                    double alt = BitConverter.ToSingle(buff, 12);   // alt

                    double yaw = BitConverter.ToSingle(buff, 16);    //yaw
                    double roll = BitConverter.ToSingle(buff, 20);   //roll
                    double pitch = BitConverter.ToSingle(buff, 24);  //pitch

                    XGeoPoint geoPos = new XGeoPoint();

                    geoPos.lond = lon;
                    geoPos.latd = lat;
                    geoPos.hgt = alt;
                    this.SetPosition(geoPos);

                    this.SetYawPitchRoll(XAngle.FromDegree(yaw), XAngle.FromDegree(pitch), XAngle.FromDegree(roll));
                    Thread.Sleep(100);

                    nIndex++;
                }
                while (((count == frameDataSize) && (nIndex < dataSize)));
                Thread.Sleep(100);
            }

        }
    }
}
