﻿namespace PlanetNCW
{
    partial class MainForm
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다.
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마십시오.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            Pixoneer.NXDL.XAngle xAngle1 = new Pixoneer.NXDL.XAngle();
            Pixoneer.NXDL.XAngle xAngle2 = new Pixoneer.NXDL.XAngle();
            this.toolBar = new System.Windows.Forms.ToolStrip();
            this.m_button_AddPlane = new System.Windows.Forms.ToolStripButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.m_listView = new System.Windows.Forms.ListView();
            this.columnHeader_Show = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader_Name = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.nxPlanetView2D = new Pixoneer.NXDL.NXPlanet.NXPlanetView();
            this.nxPlanetView3D = new Pixoneer.NXDL.NXPlanet.NXPlanetView();
            this.xncwTheater = new Pixoneer.NXDL.NNCW.XncwTheater();
            this.xncwObserver2D = new Pixoneer.NXDL.NNCW.XncwObserver();
            this.xncwObserver3D = new Pixoneer.NXDL.NNCW.XncwObserver();
            this.toolBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolBar
            // 
            this.toolBar.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.m_button_AddPlane});
            this.toolBar.Location = new System.Drawing.Point(0, 0);
            this.toolBar.Name = "toolBar";
            this.toolBar.Size = new System.Drawing.Size(1353, 25);
            this.toolBar.TabIndex = 0;
            this.toolBar.Text = "toolStrip1";
            // 
            // m_button_AddPlane
            // 
            this.m_button_AddPlane.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.m_button_AddPlane.Image = ((System.Drawing.Image)(resources.GetObject("m_button_AddPlane.Image")));
            this.m_button_AddPlane.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.m_button_AddPlane.Name = "m_button_AddPlane";
            this.m_button_AddPlane.Size = new System.Drawing.Size(66, 22);
            this.m_button_AddPlane.Text = "Add Plane";
            this.m_button_AddPlane.Click += new System.EventHandler(this.m_button_AddPlane_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 25);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.m_listView);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1353, 608);
            this.splitContainer1.SplitterDistance = 353;
            this.splitContainer1.TabIndex = 1;
            // 
            // m_listView
            // 
            this.m_listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader_Show,
            this.columnHeader_ID,
            this.columnHeader_Name});
            this.m_listView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.m_listView.HideSelection = false;
            this.m_listView.Location = new System.Drawing.Point(0, 0);
            this.m_listView.Name = "m_listView";
            this.m_listView.Size = new System.Drawing.Size(353, 608);
            this.m_listView.TabIndex = 0;
            this.m_listView.UseCompatibleStateImageBehavior = false;
            this.m_listView.View = System.Windows.Forms.View.Details;
            this.m_listView.ItemChecked += new System.Windows.Forms.ItemCheckedEventHandler(this.m_listView_ItemChecked);
            this.m_listView.MouseDown += new System.Windows.Forms.MouseEventHandler(this.m_listView_MouseDown);
            // 
            // columnHeader_Show
            // 
            this.columnHeader_Show.Text = "Show";
            // 
            // columnHeader_ID
            // 
            this.columnHeader_ID.Text = "ID";
            this.columnHeader_ID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // columnHeader_Name
            // 
            this.columnHeader_Name.Text = "Name";
            this.columnHeader_Name.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.nxPlanetView2D);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.nxPlanetView3D);
            this.splitContainer2.Size = new System.Drawing.Size(996, 608);
            this.splitContainer2.SplitterDistance = 493;
            this.splitContainer2.TabIndex = 0;
            // 
            // nxPlanetView2D
            // 
            this.nxPlanetView2D.AutoFocus = false;
            this.nxPlanetView2D.AutoRefreshRate = 0;
            this.nxPlanetView2D.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.nxPlanetView2D.Brightness = 1F;
            this.nxPlanetView2D.CallbackMode = true;
            this.nxPlanetView2D.Contrast = 1F;
            this.nxPlanetView2D.DisplayMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eDisplayMode.DisplayNormal;
            this.nxPlanetView2D.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nxPlanetView2D.EarthMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eEarthMode.Planet2D;
            this.nxPlanetView2D.ForceDraw = false;
            this.nxPlanetView2D.FrameCapture = null;
            this.nxPlanetView2D.GridType = Pixoneer.NXDL.NXPlanet.NXPlanetView.eGridType.GridDegrees;
            this.nxPlanetView2D.HeightFactor = 1F;
            this.nxPlanetView2D.InverseMouseButton = false;
            this.nxPlanetView2D.InverseMouseWheel = false;
            this.nxPlanetView2D.LayoutMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eLayoutMode.Windows;
            this.nxPlanetView2D.Location = new System.Drawing.Point(0, 0);
            this.nxPlanetView2D.Name = "nxPlanetView2D";
            this.nxPlanetView2D.RelativeHeight = 1D;
            this.nxPlanetView2D.RelativeLeft = 0D;
            this.nxPlanetView2D.RelativeTop = 0D;
            this.nxPlanetView2D.RelativeWidth = 1D;
            this.nxPlanetView2D.RestrictRenerArea = false;
            this.nxPlanetView2D.Rotatable = true;
            this.nxPlanetView2D.Saturation = 1F;
            this.nxPlanetView2D.ShowControlPoint = true;
            this.nxPlanetView2D.ShowGrid = true;
            this.nxPlanetView2D.ShowPBP = true;
            this.nxPlanetView2D.ShowPBV = true;
            this.nxPlanetView2D.ShowStatusInfo = false;
            this.nxPlanetView2D.SingleBaseMap = false;
            this.nxPlanetView2D.Size = new System.Drawing.Size(493, 608);
            this.nxPlanetView2D.TabIndex = 0;
            this.nxPlanetView2D.ToolboxAreaUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxAreaUnit.SquareMeter;
            this.nxPlanetView2D.ToolboxDistUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxDistUnit.Meter;
            this.nxPlanetView2D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.None;
            xAngle1.deg = 45D;
            this.nxPlanetView2D.ViewAreaFOV = xAngle1;
            this.nxPlanetView2D.ViewAreaID = -1;
            this.nxPlanetView2D.ZoomCenterMode = Pixoneer.NXDL.eViewZoomCenterMode.CenterByCursor;
            this.nxPlanetView2D.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.nxPlanetView2D_MouseDoubleClick);
            // 
            // nxPlanetView3D
            // 
            this.nxPlanetView3D.AutoFocus = false;
            this.nxPlanetView3D.AutoRefreshRate = 0;
            this.nxPlanetView3D.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.nxPlanetView3D.Brightness = 1F;
            this.nxPlanetView3D.CallbackMode = true;
            this.nxPlanetView3D.Contrast = 1F;
            this.nxPlanetView3D.DisplayMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eDisplayMode.DisplayNormal;
            this.nxPlanetView3D.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nxPlanetView3D.EarthMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eEarthMode.Planet3D;
            this.nxPlanetView3D.ForceDraw = false;
            this.nxPlanetView3D.FrameCapture = null;
            this.nxPlanetView3D.GridType = Pixoneer.NXDL.NXPlanet.NXPlanetView.eGridType.GridDegrees;
            this.nxPlanetView3D.HeightFactor = 1F;
            this.nxPlanetView3D.InverseMouseButton = false;
            this.nxPlanetView3D.InverseMouseWheel = false;
            this.nxPlanetView3D.LayoutMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eLayoutMode.Windows;
            this.nxPlanetView3D.Location = new System.Drawing.Point(0, 0);
            this.nxPlanetView3D.Name = "nxPlanetView3D";
            this.nxPlanetView3D.RelativeHeight = 1D;
            this.nxPlanetView3D.RelativeLeft = 0D;
            this.nxPlanetView3D.RelativeTop = 0D;
            this.nxPlanetView3D.RelativeWidth = 1D;
            this.nxPlanetView3D.RestrictRenerArea = false;
            this.nxPlanetView3D.Rotatable = true;
            this.nxPlanetView3D.Saturation = 1F;
            this.nxPlanetView3D.ShowControlPoint = true;
            this.nxPlanetView3D.ShowGrid = true;
            this.nxPlanetView3D.ShowPBP = true;
            this.nxPlanetView3D.ShowPBV = true;
            this.nxPlanetView3D.ShowStatusInfo = false;
            this.nxPlanetView3D.SingleBaseMap = false;
            this.nxPlanetView3D.Size = new System.Drawing.Size(499, 608);
            this.nxPlanetView3D.TabIndex = 0;
            this.nxPlanetView3D.ToolboxAreaUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxAreaUnit.SquareMeter;
            this.nxPlanetView3D.ToolboxDistUnit = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxDistUnit.Meter;
            this.nxPlanetView3D.ToolboxMode = Pixoneer.NXDL.NXPlanet.NXPlanetView.eToolboxMode.None;
            xAngle2.deg = 45D;
            this.nxPlanetView3D.ViewAreaFOV = xAngle2;
            this.nxPlanetView3D.ViewAreaID = -1;
            this.nxPlanetView3D.ZoomCenterMode = Pixoneer.NXDL.eViewZoomCenterMode.CenterByCursor;
            // 
            // xncwTheater
            // 
            this.xncwTheater.AutoDelete = true;
            this.xncwTheater.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.xncwTheater.LayerCapture = true;
            this.xncwTheater.LayerVisible = true;
            this.xncwTheater.Location = new System.Drawing.Point(0, 0);
            this.xncwTheater.Name = "xncwTheater";
            this.xncwTheater.Size = new System.Drawing.Size(145, 30);
            this.xncwTheater.TabIndex = 0;
            this.xncwTheater.UseDisplayList = true;
            this.xncwTheater.Visible = false;
            // 
            // xncwObserver2D
            // 
            this.xncwObserver2D.AutoDelete = true;
            this.xncwObserver2D.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.xncwObserver2D.FollowViewMaxZoom = false;
            this.xncwObserver2D.InverseMouseButton = false;
            this.xncwObserver2D.LayerCapture = true;
            this.xncwObserver2D.LayerVisible = true;
            this.xncwObserver2D.Location = new System.Drawing.Point(0, 0);
            this.xncwObserver2D.Name = "xncwObserver2D";
            this.xncwObserver2D.Size = new System.Drawing.Size(145, 30);
            this.xncwObserver2D.TabIndex = 0;
            this.xncwObserver2D.UseDisplayList = true;
            this.xncwObserver2D.Visible = false;
            // 
            // xncwObserver3D
            // 
            this.xncwObserver3D.AutoDelete = true;
            this.xncwObserver3D.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.xncwObserver3D.FollowViewMaxZoom = false;
            this.xncwObserver3D.InverseMouseButton = false;
            this.xncwObserver3D.LayerCapture = true;
            this.xncwObserver3D.LayerVisible = true;
            this.xncwObserver3D.Location = new System.Drawing.Point(0, 0);
            this.xncwObserver3D.Name = "xncwObserver3D";
            this.xncwObserver3D.Size = new System.Drawing.Size(145, 30);
            this.xncwObserver3D.TabIndex = 0;
            this.xncwObserver3D.UseDisplayList = true;
            this.xncwObserver3D.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1353, 633);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolBar);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "PlanetNCW";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.toolBar.ResumeLayout(false);
            this.toolBar.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion

        private System.Windows.Forms.ToolStrip toolBar;
        private System.Windows.Forms.ToolStripButton m_button_AddPlane;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.ListView m_listView;
        private System.Windows.Forms.ColumnHeader columnHeader_Show;
        private System.Windows.Forms.ColumnHeader columnHeader_ID;
        private System.Windows.Forms.ColumnHeader columnHeader_Name;
        private Pixoneer.NXDL.NXPlanet.NXPlanetView nxPlanetView2D;
        private Pixoneer.NXDL.NXPlanet.NXPlanetView nxPlanetView3D;
        private Pixoneer.NXDL.NNCW.XncwTheater xncwTheater;
        private Pixoneer.NXDL.NNCW.XncwObserver xncwObserver2D;
        private Pixoneer.NXDL.NNCW.XncwObserver xncwObserver3D;
    }
}

