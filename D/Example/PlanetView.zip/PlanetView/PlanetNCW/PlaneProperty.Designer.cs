﻿namespace PlanetNCW
{
    partial class PlaneProperty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PlaneProperty));
            this.textBox_DataFilePath = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TextBox_ModelFile = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.TextBox_Name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.TextBox_ID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.ButtonApply = new System.Windows.Forms.Button();
            this.m_checkBox_Scalable = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textbox_zScale = new System.Windows.Forms.TextBox();
            this.textbox_yScale = new System.Windows.Forms.TextBox();
            this.textbox_xScale = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox_CameraMode = new System.Windows.Forms.ComboBox();
            this.m_checkBox_ShowBoundingBox = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox_DataFilePath
            // 
            this.textBox_DataFilePath.Location = new System.Drawing.Point(100, 116);
            this.textBox_DataFilePath.Name = "textBox_DataFilePath";
            this.textBox_DataFilePath.ReadOnly = true;
            this.textBox_DataFilePath.Size = new System.Drawing.Size(131, 21);
            this.textBox_DataFilePath.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(16, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 12);
            this.label3.TabIndex = 21;
            this.label3.Text = "▶ Data :";
            // 
            // TextBox_ModelFile
            // 
            this.TextBox_ModelFile.Location = new System.Drawing.Point(100, 85);
            this.TextBox_ModelFile.Name = "TextBox_ModelFile";
            this.TextBox_ModelFile.ReadOnly = true;
            this.TextBox_ModelFile.Size = new System.Drawing.Size(131, 21);
            this.TextBox_ModelFile.TabIndex = 20;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 12);
            this.label4.TabIndex = 19;
            this.label4.Text = "▶ Model :";
            // 
            // TextBox_Name
            // 
            this.TextBox_Name.Location = new System.Drawing.Point(100, 49);
            this.TextBox_Name.Name = "TextBox_Name";
            this.TextBox_Name.ReadOnly = true;
            this.TextBox_Name.Size = new System.Drawing.Size(131, 21);
            this.TextBox_Name.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 12);
            this.label2.TabIndex = 17;
            this.label2.Text = "▶ Name :";
            // 
            // TextBox_ID
            // 
            this.TextBox_ID.Location = new System.Drawing.Point(100, 12);
            this.TextBox_ID.Name = "TextBox_ID";
            this.TextBox_ID.ReadOnly = true;
            this.TextBox_ID.Size = new System.Drawing.Size(131, 21);
            this.TextBox_ID.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 12);
            this.label1.TabIndex = 15;
            this.label1.Text = "▶ ID :";
            // 
            // button_Cancel
            // 
            this.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Cancel.Location = new System.Drawing.Point(172, 356);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(59, 25);
            this.button_Cancel.TabIndex = 24;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // ButtonApply
            // 
            this.ButtonApply.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.ButtonApply.Location = new System.Drawing.Point(101, 356);
            this.ButtonApply.Name = "ButtonApply";
            this.ButtonApply.Size = new System.Drawing.Size(59, 25);
            this.ButtonApply.TabIndex = 23;
            this.ButtonApply.Text = "Apply";
            this.ButtonApply.UseVisualStyleBackColor = true;
            this.ButtonApply.Click += new System.EventHandler(this.ButtonApply_Click);
            // 
            // m_checkBox_Scalable
            // 
            this.m_checkBox_Scalable.AutoSize = true;
            this.m_checkBox_Scalable.Location = new System.Drawing.Point(14, 59);
            this.m_checkBox_Scalable.Name = "m_checkBox_Scalable";
            this.m_checkBox_Scalable.Size = new System.Drawing.Size(73, 16);
            this.m_checkBox_Scalable.TabIndex = 25;
            this.m_checkBox_Scalable.Text = "Scalable";
            this.m_checkBox_Scalable.UseVisualStyleBackColor = true;
            this.m_checkBox_Scalable.CheckedChanged += new System.EventHandler(this.m_checkBox_Scalable_CheckedChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textbox_zScale);
            this.groupBox1.Controls.Add(this.m_checkBox_Scalable);
            this.groupBox1.Controls.Add(this.textbox_yScale);
            this.groupBox1.Controls.Add(this.textbox_xScale);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Location = new System.Drawing.Point(11, 147);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(218, 120);
            this.groupBox1.TabIndex = 26;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "▶ Scale";
            // 
            // textbox_zScale
            // 
            this.textbox_zScale.Location = new System.Drawing.Point(173, 24);
            this.textbox_zScale.Name = "textbox_zScale";
            this.textbox_zScale.Size = new System.Drawing.Size(40, 21);
            this.textbox_zScale.TabIndex = 29;
            // 
            // textbox_yScale
            // 
            this.textbox_yScale.Location = new System.Drawing.Point(102, 24);
            this.textbox_yScale.Name = "textbox_yScale";
            this.textbox_yScale.Size = new System.Drawing.Size(40, 21);
            this.textbox_yScale.TabIndex = 28;
            // 
            // textbox_xScale
            // 
            this.textbox_xScale.Location = new System.Drawing.Point(30, 24);
            this.textbox_xScale.Name = "textbox_xScale";
            this.textbox_xScale.Size = new System.Drawing.Size(40, 21);
            this.textbox_xScale.TabIndex = 27;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(155, 27);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(12, 12);
            this.label7.TabIndex = 2;
            this.label7.Text = "z";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(84, 27);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(12, 12);
            this.label6.TabIndex = 1;
            this.label6.Text = "y";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 27);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(12, 12);
            this.label5.TabIndex = 0;
            this.label5.Text = "x";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(16, 287);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 12);
            this.label8.TabIndex = 21;
            this.label8.Text = "▶ Camera Mode :";
            // 
            // comboBox_CameraMode
            // 
            this.comboBox_CameraMode.FormattingEnabled = true;
            this.comboBox_CameraMode.Items.AddRange(new object[] {
            "Back view.",
            "Front view.",
            "Left view.",
            "Right view.",
            "God\'s eye view.",
            "God\'s eye view static.",
            "Bottom view.",
            "Bottom view static.",
            "Inside view.",
            "Inside view free.",
            "Far view.",
            "Unusable."});
            this.comboBox_CameraMode.Location = new System.Drawing.Point(132, 282);
            this.comboBox_CameraMode.Name = "comboBox_CameraMode";
            this.comboBox_CameraMode.Size = new System.Drawing.Size(97, 20);
            this.comboBox_CameraMode.TabIndex = 27;
            // 
            // m_checkBox_ShowBoundingBox
            // 
            this.m_checkBox_ShowBoundingBox.AutoSize = true;
            this.m_checkBox_ShowBoundingBox.Location = new System.Drawing.Point(19, 323);
            this.m_checkBox_ShowBoundingBox.Name = "m_checkBox_ShowBoundingBox";
            this.m_checkBox_ShowBoundingBox.Size = new System.Drawing.Size(139, 16);
            this.m_checkBox_ShowBoundingBox.TabIndex = 25;
            this.m_checkBox_ShowBoundingBox.Text = "Show Bounding Box";
            this.m_checkBox_ShowBoundingBox.UseVisualStyleBackColor = true;
            this.m_checkBox_ShowBoundingBox.CheckedChanged += new System.EventHandler(this.m_checkBox_ShowBoundingBox_CheckedChanged);
            // 
            // PlaneProperty
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(249, 401);
            this.Controls.Add(this.comboBox_CameraMode);
            this.Controls.Add(this.m_checkBox_ShowBoundingBox);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.ButtonApply);
            this.Controls.Add(this.textBox_DataFilePath);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TextBox_ModelFile);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TextBox_Name);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TextBox_ID);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PlaneProperty";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "PlaneProperty";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.PlaneProperty_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_DataFilePath;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TextBox_ModelFile;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox TextBox_Name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TextBox_ID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.Button ButtonApply;
        private System.Windows.Forms.CheckBox m_checkBox_Scalable;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textbox_zScale;
        private System.Windows.Forms.TextBox textbox_yScale;
        private System.Windows.Forms.TextBox textbox_xScale;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox_CameraMode;
        private System.Windows.Forms.CheckBox m_checkBox_ShowBoundingBox;
    }
}