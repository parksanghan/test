﻿namespace PlanetNCW
{
    partial class AddPlaneForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddPlaneForm));
            this.TextBox_ID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.TextBox_Name = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.Button_LoadModel = new System.Windows.Forms.Button();
            this.TextBox_ModelFile = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Button_LoadDataFile = new System.Windows.Forms.Button();
            this.textBox_DataFilePath = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button_Cancel = new System.Windows.Forms.Button();
            this.ButtonApply = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TextBox_ID
            // 
            this.TextBox_ID.Location = new System.Drawing.Point(101, 12);
            this.TextBox_ID.Name = "TextBox_ID";
            this.TextBox_ID.ReadOnly = true;
            this.TextBox_ID.Size = new System.Drawing.Size(131, 21);
            this.TextBox_ID.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 12);
            this.label1.TabIndex = 6;
            this.label1.Text = "▶ ID :";
            // 
            // TextBox_Name
            // 
            this.TextBox_Name.Location = new System.Drawing.Point(101, 49);
            this.TextBox_Name.Name = "TextBox_Name";
            this.TextBox_Name.Size = new System.Drawing.Size(131, 21);
            this.TextBox_Name.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 12);
            this.label2.TabIndex = 8;
            this.label2.Text = "▶ Name :";
            // 
            // Button_LoadModel
            // 
            this.Button_LoadModel.Location = new System.Drawing.Point(201, 86);
            this.Button_LoadModel.Name = "Button_LoadModel";
            this.Button_LoadModel.Size = new System.Drawing.Size(27, 19);
            this.Button_LoadModel.TabIndex = 12;
            this.Button_LoadModel.Text = "...";
            this.Button_LoadModel.UseVisualStyleBackColor = true;
            this.Button_LoadModel.Click += new System.EventHandler(this.Button_LoadModel_Click);
            // 
            // TextBox_ModelFile
            // 
            this.TextBox_ModelFile.Location = new System.Drawing.Point(101, 85);
            this.TextBox_ModelFile.Name = "TextBox_ModelFile";
            this.TextBox_ModelFile.ReadOnly = true;
            this.TextBox_ModelFile.Size = new System.Drawing.Size(94, 21);
            this.TextBox_ModelFile.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 88);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "▶ Model :";
            // 
            // Button_LoadDataFile
            // 
            this.Button_LoadDataFile.Location = new System.Drawing.Point(201, 117);
            this.Button_LoadDataFile.Name = "Button_LoadDataFile";
            this.Button_LoadDataFile.Size = new System.Drawing.Size(27, 19);
            this.Button_LoadDataFile.TabIndex = 15;
            this.Button_LoadDataFile.Text = "...";
            this.Button_LoadDataFile.UseVisualStyleBackColor = true;
            this.Button_LoadDataFile.Click += new System.EventHandler(this.Button_LoadDataFile_Click);
            // 
            // textBox_DataFilePath
            // 
            this.textBox_DataFilePath.Location = new System.Drawing.Point(101, 116);
            this.textBox_DataFilePath.Name = "textBox_DataFilePath";
            this.textBox_DataFilePath.ReadOnly = true;
            this.textBox_DataFilePath.Size = new System.Drawing.Size(94, 21);
            this.textBox_DataFilePath.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 119);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 12);
            this.label3.TabIndex = 13;
            this.label3.Text = "▶ Data :";
            // 
            // button_Cancel
            // 
            this.button_Cancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button_Cancel.Location = new System.Drawing.Point(169, 159);
            this.button_Cancel.Name = "button_Cancel";
            this.button_Cancel.Size = new System.Drawing.Size(59, 25);
            this.button_Cancel.TabIndex = 17;
            this.button_Cancel.Text = "Cancel";
            this.button_Cancel.UseVisualStyleBackColor = true;
            this.button_Cancel.Click += new System.EventHandler(this.button_Cancel_Click);
            // 
            // ButtonApply
            // 
            this.ButtonApply.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.ButtonApply.Location = new System.Drawing.Point(98, 159);
            this.ButtonApply.Name = "ButtonApply";
            this.ButtonApply.Size = new System.Drawing.Size(59, 25);
            this.ButtonApply.TabIndex = 16;
            this.ButtonApply.Text = "Apply";
            this.ButtonApply.UseVisualStyleBackColor = true;
            this.ButtonApply.Click += new System.EventHandler(this.ButtonApply_Click);
            // 
            // AddPlaneForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(243, 205);
            this.Controls.Add(this.button_Cancel);
            this.Controls.Add(this.ButtonApply);
            this.Controls.Add(this.Button_LoadDataFile);
            this.Controls.Add(this.textBox_DataFilePath);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Button_LoadModel);
            this.Controls.Add(this.TextBox_ModelFile);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TextBox_Name);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TextBox_ID);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddPlaneForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "AddPlaneForm";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.AddPlaneForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TextBox_ID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TextBox_Name;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Button_LoadModel;
        private System.Windows.Forms.TextBox TextBox_ModelFile;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button Button_LoadDataFile;
        private System.Windows.Forms.TextBox textBox_DataFilePath;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_Cancel;
        private System.Windows.Forms.Button ButtonApply;
    }
}