﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PlanetNCW
{
    public partial class PlaneProperty : Form
    {
        public UInt32 m_ModelID = 0;
        public String m_Name = String.Empty;
        public String m_ModelFilePath = String.Empty;
        public String m_DataFilePath = String.Empty;
        public Boolean m_scalable = false;
        public Double m_xScale = 1.0;
        public Double m_yScale = 1.0;
        public Double m_zScale = 1.0;
        public UInt32 m_CamMode = 11;   // Unusable;
        public Boolean m_ShowBoundingBox = false;

        public PlaneProperty()
        {
            InitializeComponent();
        }

        private void PlaneProperty_Load(object sender, EventArgs e)
        {
            TextBox_ID.Text = m_ModelID.ToString();

            if (m_Name == String.Empty)
                TextBox_Name.Text = "No Name";
            else TextBox_Name.Text = m_Name;

            if (m_ModelFilePath == String.Empty)
                TextBox_ModelFile.Text = "No Name";
            else TextBox_ModelFile.Text = m_ModelFilePath;

            if (m_DataFilePath == String.Empty)
                textBox_DataFilePath.Text = "No Name";
            else textBox_DataFilePath.Text = m_DataFilePath;

            m_checkBox_Scalable.Checked = m_scalable;
            m_checkBox_ShowBoundingBox.Checked = m_ShowBoundingBox;

            textbox_xScale.Text = m_xScale.ToString();
            textbox_yScale.Text = m_yScale.ToString();
            textbox_zScale.Text = m_zScale.ToString();

            comboBox_CameraMode.SelectedIndex = (int)m_CamMode;
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            m_ModelID = UInt32.Parse(TextBox_ID.Text);

            m_xScale = Double.Parse(textbox_xScale.Text);
            m_yScale = Double.Parse(textbox_yScale.Text);
            m_zScale = Double.Parse(textbox_zScale.Text);

            m_CamMode = (UInt32)comboBox_CameraMode.SelectedIndex;
            DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void m_checkBox_Scalable_CheckedChanged(object sender, EventArgs e)
        {
            m_scalable = m_checkBox_Scalable.Checked;
        }

        private void m_checkBox_ShowBoundingBox_CheckedChanged(object sender, EventArgs e)
        {
            m_ShowBoundingBox = m_checkBox_ShowBoundingBox.Checked;
        }
    }
}
