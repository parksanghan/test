﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PlanetNCW
{
    public partial class AddPlaneForm : Form
    {

        public UInt32 m_ModelID = 0;
        public String m_Name = String.Empty;
        public String m_ModelFilePath = String.Empty;
        public String m_DataFilePath = String.Empty;


        public AddPlaneForm()
        {
            InitializeComponent();
        }

        private void AddPlaneForm_Load(object sender, EventArgs e)
        {
            TextBox_Name.Text = m_Name;
            textBox_DataFilePath.Text = m_DataFilePath;
            TextBox_ModelFile.Text = m_ModelFilePath;
            TextBox_Name.Text = m_Name;
            TextBox_ID.Text = m_ModelID.ToString();
        }

        private void Button_LoadModel_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Model Files|*.3ds";
            openFileDialog1.Title = "Select Model File";

            // Show the Dialog.
            // If the user clicked OK in the dialog and
            // a .CUR file was selected, open it.
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_ModelFilePath = openFileDialog1.FileName;
                TextBox_ModelFile.Text = m_ModelFilePath;
            }
        }

        private void Button_LoadDataFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "Flight Files|*.dat";
            openFileDialog1.Title = "Select Simulation Data File";

            // Show the Dialog.
            // If the user clicked OK in the dialog and
            // a .CUR file was selected, open it.
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                m_DataFilePath = openFileDialog1.FileName;
                textBox_DataFilePath.Text = m_DataFilePath;
            }
        }

        private void ButtonApply_Click(object sender, EventArgs e)
        {
            m_DataFilePath = textBox_DataFilePath.Text;
            m_ModelFilePath = TextBox_ModelFile.Text;
            m_Name = TextBox_Name.Text;
            DialogResult = System.Windows.Forms.DialogResult.OK;
        }

        private void button_Cancel_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }
    }
}
