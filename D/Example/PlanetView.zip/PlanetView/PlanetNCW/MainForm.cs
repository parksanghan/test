﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Pixoneer.NXDL;
using Pixoneer.NXDL.NEQUIP;

using System.Threading;

namespace PlanetNCW
{
    public partial class MainForm : Form
    {
        
        UInt32 m_nModelID = 0;
        List<MyModel> m_ModelList = new List<MyModel>();
        private Thread m_thread = null;
        private bool m_bRunThread = false;

        public UInt32 GetNextModelID()
        {
            return (m_nModelID + 1);
        }
        
        public MainForm()
        {
            InitializeComponent();
        }
        
        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (m_thread != null)
            {
                m_bRunThread = false;
                if (m_thread.IsAlive == true)
                    m_thread.Join();
                m_thread = null;
            }

            foreach (MyModel my in m_ModelList)
            {
                my.UnInitialize();
            }
            m_ModelList.Clear();
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            Xfn.Close();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            bool bRes = false;
            bRes = xncwTheater.AttachTo(nxPlanetView2D);
            bRes = xncwObserver2D.AttachTo(nxPlanetView2D);

            bRes = xncwTheater.AttachTo(nxPlanetView3D);
            bRes = xncwObserver3D.AttachTo(nxPlanetView3D);

            xncwTheater.ShowAllObjects(nxPlanetView3D, true);

            XGeoPoint pos = new XGeoPoint();
            pos.latd = 37.5;
            pos.lond = 127.5;
            pos.hgt = 2000000.0;
            nxPlanetView2D.SetCameraPosition(pos, XAngle.FromDegree(0.0));
            nxPlanetView2D.GridType = Pixoneer.NXDL.NXPlanet.NXPlanetView.eGridType.GridNone;
            nxPlanetView2D.ShowGrid = true;
            nxPlanetView2D.Rotatable = false;
            pos.hgt = 1050000.0;
            nxPlanetView3D.SetCameraPosition(pos, XAngle.FromDegree(0.0), XAngle.FromDegree(-90.0), XAngle.FromDegree(0.0));
            m_listView.CheckBoxes = true;
            m_listView.FullRowSelect = true;

            nxPlanetView2D.ShowStatusInfo = true;
            nxPlanetView3D.ShowStatusInfo = false;

            xncwObserver2D.SetDistance(1000);

            nxPlanetView3D.EnableGroundEffect = true;
            XGeoPoint sunPos = XGeoPoint.FromDegree(180.0, 0.0, 6378137.0000 * 0.000001);
            nxPlanetView3D.SetSunPosition(sunPos);
            nxPlanetView3D.RefreshScreen();
        }
        

        private void AddListViewItem(MyModel newItem)
        {
            m_ModelList.Add(newItem);
            ListViewItem lvi = new ListViewItem(newItem.m_nID.ToString());
            lvi.Checked = true;
            lvi.SubItems.Add(newItem.m_nID.ToString());
            lvi.SubItems.Add(newItem.m_strName.ToString());
            m_listView.Items.Add(lvi);
        }
        public void RefreshScreenThread()
        {
            m_bRunThread = true;
            
            while (m_bRunThread)
            {
                xncwTheater.UpdateVisibleArea();
                nxPlanetView2D.RefreshScreen();
                nxPlanetView3D.RefreshScreen();
                Thread.Sleep(100);
            }
        }
        private void m_button_AddPlane_Click(object sender, EventArgs e)
        {
            AddPlaneForm newPalne = new AddPlaneForm();
            newPalne.m_ModelID = GetNextModelID();
            newPalne.m_Name = "Model";
            DialogResult res = newPalne.ShowDialog();
            if (res == System.Windows.Forms.DialogResult.OK)
            {
                MyModel newItem = new MyModel();
                if (newItem.Initialize(newPalne.m_ModelFilePath, newPalne.m_Name, newPalne.m_ModelID, newPalne.m_DataFilePath) == true)
                {
                    newItem.Scalable = false;
                    XEquipObj obj = newItem;
                    if (xncwTheater.AddEquipment(newPalne.m_ModelID, ref obj) == true)
                    {
                        newItem.Start();
                        xncwTheater.UpdateVisibleArea();
                        nxPlanetView2D.RefreshScreen();
                        nxPlanetView3D.RefreshScreen();
                        m_nModelID++;
                        AddListViewItem(newItem);

                        if (m_thread == null)
                        {
                            m_thread = new Thread(RefreshScreenThread);
                            m_thread.Start();
                        }
                        
                    }
                    else
                        newItem.UnInitialize();
                }
            }
        }

        private void m_listView_ItemChecked(object sender, ItemCheckedEventArgs e)
        {
            if (e.Item.Text == String.Empty)
                return;

            int nID = int.Parse(e.Item.Text);
            if (xncwTheater == null)
                return;
            XEquipObj obj = xncwTheater.GetEquipment(nID);
            if (obj != null)
                obj.HideObject(!e.Item.Checked);
        }

        private void m_listView_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                ListViewItem selectItem = m_listView.GetItemAt(e.X, e.Y);
                if (selectItem == null)
                    return;

                String strID = selectItem.Text;
                ContextMenu m = new ContextMenu();
                MenuItem property = new MenuItem();
                property.Text = "속성";
                property.Click += (senders, es) =>
                {
                    ShowPropertyDlg(int.Parse(strID));
                };
                m.MenuItems.Add(property);
                m.Show(m_listView, new Point(e.X, e.Y));
            }
        }

        private void ShowPropertyDlg(int id)
        {
            if (xncwTheater == null)
                return;
            XEquipObj obj = xncwTheater.GetEquipment(id);
            if (obj != null)
            {
                MyModel ac = (MyModel)obj;
                PlaneProperty pty = new PlaneProperty();
                
                pty.m_Name = ac.m_strName;
                pty.m_ModelID = ac.m_nID;
                pty.m_DataFilePath = ac.m_strDataFile;
                pty.m_ModelFilePath = ac.m_strModelFile;
                pty.m_scalable = ac.Scalable;
                pty.m_xScale = ac.Scale.x;
                pty.m_yScale = ac.Scale.y;
                pty.m_zScale = ac.Scale.z;
                pty.m_ShowBoundingBox = ac.m_showBoundingBox;

                if (ac.m_CamMode == Pixoneer.NXDL.NNCW.XncwObserver.eViewMode.Unusable)
                    pty.m_CamMode = 11;
                else
                    pty.m_CamMode = (UInt32)ac.m_CamMode;
                DialogResult res = pty.ShowDialog();

                if (res == System.Windows.Forms.DialogResult.OK)
                {
                    ac.Scalable = pty.m_scalable;
                    ac.Scale = new XVertex3d(pty.m_xScale, pty.m_yScale, pty.m_zScale);
                    ac.m_showBoundingBox = pty.m_ShowBoundingBox;
                    ac.ShowBoundingBox(ac.m_showBoundingBox);
                    
                    if (pty.m_CamMode == 11)
                        ac.m_CamMode = Pixoneer.NXDL.NNCW.XncwObserver.eViewMode.Unusable;
                    else
                        ac.m_CamMode = (Pixoneer.NXDL.NNCW.XncwObserver.eViewMode)pty.m_CamMode;

                    if (ac.m_CamMode == Pixoneer.NXDL.NNCW.XncwObserver.eViewMode.Unusable)
                    {
                        xncwObserver2D.SurveyNone();
                        xncwObserver3D.SurveyNone();
                        obj.HideObject(false);
                        obj.HideObject(false);
                        XEquipObj a = new XEquipObj();
                    }
                    else
                    {
                        double distance2D = xncwObserver2D.GetDistance();
                        double distance3D = xncwObserver3D.GetDistance();
                        xncwObserver2D.SurveyTargetObj(obj, ac.m_CamMode);
                        xncwObserver2D.SetDistance(distance2D);
                        xncwObserver3D.SurveyTargetObj(obj, ac.m_CamMode);
                        xncwObserver3D.SetDistance(distance3D);
                    }

                    xncwTheater.UpdateVisibleArea();
                    nxPlanetView2D.RefreshScreen();
                    nxPlanetView3D.RefreshScreen();
                }
            }
        }

        private void nxPlanetView2D_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            m_ModelList[0].AutoDelete = false;

            xncwTheater.Pick(nxPlanetView2D.GetHandle(), new XVertex2d(e.X, e.Y));
        }
    }
}
